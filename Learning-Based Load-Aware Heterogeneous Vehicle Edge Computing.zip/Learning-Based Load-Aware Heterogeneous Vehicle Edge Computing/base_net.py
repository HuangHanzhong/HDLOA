import torch.nn as nn
import torch.nn.functional as f


class RNN(nn.Module):
    # Because all the agents share the same network, input_shape=obs_shape+n_actions+n_agents
    def __init__(self, input_shape, conf):
        super(RNN, self).__init__()
        self.conf = conf

        self.fc1 = nn.Linear(input_shape, conf.rnn_hidden_dim)
        self.rnn = nn.GRUCell(conf.rnn_hidden_dim, conf.rnn_hidden_dim)
        self.fc2 = nn.Linear(conf.rnn_hidden_dim, conf.n_actions)

    def forward(self, obs, hidden_state):
        x = f.relu(self.fc1(obs))
        h_in = hidden_state.reshape(-1, self.conf.rnn_hidden_dim)
        h = self.rnn(x, h_in)
        q = self.fc2(h)
        return q, h


# Critic of Central-V
class Critic(nn.Module):
    def __init__(self, input_shape, conf):
        super(Critic, self).__init__()
        self.conf = conf
        self.fc1 = nn.Linear(input_shape, conf.critic_dim)
        self.fc2 = nn.Linear(conf.critic_dim, conf.critic_dim)
        self.fc3 = nn.Linear(conf.critic_dim, 1)

    def forward(self, inputs):
        x = f.relu(self.fc1(inputs))
        x = f.relu(self.fc2(x))
        q = self.fc3(x)
        return q
