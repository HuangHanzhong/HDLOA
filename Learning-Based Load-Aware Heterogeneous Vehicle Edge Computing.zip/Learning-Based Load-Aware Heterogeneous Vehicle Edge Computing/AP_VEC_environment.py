"""
Created on Tue Nov 10 06:17:06 2020
@author: leisureronaldo
This function is used for uplink computation offloading
"""
import numpy as np
import random
import math
import copy
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
from interval import Interval
from math import ceil

class VEC_env:
    def __init__(self, conf):
        self.conf = conf
        # 下面三个是类实例变量，即实例化的特定类对象独有。在reset和step函数中通用
        self.VUE_coordinate_y_set = [0]*self.conf.VUE_num
        self.VUE_RSU_index_mapping = [0]*self.conf.VUE_num
        self.VUE_with_task_num = 0
        self.VUE_with_task_index_set = []
        self.VUE_task_type_index_set = [0]*self.conf.VUE_num
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num
        
        self.obs = [0]*self.conf.VUE_num
        
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        self.ABS_available_energy = self.conf.ABS_energy_initial
        self.MBS_computing_resource = 0
        self.last_action = np.zeros((self.conf.n_agents, self.conf.n_actions))
        
        self.state = np.empty(self.conf.state_shape)
        
        self.avail_actions = []
        
        self.VUE_x1_num = 0
        self.VUE_x2_num = 0
        
        self.local_latency_if_set = [0]*self.conf.VUE_num
        self.VUE_with_task_index_set = []
        self.VUE_with_task_num = 0
        
        self.last_reward = 0
        self.last_bad_reward_count = 0
        
        self.lowzero_gain_count_in_this_episode = 0
        self.lowzero_reward_temp_if_interval_count_in_this_episode = 0
        
    def reset(self): # 初始化每回合开始的obs和state
        self.lowzero_gain_count_in_this_episode = 0
        self.lowzero_reward_temp_if_interval_count_in_this_episode = 0
        
        self.VUE_coordinate_y_set = [0]*self.conf.VUE_num
        self.VUE_RSU_index_mapping = [0]*self.conf.VUE_num
        generated_task_num = 0 # 初始化
        self.VUE_with_task_num = 0
        self.VUE_with_task_index_set = []
        self.VUE_task_type_index_set = [0]*self.conf.VUE_num
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num
        self.local_latency_if_set = [0]*self.conf.VUE_num
        
        self.obs = [0]*self.conf.VUE_num
        
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        self.ABS_available_energy = self.conf.ABS_energy_initial
        self.MBS_computing_resource = 0
        self.last_action = np.zeros((self.conf.n_agents, self.conf.n_actions))
        
        self.state = np.empty(self.conf.state_shape)
        
        self.avail_actions = [0]*self.conf.VUE_num
        
        self.last_reward = 0
        self.last_bad_reward_count = 0
        
        self.VUE_x1_num = 0
        self.VUE_x2_num = 0
        """
        while self.VUE_x1_num == 0:
            self.VUE_x1_num = (random.sample(self.conf.VUE_index_set, 1))[0] # sample的结果是一个列表，要取出元素
        """
        self.VUE_x1_num = 6
        self.VUE_x2_num = self.conf.VUE_num - self.VUE_x1_num # 后面向左行驶的车辆数（x轴负轴）
        
        VUE_x1_coordinate_y_set = random.sample(self.conf.x1_coordinate_candidates, self.VUE_x1_num) # 从坐标点候选集随机初始化车辆坐标
        VUE_x1_coordinate_y_set.sort() # 由小到大排序
        VUE_x2_coordinate_y_set = random.sample(self.conf.x2_coordinate_candidates, self.VUE_x2_num)
        VUE_x2_coordinate_y_set.sort()
        
        self.VUE_coordinate_y_set = VUE_x1_coordinate_y_set + VUE_x2_coordinate_y_set # 合并两条路的车辆坐标
        
        VUE_coordinate_y_set_candidate = []
        VUE_coordinate_y_set_candidate.append([-149, -99, 101, 201, 301, 501, -251, -151, -51, 49, 99, 199, 249, 349, 449, 499, 549, 599]) # [1, 8, 9]
        #VUE_coordinate_y_set_candidate.append([-599, -449, 51, 251, 401, 501, -501, -401, -301, -201, -151, -51, 49, 99, 149, 349, 549, 599]) # [6, 6, 6]
        
        """
        VUE_coordinate_y_set_candidate.append([-99, 101, 201, 251, 401, 501, -451, -351, -101, -51, 49, 99, 299, 349, 399, 449, 499, 599]) # [2, 6, 10]
        VUE_coordinate_y_set_candidate.append([-549, -299, -49, 301, 401, 501, -451, -401, -351, -251, -101, 249, 349, 399, 449, 499, 549, 599]) # [6, 2, 4]
        VUE_coordinate_y_set_candidate.append([-599, -399, -349, -149, 51, 251, -451, -401, -351, -251, -201, 199, 249, 299, 349, 399, 449, 549]) # [8, 3, 7]
        VUE_coordinate_y_set_candidate.append([-449, -249, 151, 301, 401, 451, -501, -251, -201, -51, 49, 99, 149, 299, 349, 399, 549, 599]) # [5, 5, 8]
        VUE_coordinate_y_set_candidate.append([-549, 51, 201, 251, 401, 451, -501, -401, -251, -201, -1, 199, 249, 299, 349, 399, 499, 549]) # [5, 3, 10]
        VUE_coordinate_y_set_candidate.append([-399, -299, -249, -99, -49, 151, -501, -451, -401, -351, -201, -151, -101, 99, 199, 299, 499, 599]) # [8, 7, 3]
        #VUE_coordinate_y_set_candidate.append([-349, -199, -99, 251, 351, 501, -501, -451, -351, -151, -101, -1, 49, 199, 299, 349, 449, 549]) # [4, 7, 7]
        """
        VUE_coordinate_y_set_candidate_index = list(range(0, len(VUE_coordinate_y_set_candidate)))
        VUE_coordinate_y_set_index = random.sample(VUE_coordinate_y_set_candidate_index, 1)[0]
        self.VUE_coordinate_y_set = VUE_coordinate_y_set_candidate[VUE_coordinate_y_set_index]
        """"""
        for VUE_index in self.conf.VUE_index_set:
            for RSU_index in self.conf.RSU_index_set:
                if self.VUE_coordinate_y_set[VUE_index] in self.conf.RSU_y_range_set[RSU_index]:  # 如果VUE y坐标在此RSU范围内
                    self.VUE_RSU_index_mapping[VUE_index] = RSU_index # VUE与RSU的连接映射
        
        # 指数分布参考 https://blog.csdn.net/robert_chen1988/article/details/82887820
        # np.random.poisson(5, [2,2]) # 生成2*2的均值为5的泊松数组
        # random.expovariate(0.2) # 生成一个均值为0.2的指数分布随机数
        # generated_task_num = int(np.random.exponential(self.conf.exp_lambda, size=1)[0]) # 生成size=1的一维数组，取出元素再加int即一个随机整数
        
        while generated_task_num not in Interval(self.conf.VUE_with_task_num_min, self.conf.VUE_num):
            generated_task_num = int(np.random.poisson(self.conf.task_generation_lambda, [1])[0])
            # 生成size=1的一维数组，取出元素再加int即一个随机整数
        """"""
        generated_task_num = self.conf.VUE_num
        self.VUE_with_task_num = generated_task_num
        self.VUE_with_task_index_set = random.sample(self.conf.VUE_index_set, generated_task_num)
        self.VUE_with_task_index_set.sort()
        
        self.VUE_task_type_index_set = np.random.choice(list(range(0, self.conf.task_type_num)), self.conf.VUE_num, p = self.conf.task_type_prob.ravel()).tolist()
        # 生成self.VUE_num个任务编号，下面只取有任务生成的车辆编号进行任务数据和计算需求赋值
        last_gain_states = [0]*self.conf.VUE_num
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                self.VUE_task_bit_size_set[VUE_index] = self.conf.task_bit_size_set[self.VUE_task_type_index_set[VUE_index]]
                self.VUE_task_computation_resource_requirement_set[VUE_index] = self.conf.task_computation_resource_requirement_set[self.VUE_task_type_index_set[VUE_index]]
                
                this_VUE_local_computing_latency_if = (self.VUE_task_computation_resource_requirement_set[VUE_index] / self.conf.VUE_computing_resource) * 1e3
                # 本地计算时延(ms)。如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                self.local_latency_if_set[VUE_index] = round(this_VUE_local_computing_latency_if, 3)
            
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + \
                                               [self.VUE_task_bit_size_set[VUE_index] / self.conf.task_bit_size_max] + \
                                               [self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max] + \
                                               [self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                      self.conf.task_computation_resource_requirement_max] + \
                                                [last_gain_states[VUE_index]])
                # [round(self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max, 4)]
            else:
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + [0]*(self.conf.obs_shape - 1))
        
        VUE_task_computation_resource_requirement_in_RSUs_set = [[], [], []] # 每个RSU里面的所有VUE的计算资源需求
        VUE_index_set_dd = [[], [], []]
        for VUE_index in self.VUE_with_task_index_set:
            this_RSU_index = self.VUE_RSU_index_mapping[VUE_index]
            self.VUE_with_task_num_in_RSU_set[this_RSU_index] += 1
            VUE_task_computation_resource_requirement_in_RSUs_set[this_RSU_index].append(self.VUE_task_computation_resource_requirement_set[VUE_index])
            VUE_index_set_dd[this_RSU_index].append(VUE_index)
        
        #print("self.VUE_coordinate_y_set:", self.VUE_coordinate_y_set)
        #print("self.VUE_with_task_num_in_RSU_set:", self.VUE_with_task_num_in_RSU_set)
        self.MBS_computing_resource = (self.conf.MBS_computing_resource_up - np.random.poisson(self.conf.Poisson_factor=3, size=1)) * 1e9
        # CPU cycles/second MBS还要服务其余的用户等，因此设定随机可用计算资源
        
        self.state = np.array([ele/self.conf.VUE_num for ele in self.VUE_with_task_num_in_RSU_set] + \
                              [self.ABS_available_energy / self.conf.ABS_energy_initial] + \
                              [self.MBS_computing_resource / (self.conf.MBS_computing_resource_up*1e9)] + \
                              self.last_action.flatten().tolist())
        self.real_VUE_index_set = []
        for RSU_index in range(self.conf.RSU_num):
            if len(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index]) <= self.conf.beam_num_max:
                for i in VUE_index_set_dd[RSU_index]:
                    avail_actions = [0]*self.conf.n_actions
                    avail_actions[RSU_index + 1] = 1
                    self.avail_actions[i] = avail_actions
            
            elif len(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index]) > self.conf.beam_num_max:
                VUE_task_computation_resource_requirement_in_RSUs_set_sorted = sorted(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index], reverse=True)
                VUE_index_set_of_direct_RSU_mode = []
                for index in range(self.conf.beam_num_max):
                    this_VUE_index_temp = VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index].index(VUE_task_computation_resource_requirement_in_RSUs_set_sorted[index]) # 取第一大的index
                    this_VUE_index = VUE_index_set_dd[RSU_index][this_VUE_index_temp]
                    VUE_index_set_of_direct_RSU_mode.append(this_VUE_index)
                    VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index][this_VUE_index_temp] = 0
                    
                for i in VUE_index_set_dd[RSU_index]:
                    if i in VUE_index_set_of_direct_RSU_mode:
                        avail_actions = [0]*self.conf.n_actions
                        avail_actions[RSU_index + 1] = 1
                        self.avail_actions[i] = avail_actions
                    else:
                        avail_actions = [1]*self.conf.n_actions
                        avail_actions[RSU_index + 1] = 0
                        self.avail_actions[i] = avail_actions
                        self.real_VUE_index_set.append(i)                    
        #if 0 in self.avail_actions:
        #print(self.avail_actions)
        #print("yes")
        
    def step(self, episodes_count, step, action_set):
        bad_offloading_flag_num = 0
        generated_task_num_record = self.VUE_with_task_num  # 记录此数据return传给utils
        good_offloading_VUE_num = 0
        
        local_num = 0
        offloading_mode_gain_sum = 0
        offloading_mode_revised_gain_sum = 0
        VUE_num_served_by_MBS = 0
        relay_latency_max = 0
        latency_set_max = 0
        latency_set_sum = 0
        latency_max_interval = 0
        RSU_empty_flag = 0
        MBS_empty_flag = 0
        VUE_num_direct_served_by_RSU_set = [0]*self.conf.RSU_num
        VUE_num_relay_served_by_RSU_set = [0]*self.conf.RSU_num
        VUE_num_served_by_RSU_set = [0]*self.conf.RSU_num
        bad_offloading_flag_set = [0]*self.conf.bad_flag_num
        
        
        return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, relay_latency_max, latency_set_max, latency_set_sum, \
                       latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                       VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, \
                       self.lowzero_gain_count_in_this_episode, self.lowzero_reward_temp_if_interval_count_in_this_episode]
        
        #####
        if self.ABS_available_energy < self.conf.ABS_energy_threshold: # ABS能量阈值
            #print("ABS energy out")
            reward = self.conf.ABS_energy_out_penalty
            terminated = True
            return (reward, terminated, return_part)
        
        action_set_int = [int(i) for i in action_set]
        self.last_action = np.eye(self.conf.n_actions)[np.array(action_set_int)]
        
        VUE_relay_computing_node_mapping_matrix = [[0 for i in range(2)] for j in range(self.conf.VUE_num)]
        # 存储中继计算节点编号；第一列表示中继VUE的编号；第2列表示中继RSU的编号
        VUE_decision_flag_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*9二维列表，第1列表示直接本地计算；第2~4列表示RSU的直连决策；
        # 后5~7列表示RSU中继决策；第8列表示MBS的中继决策；
        for VUE_index in self.VUE_with_task_index_set:
            if action_set[VUE_index] == 0: # 直接本地计算
                VUE_decision_flag_full_matrix[VUE_index][0] = 1
            elif action_set[VUE_index] in Interval(1, self.conf.RSU_num): # 如果决策值在这一区间，表示卸载到RSU
                the_RSU_index = action_set[VUE_index] - 1
                if the_RSU_index == int(self.VUE_RSU_index_mapping[VUE_index]): # 直接卸载RSU
                    VUE_decision_flag_full_matrix[VUE_index][1 + the_RSU_index] = 1 # int()保证列表索引为int
                    # 如果VUE_RSU_index_mapping[VUE_index]=0，则在VUE_decision_flag_full_matrix[VUE_index]中位于2+0列
                else: # 中继RSU
                    VUE_relay_computing_node_mapping_matrix[VUE_index][1] = the_RSU_index # 记录此VUE的中继RSU编号
                    VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + the_RSU_index] = 1
            elif action_set[VUE_index] == self.conf.RSU_num + 1: # 中继MBS
                VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] = 1
        VUE_decision_flag_full_matrix_row_sum = [sum(i) for i in zip(*VUE_decision_flag_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_num_served_by_VUE = VUE_decision_flag_full_matrix_row_sum[0] # 直接本地计算的VUE数
        VUE_num_direct_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1: 1+self.conf.RSU_num] # 每个RSU直接服务的VUE数，是一个长度为RSU_num的列表
        VUE_num_relay_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # 每个RSU中继服务的VUE数，长度为3的列表
        VUE_num_served_by_RSU_set = [VUE_decision_flag_full_matrix_row_sum[1] + VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[2] + VUE_decision_flag_full_matrix_row_sum[2+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[3] + VUE_decision_flag_full_matrix_row_sum[3+self.conf.RSU_num]] # RSU服务的用户数量集合
        beam_num_of_RSU_set = VUE_num_direct_served_by_RSU_set
        # ABS和RSU通过sub6，不是通过毫米波，所以这个RSU本地卸载用户就是毫米波波束个数
        
        
        
        overload_RSU_num = len([ele for ele in beam_num_of_RSU_set if ele > self.conf.beam_num_max])
        if overload_RSU_num == 1:
            overload_RSU_index = []
            relay_VUE_num_for_overload_RSU = []
            if max(beam_num_of_RSU_set) > self.conf.beam_num_max:
                for RSU_index in range(self.conf.RSU_num):
                    if beam_num_of_RSU_set[RSU_index] > 4:
                        overload_RSU_index = RSU_index
                        relay_VUE_num_for_overload_RSU = VUE_num_relay_served_by_RSU_set[RSU_index] # 超载RSU对应的中继用户数
        if overload_RSU_num > 0:
            self.lowzero_reward_temp_if_interval_count_in_this_episode += 1
        
        VUE_num_served_by_MBS = VUE_decision_flag_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE数
        VUE_distribution = [VUE_num_served_by_VUE] + self.VUE_with_task_num_in_RSU_set + VUE_num_direct_served_by_RSU_set + VUE_num_relay_served_by_RSU_set + \
                           VUE_num_served_by_RSU_set + [VUE_num_served_by_MBS]
        
        if sum(VUE_num_relay_served_by_RSU_set) == 0:
            RSU_empty_flag = 1
        if VUE_num_served_by_MBS == 0:
            MBS_empty_flag = 1
        
        VUE_task_type_index_full_matrix = [[0 for i in range(self.conf.task_type_num)] for j in range(self.conf.VUE_num + self.conf.RSU_num + 1)]
        # 行为每个节点编号，列为任务类型编号
        local_task_type_index_set = []
        edge_task_type_index_set = []
        for VUE_index in self.VUE_with_task_index_set:
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 本地计算
                VUE_task_type_index_full_matrix[VUE_index][self.VUE_task_type_index_set[VUE_index]] += 1
                local_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            for RSU_index in self.conf.RSU_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][1 + RSU_index] == 1 or \
                   VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + RSU_index] == 1: # RSU计算
                    VUE_task_type_index_full_matrix[self.conf.VUE_num + RSU_index][self.VUE_task_type_index_set[VUE_index]] += 1
                    edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][-1] == 1: # MBS计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
        
        VUE_task_bit_size_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        VUE_task_computation_resource_requirement_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*8二维列表，表示VUE和本地/VUE/RSU/MBS的任务连接映射
        for VUE_index in self.VUE_with_task_index_set:
            for index in range(8): # 遍历本地，直连RSU，中继RSU和中继MBS
                if index == 1 and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                    # 注意此处的行序号，比如如果VUE1中继到VUE3，那么此时就是VEU_index=1，然后赋值VUE_task_computation_resource_requirement_full_matrix[3][1]
                if index in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                elif index != 1 and index not in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = self.VUE_task_computation_resource_requirement_set[VUE_index]
        
        VUE_task_bit_size_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_bit_size_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_bit_size_relay_served_by_RSU_set = VUE_task_bit_size_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # RSU中继服务的用户任务量集合
        VUE_task_bit_size_relay_served_by_MBS = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        VUE_task_bit_size_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set + [VUE_task_bit_size_relay_served_by_MBS])
        VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set)
        # ABS中继的总任务量
        
        VUE_task_computation_resource_requirement_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_computation_resource_requirement_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_computation_resource_requirement_served_by_RSU_set = [VUE_task_computation_resource_requirement_full_matrix_row_sum[1] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3 + self.conf.RSU_num]]
        # RSU中继服务的用户任务量集合
        VUE_task_computation_resource_requirement_served_by_MBS = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num]
        # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
        
        VX_distance_set = [[0 for i in range(1 + self.conf.RSU_num)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*(1+RSU_num)二维列表，前两列表示VUE到RSU的距离，最后一列表示VUE到ABS的距离
        for VUE_index in self.conf.VUE_index_set:
            VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - \
                                                                           np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])])) # 单位m
            VX_distance_set[VUE_index][-1] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.ABS_coordinate))
        
        AX_distance_set = [0]*(1 + self.conf.RSU_num)
        for RSU_index in self.conf.RSU_index_set:
            AX_distance_set[RSU_index] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.RSU_coordinate_set[RSU_index]))
        AX_distance_set[-1] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.MBS_coordinate))
        
        local_latency_set = [0]*self.conf.VUE_num
        RSU_direct_latency_set = [0]*self.conf.VUE_num
        RSU_relay_latency_set = [0]*self.conf.VUE_num
        MBS_relay_latency_set = [0]*self.conf.VUE_num
        VUE_latency_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*9二维列表
        relay_transmission_latency_sum = 0
               
        for VUE_index in self.VUE_with_task_index_set: # 遍历VUE
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                this_VUE_local_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                   self.conf.VUE_computing_resource) * 1e3 # 本地计算时延(ms)
                # 如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                local_latency_set[VUE_index] = this_VUE_local_computing_latency
                #print("local_latency_set[VUE_index]:", int(local_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][0] = int(local_latency_set[VUE_index])
                
            if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]: # 如果选择直连RSU
                VUE_direct_served_RSU_index = VUE_decision_flag_full_matrix[VUE_index].index(1) - 1 # 此VUE直连的RSU编号
                this_VR_distance = VX_distance_set[VUE_index][VUE_direct_served_RSU_index]
                this_VR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VR_distance ** (-self.conf.VR_power_decay_exponent), 10)
                this_VR_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_mmW_antenna_gain + self.conf.RSU_rx_mmW_antenna_gain + this_VR_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * self.conf.mmW_bandwidth, 10)
                """
                if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VR_transmission_rate = self.conf.mmW_bandwidth * math.log(1 + 10**(this_VR_SNR/10), 2)
                this_VR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VR_transmission_rate) * 1e3 # 单位为ms
                # 20+34+91-(20*math.log(4*math.pi*28*10**9 / (3*10**8), 10) + 10*2*math.log(200,10) + np.random.normal(loc=0.0, scale=4, size=None))
                # 如果任务为CA，(1e6 / 1.7e9) * 1000 = 0.57, 毫米波速度非常快
                
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] error")
                this_VUE_RSU_direct_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_RSU) * 1e3 # 单位为ms
                # 如果任务为CA，分配了50%计算资源，(1e6*150/(6e9*50/100))*1000 = 50 ms
                RSU_direct_latency_set[VUE_index] = this_VR_transmission_latency + this_VUE_RSU_direct_computing_latency
                #print("RSU_direct_latency_set[VUE_index]:", int(RSU_direct_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + VUE_direct_served_RSU_index] = int(RSU_direct_latency_set[VUE_index])
                
            elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]: # 如果选择中继到RSU
                VUE_relay_served_RSU_index = VUE_relay_computing_node_mapping_matrix[VUE_index][1] # 此VUE中继的RSU编号
                this_VA_distance = VX_distance_set[VUE_index][-1]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/37e6)*1000 = 27 ms
                
                this_AR_distance = AX_distance_set[VUE_relay_served_RSU_index]
                this_AR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_AR_distance ** (-self.conf.AR_power_decay_exponent), 10)
                if VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS > 0:
                    this_RSU_downlink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS error")
                this_AR_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.RSU_rx_sub6_antenna_gain + this_AR_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_RSU_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AR_transmission_rate = this_RSU_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AR_SNR/10), 2)
                this_AR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AR_transmission_rate) * 1e3 # 多个VUE的任务从ABS一起传输到RSU
                # 如果任务为CA， (1e6/96e6)*1000 = 10 ms
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] error")
                this_VUE_RSU_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_RSU) * 1e3
                RSU_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AR_transmission_latency + this_VUE_RSU_relay_computing_latency
                #print("RSU_relay_latency_set[VUE_index]:", int(RSU_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + self.conf.RSU_num + VUE_relay_served_RSU_index] = int(RSU_relay_latency_set[VUE_index])
                relay_transmission_latency_sum += this_VA_transmission_latency + this_AR_transmission_latency
                
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] == 1: # 如果选择中继到MBS
                this_VA_distance = VX_distance_set[VUE_index][-1]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB +\
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                
                this_AM_distance = AX_distance_set[-1]
                this_AM_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_AM_distance ** (-self.conf.AM_power_decay_exponent), 10)
                MBS_downlink_bandwidth_allocated_by_ABS = self.conf.sub6_bandwidth # MBS独占AM带宽
                this_AM_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_AM_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * MBS_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AM_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AM_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AM_transmission_rate = MBS_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AM_SNR/10), 2)
                this_AM_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AM_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/126e6)*1000 = 7.9 ms
                if VUE_task_computation_resource_requirement_served_by_MBS > 0:
                    this_VUE_computing_resource_allocated_by_MBS = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_MBS) * \
                                                                   self.MBS_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_MBS error")
                this_VUE_MBS_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_MBS) * 1e3
                MBS_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AM_transmission_latency + this_VUE_MBS_relay_computing_latency
                #print("MBS_relay_latency_set[VUE_index]:", int(MBS_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][-1] = int(MBS_relay_latency_set[VUE_index])
                relay_transmission_latency_sum += this_VA_transmission_latency + this_AM_transmission_latency
                
        for VUE_index in self.VUE_with_task_index_set:
            local_latency_set[VUE_index] = int(local_latency_set[VUE_index])
            RSU_direct_latency_set[VUE_index] = int(RSU_direct_latency_set[VUE_index])
            RSU_relay_latency_set[VUE_index] = int(RSU_relay_latency_set[VUE_index])
            MBS_relay_latency_set[VUE_index] = int(MBS_relay_latency_set[VUE_index])
        
        
        low_step_penalty = 0
        """
        low_step_penalty_initial = -0.5
        if step < 6:
            low_step_penalty = low_step_penalty_initial
        elif step in Interval(6, 10):
            low_step_penalty = low_step_penalty_initial + 0.15 * (step-5)
        """
        action_set_if_not_relay = [0]*self.VUE_with_task_num
        action_set_all_direct_RSU = [0]*self.VUE_with_task_num
        for VUE_index in self.VUE_with_task_index_set:
            if action_set[VUE_index] in Interval(1 + self.conf.RSU_num, 1 + 2*self.conf.RSU_num): # 中继卸载到RSU/MBS
                action_set_if_not_relay[VUE_index] = self.VUE_RSU_index_mapping[VUE_index]
            else:
                action_set_if_not_relay[VUE_index] = action_set[VUE_index]
            
            action_set_all_direct_RSU[VUE_index] = self.VUE_RSU_index_mapping[VUE_index]
        
        reward_if_not_relay = self.step_if(episodes_count, action_set_if_not_relay)
        # 如果agent的选择中继的用户不选择中继，而直接卸载到RSU，而不选择中继的用户保持action不变，计算其总增益
        reward_if_all_direct_RSU = self.step_if(episodes_count, action_set_all_direct_RSU)
        # 如果所有用户都直接卸载到RSU，其总增益
        
        reward_if_max = max(reward_if_not_relay, reward_if_all_direct_RSU)
        
        latency_set = [ele for ele in (local_latency_set + RSU_direct_latency_set + RSU_relay_latency_set + MBS_relay_latency_set) if ele > 0] # 单位ms
        #print("self.local_latency_if_set:", self.local_latency_if_set)
        #print("RSU_direct_latency_set   :", RSU_direct_latency_set)
        #print("RSU_relay_latency_set    :", RSU_relay_latency_set)
        relay_latency_set = [ele for ele in (RSU_relay_latency_set + MBS_relay_latency_set) if ele > 0] # 单位ms
        if len(relay_latency_set) > 0:
            relay_latency_max = max(relay_latency_set)
        else:
            relay_latency_max = 0
        latency_set_sum = round(sum(latency_set), 3)
        local_latency_if_set_sum = round(sum(self.local_latency_if_set), 3) # 如果本地计算的时延总和
        latency_set_max = round(max(latency_set), 3) # 最大用户时延值
        local_latency_if_set_max = round(max(self.local_latency_if_set), 3) # 如果本地计算的最大时延
        latency_max_interval = local_latency_if_set_max - latency_set_max # 本地计算模式和卸载模式的最大时延差，如果为正，则卸载效果好
        offloading_mode_gain_sum = int(local_latency_if_set_sum - latency_set_sum) # 如果本地时延与实际时延总和的差值，即选择卸载模式之后的增益
        
        offloading_mode_gain_set = [0]*self.conf.VUE_num # 每个用户的卸载增益
        offloading_mode_revised_gain_sum = 0 # 修改的增益总和。不同于offloading_mode_gain_sum，这个会对增益为负的用户做惩罚
        lowzero_gain_index_set = [] # 负增益的边缘节点编号
        good_gain_extra_score_sum = 0 # 正增益额外加的分
        RSU_gain_set = [0]*self.conf.RSU_num
        RSU_direct_gain_set = [[], [], []]
        RSU_relay_gain_set = [[], [], []]
        MBS_gain_set = []
        local_num = 0
        last_gain_states = [0]*self.conf.VUE_num
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                    offloading_mode_gain_set[VUE_index] = 0
                    #offloading_mode_revised_gain_sum += -20
                    local_num += 1
                
                elif 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]:
                    RSU_index = VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num].index(1)
                    """
                    offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:]) # 增益为正才好
                    if offloading_mode_gain_set[VUE_index] < 0: # 为负
                        lowzero_gain_index_set.append(RSU_index)
                        offloading_mode_gain_set[VUE_index] += -100
                    else:
                        good_gain_extra_score_sum += 50
                        offloading_mode_gain_set[VUE_index] += 50
                    if beam_num_of_RSU_set[RSU_index] > self.conf.beam_num_max:
                        offloading_mode_gain_set[VUE_index] = -50
                    RSU_gain_set[RSU_index] += offloading_mode_gain_set[VUE_index]
                    RSU_direct_gain_set[RSU_index].append(offloading_mode_gain_set[VUE_index])
                    offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                    """
                elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]:
                    RSU_index = (VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num].index(1))
                    offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:])
                    if offloading_mode_gain_set[VUE_index] < 0: # 为负
                        lowzero_gain_index_set.append(RSU_index)
                        #offloading_mode_gain_set[VUE_index] += -500
                        last_gain_states[VUE_index] = 1 # 如果增益为负，则增益状态置为1
                    else:
                        good_gain_extra_score_sum += 30
                        offloading_mode_gain_set[VUE_index] += 30
                    RSU_gain_set[RSU_index] += offloading_mode_gain_set[VUE_index]
                    RSU_relay_gain_set[RSU_index].append(int(offloading_mode_gain_set[VUE_index]))
                    offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                elif VUE_decision_flag_full_matrix[VUE_index][-1] == 1:
                    offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:])
                    if offloading_mode_gain_set[VUE_index] < 0: # 为负
                        lowzero_gain_index_set.append(2*self.conf.RSU_num)
                        #offloading_mode_gain_set[VUE_index] += -500
                        last_gain_states[VUE_index] = 1
                    else:
                        offloading_mode_gain_set[VUE_index] += -int(offloading_mode_gain_set[VUE_index] * 0.6)
                    MBS_gain_set.append(int(offloading_mode_gain_set[VUE_index]))
                    offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
        
        #print(RSU_relay_gain_set, MBS_gain_set)
        offloading_mode_gain_set = [int(ele) for ele in offloading_mode_gain_set]
        offloading_mode_revised_gain_sum = int(offloading_mode_revised_gain_sum)
        RSU_gain_set = [int(ele) for ele in RSU_gain_set]
        zero_num_in_offloading_mode_gain_set = len([ele for ele in offloading_mode_gain_set if ele == 0]) # 增益为0的用户数
        upzero_gains = [ele for ele in offloading_mode_gain_set if ele > 0]
        upzero_gains_num = len(upzero_gains)
        lowzero_gains = [ele for ele in offloading_mode_gain_set if ele < 0] # 负增益集合
        lowzero_gains_num = len(lowzero_gains)
        if lowzero_gains_num == 0:
            lowzero_gains_sum = 0
        elif lowzero_gains_num > 0:
            self.lowzero_gain_count_in_this_episode += 1
            #print("lowzero_gain_count:", self.lowzero_gain_count_in_this_episode)
            lowzero_gains_sum = int(sum(lowzero_gains)) # 所有负增益的和
            offloading_mode_revised_gain_sum += -good_gain_extra_score_sum # 如果有负增益，则把正增益加的分全部扣了
        
        #if (offloading_mode_revised_gain_sum < 600 or offloading_mode_gain_sum < 1500) and (lowzero_gains_sum < 0 or reward_temp_if_interval < 0):
        if lowzero_gains_num >= 3:
            bad_offloading_flag_set[0] = 1
            bad_offloading_flag_num += 1
        """
        if overload_RSU_num > 0:
            bad_offloading_flag_set[1] = 1
            bad_offloading_flag_num += 1
        
        if latency_max_interval < 0:
            bad_offloading_flag_set[2] = 1
            bad_offloading_flag_num += 1
        """
        ######
        #if lowzero_gains_num > 0:
            #offloading_mode_revised_gain_sum += -400 + (-100)*(lowzero_gains_num-1)
        if lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100:
            sRange = [100, 600]
            dRange = [0, 9.5]
            if offloading_mode_revised_gain_sum in Interval(sRange[0], sRange[1]):
                offloading_mode_revised_gain_sum_nor = (offloading_mode_revised_gain_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
            elif offloading_mode_revised_gain_sum > sRange[1]:
                offloading_mode_revised_gain_sum_nor = 10
        else:
            sRange = [-900, 0]
            dRange = [-10, -3]
            if offloading_mode_revised_gain_sum < sRange[0]:
                offloading_mode_revised_gain_sum_nor = -10
            if offloading_mode_revised_gain_sum in Interval(sRange[0], sRange[1]):
                offloading_mode_revised_gain_sum_nor = (offloading_mode_revised_gain_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
            elif offloading_mode_revised_gain_sum > sRange[1]:
                offloading_mode_revised_gain_sum_nor = -2
        
        
        """
        if not (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100):
            relay_latency_max_nor = 0
        
        if not (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100) and relay_latency_max_nor >= 0:
            relay_latency_max_nor = 0
        if relay_latency_max_nor < 0 and (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100):
            offloading_mode_revised_gain_sum_nor = 0
        """
        
        
        """
        sRange = [3, 7]
        dRange = [0, 10]
        if upzero_gains_num < sRange[0]:
            upzero_gains_num_nor = 0
        if upzero_gains_num in Interval(sRange[0], sRange[1]):
            upzero_gains_num_nor = (upzero_gains_num-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        elif upzero_gains_num > sRange[1]:
            upzero_gains_num_nor = 10
        """
        
        
        """
        if episodes_count > self.conf.start_show_epoch and 1 in bad_offloading_flag_set:
            print("bad_offloading_flag_set:", bad_offloading_flag_set, ' ', lowzero_gains_sum, ' ', int(offloading_mode_revised_gain_sum), ' ', \
                                              lowzero_gain_index_set, ' ', local_num, self.VUE_with_task_num_in_RSU_set, beam_num_of_RSU_set, \
                                              VUE_num_relay_served_by_RSU_set, VUE_num_served_by_MBS, ' ', '  ', step)
            print("                                 ", RSU_relay_gain_set, '  ', MBS_gain_set, '\n')
        """
        """
        if bad_offloading_flag_set[0] == 1:
            reward = -1
            reward += low_step_penalty
            terminated = True
            return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, \
                           latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                           VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, self.lowzero_gain_count_in_this_episode, \
                           self.lowzero_reward_temp_if_interval_count_in_this_episode]
            return (reward, terminated, return_part)
        
        if latency_max_interval < 0:
            reward = -1
            reward += low_step_penalty
            terminated = True
            return (reward, terminated, return_part)
        """
        """
        reward = 0.65*offloading_mode_revised_gain_sum_nor + 0.35*relay_latency_max_nor
        """
        sRange = [2700, 2350]
        dRange = [0, 10]
        if latency_set_sum > sRange[0]:
            latency_set_sum_nor = -1
        if latency_set_sum in Interval(sRange[0], sRange[1]):
            latency_set_sum_nor = (latency_set_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        elif latency_set_sum < sRange[1]:
            latency_set_sum_nor = 10
        
        sRange = [290, 230]
        dRange = [0.5, 10]
        if latency_set_max > sRange[0]:
            latency_set_max_nor = 0
        if latency_set_max in Interval(sRange[0], sRange[1]):
            latency_set_max_nor = (latency_set_max-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        elif latency_set_max < sRange[1]:
            latency_set_max_nor = 10
        
        if len(lowzero_gain_index_set) == 0:
            lowzero_gain_index_set = 0
        
        ##### rewar 1
        reward = 0.6*latency_set_sum_nor + 0.4*latency_set_max_nor
        
        ##### reward 2
        #reward = latency_set_sum_nor
        
        if sum(VUE_num_relay_served_by_RSU_set) + VUE_num_served_by_MBS <= 1:
            reward = -4
        if VUE_num_relay_served_by_RSU_set[0] <= 0:
            reward = -5
        if VUE_num_served_by_MBS <= 0:
            reward = -3
        #if lowzero_gains_sum > 0:
            #reward = -6
        """
        sRange = [-60, -1]
        dRange = [-8, -4]
        if lowzero_gains_sum < sRange[0]:
            lowzero_gains_sum_nor = -8
        if lowzero_gains_sum in Interval(sRange[0], sRange[1]):
            lowzero_gains_sum_nor = (lowzero_gains_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        if lowzero_gains_num > 0:
            reward = lowzero_gains_sum_nor
        """
        reward = max(min(reward, 10), -10)
        #if episodes_count > self.conf.start_show_epoch:
        if episodes_count > self.conf.start_show_epoch and (sum(VUE_num_relay_served_by_RSU_set) == 0 or lowzero_gains_sum < 0):
            print("    >:", lowzero_gains_sum, ' ', int(offloading_mode_revised_gain_sum), ' ', round(reward, 1), '  ', lowzero_gain_index_set, ' ', \
                            local_num, self.VUE_with_task_num_in_RSU_set, beam_num_of_RSU_set, VUE_num_relay_served_by_RSU_set, VUE_num_served_by_MBS, '  ', \
                            int(relay_latency_max), RSU_empty_flag, MBS_empty_flag, '  ', RSU_relay_gain_set, '  ', MBS_gain_set)
        
        """
        if min(VUE_num_relay_served_by_RSU_set[0], VUE_num_served_by_MBS) == 0 or sum(VUE_num_relay_served_by_RSU_set) + VUE_num_served_by_MBS <= 1:
            reward = -4
        """ 
        
        
        
        """
        if episodes_count > 1100 and self.last_bad_reward_count > 0 and reward > 0 and lowzero_gains_sum == 0:
            reward = reward * (1- 0.2*self.last_bad_reward_count)
        """
        """
        sRange = [-500, -1]
        dRange = [-10, -4]
        if lowzero_gains_sum < sRange[0]:
            lowzero_gains_sum_nor = -10
        if lowzero_gains_sum in Interval(sRange[0], sRange[1]):
            lowzero_gains_sum_nor = (lowzero_gains_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        
        if lowzero_gains_num > 0:
            reward = lowzero_gains_sum_nor
        """
        
        
        """
        for RSU_index in range(self.conf.RSU_num):
            if self.VUE_with_task_num_in_RSU_set[RSU_index] > 4 and beam_num_of_RSU_set[RSU_index] < 4 and VUE_num_relay_served_by_RSU_set[RSU_index] > 0:
                reward = reward * 0.5
                break
            if self.VUE_with_task_num_in_RSU_set[RSU_index] > 4 and beam_num_of_RSU_set[RSU_index] < 4 and VUE_num_relay_served_by_RSU_set[RSU_index] == 0:
                reward = reward * 0.6
                break
            if self.VUE_with_task_num_in_RSU_set[RSU_index] > 4 and beam_num_of_RSU_set[RSU_index] == 4 and VUE_num_relay_served_by_RSU_set[RSU_index] > 0:
                reward = reward * 0.7
                break
            elif self.VUE_with_task_num_in_RSU_set[RSU_index] > 4 and beam_num_of_RSU_set[RSU_index] == 4 and VUE_num_relay_served_by_RSU_set[RSU_index] == 0:
                reward = 10
                break
        """
        
        """
        #if 0 in VUE_num_served_by_RSU_set:
        if episodes_count > self.conf.start_show_episode and (episodes_count + 1) % int(self.conf.result_print_interval/1) == 0:
            print("reward:", \
                  [good_offloading_flag+1, round(reward, 2), int(offloading_mode_gain_sum), int(offloading_mode_revised_gain_sum), \
                   round(offloading_mode_revised_gain_sum / 2700, 2)], offloading_mode_gain_set)
            
            print("VUE_num: ", VUE_distribution, '\n', offloading_mode_gain_set, '\n')
            print("end:")
            
            print("local_latency_set:       ", local_latency_set)
            print("RSU_direct_latency_set:  ", RSU_direct_latency_set)
            print("RSU_relay_latency_set:   ", RSU_relay_latency_set)
            print("MBS_relay_latency_set:   ", MBS_relay_latency_set)
            print("VUE_decision_flag_full_matrix:", VUE_decision_flag_full_matrix)
            print("VUE_relay_computing_node_mapping_matrix:", VUE_relay_computing_node_mapping_matrix)
            print("VUE_latency_full_matrix:", VUE_latency_full_matrix)
            print("self.VUE_RSU_index_mapping:", self.VUE_RSU_index_mapping)
            print("action_set:              ", action_set)
            print("yes:")
        """
        
        VUE_speed_set_tensor = tf.random.truncated_normal( # 通过tf.random.truncated_normal生成长度为VUE_num的一维截断高斯数组
                [self.conf.VUE_num],
                mean = self.conf.truncated_normal_mean,
                stddev = self.conf.truncated_normal_stddev,
                dtype = tf.dtypes.float32,
                seed = None,
                name = None)
        with tf.Session() as sess: # 假如长度为5，上述输出的VUE_speed_set_tensor为<tf.Tensor 'truncated_normal:0' shape=(5,) dtype=float32>
        # 需要tf.Session()和sess.run()，才能输出一维数组array([53.789173, 62.596733, 61.138756, 68.24399 , 60.86609 ], dtype=float32)
            VUE_speed_set = list(sess.run(VUE_speed_set_tensor)) # 然后再转换为list
        VUE_speed_set = [ele*self.conf.VUE_speed_unit_factor for ele in VUE_speed_set] # 单位换算
        # [1.7, 1.6, 1.7, 1.5, 1.4, 1.7, 1.6, 1.5, 1.6, 1.6, 1.6, 1.6, 1.5, 1.7, 1.5, 1.5, 1.6, 1.7, 1.6, 1.5, 1.7, 1.8, 1.7, 1.6, 1.6, \
        # 1.6, 1.9, 1.6, 1.6, 1.8, 1.5, 1.7, 1.8, 1.7, 1.6, 1.8, 1.7, 1.5, 1.9, 1.6, 1.5, 1.5, 1.7, 1.6, 1.6, 1.7, 1.5, 1.5, 1.9, 1.6]
        
        VUE_x1_coordinate_y_set = self.VUE_coordinate_y_set[0: self.VUE_x1_num]
        VUE_x2_coordinate_y_set = self.VUE_coordinate_y_set[self.VUE_x1_num: ]
        
        for VUE_x1_index in range(self.VUE_x1_num): # x正轴道路的车辆沿y轴正方向（从左往右）行驶
            VUE_x1_coordinate_y_set[VUE_x1_index] = VUE_x1_coordinate_y_set[VUE_x1_index] + VUE_speed_set[VUE_x1_index]  # 更新VUE的y坐标
            if VUE_x1_coordinate_y_set[VUE_x1_index] > self.conf.coordinate_y_end: # 如果超出y轴右边界范围，则从左边重新进入道路
                VUE_x1_coordinate_y_set[VUE_x1_index] = self.conf.coordinate_y_begin + (VUE_x1_coordinate_y_set[VUE_x1_index] - self.conf.coordinate_y_end)
        VUE_x1_coordinate_y_set.sort() # 由小到大排序
        
        for VUE_x2_index in range(self.VUE_x2_num): # x负轴道路的车辆沿y轴负方向（从右往左）行驶
            VUE_x2_coordinate_y_set[VUE_x2_index] = VUE_x2_coordinate_y_set[VUE_x2_index] - VUE_speed_set[self.VUE_x1_num + VUE_x2_index]  # 更新VUE的y坐标
            # 注意VUE_speed_set的索引
            if VUE_x2_coordinate_y_set[VUE_x2_index] < self.conf.coordinate_y_begin: # 如果超出仿真范围，则从右边重新进入道路
                VUE_x2_coordinate_y_set[VUE_x2_index] = self.conf.coordinate_y_end + (VUE_x2_coordinate_y_set[VUE_x2_index] - self.conf.coordinate_y_begin)
        VUE_x2_coordinate_y_set.sort() # 由小到大排序
        
        self.VUE_coordinate_y_set = VUE_x1_coordinate_y_set + VUE_x2_coordinate_y_set # 合并两条路的车辆坐标
        
        self.VUE_RSU_index_mapping = [0]*self.conf.VUE_num # 重新初始化VUE_RSU_index_mapping
        for VUE_index in self.conf.VUE_index_set:
            for RSU_index in self.conf.RSU_index_set:
                if self.VUE_coordinate_y_set[VUE_index] in self.conf.RSU_y_range_set[RSU_index]:  # 如果VUE y坐标在此RSU范围内
                    self.VUE_RSU_index_mapping[VUE_index] = RSU_index # VUE与RSU的连接映射
        
        generated_task_num = 0 # 初始化
        self.VUE_with_task_num = 0 #初始化
        self.VUE_with_task_index_set = []
        
        while generated_task_num not in Interval(self.conf.VUE_with_task_num_min, self.conf.VUE_num):
            generated_task_num = int(np.random.poisson(self.conf.task_generation_lambda, [1])[0])
            # 生成size=1的一维数组，取出元素再加int即一个随机整数
        """"""
        generated_task_num = self.conf.VUE_num
        self.VUE_with_task_num = generated_task_num
        self.VUE_with_task_index_set = random.sample(self.conf.VUE_index_set, generated_task_num)
        self.VUE_with_task_index_set.sort()
        
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num
        self.local_latency_if_set = [0]*self.conf.VUE_num
        self.obs = [0]*self.conf.VUE_num
        
        self.VUE_task_type_index_set = np.random.choice(list(range(0, self.conf.task_type_num)), self.conf.VUE_num, p = self.conf.task_type_prob.ravel()).tolist()
        # 生成self.VUE_num个任务编号，下面只取有任务生成的车辆编号进行任务数据和计算需求赋值
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                self.VUE_task_bit_size_set[VUE_index] = self.conf.task_bit_size_set[self.VUE_task_type_index_set[VUE_index]]
                self.VUE_task_computation_resource_requirement_set[VUE_index] = self.conf.task_computation_resource_requirement_set[self.VUE_task_type_index_set[VUE_index]]
                
                this_VUE_local_computing_latency_if = (self.VUE_task_computation_resource_requirement_set[VUE_index] / self.conf.VUE_computing_resource) * 1e3
                # 本地计算时延(ms)。如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                self.local_latency_if_set[VUE_index] = round(this_VUE_local_computing_latency_if, 3)
            
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + \
                                               [self.VUE_task_bit_size_set[VUE_index] / self.conf.task_bit_size_max] + \
                                               [self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max] + \
                                               [self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                      self.conf.task_computation_resource_requirement_max] + \
                                                [last_gain_states[VUE_index]])
                # [round(self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max, 4)]
            else:
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + [0]*(self.conf.obs_shape - 1))
        
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        VUE_task_computation_resource_requirement_in_RSUs_set = [[], [], []] # 每个RSU里面的所有VUE的计算资源需求
        VUE_index_set_dd = [[], [], []]
        for VUE_index in self.VUE_with_task_index_set:
            this_RSU_index = self.VUE_RSU_index_mapping[VUE_index]
            self.VUE_with_task_num_in_RSU_set[this_RSU_index] += 1
            VUE_task_computation_resource_requirement_in_RSUs_set[this_RSU_index].append(self.VUE_task_computation_resource_requirement_set[VUE_index])
            VUE_index_set_dd[this_RSU_index].append(VUE_index)
        
        self.ABS_available_energy = self.ABS_available_energy - 1
        
        self.MBS_computing_resource = 0 # 初始化
        self.MBS_computing_resource = (self.conf.MBS_computing_resource_up - np.random.poisson(self.conf.Poisson_factor=3, size=1)) * 1e9
        # CPU cycles/second MBS还要服务其余的用户等，因此设定随机可用计算资源
        
        self.state = np.empty(self.conf.state_shape) # 初始化
        self.state = np.array([ele/self.conf.VUE_num for ele in self.VUE_with_task_num_in_RSU_set] + \
                              [self.ABS_available_energy / self.conf.ABS_energy_initial] + \
                              [self.MBS_computing_resource / (self.conf.MBS_computing_resource_up*1e9)] + \
                              self.last_action.flatten().tolist())
        
        self.avail_actions = [0]*self.conf.VUE_num
        self.real_VUE_index_set = []
        for RSU_index in range(self.conf.RSU_num):
            if len(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index]) <= self.conf.beam_num_max:
                for i in VUE_index_set_dd[RSU_index]:
                    avail_actions = [0]*self.conf.n_actions
                    avail_actions[RSU_index + 1] = 1
                    self.avail_actions[i] = avail_actions
            
            elif len(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index]) > self.conf.beam_num_max:
                VUE_task_computation_resource_requirement_in_RSUs_set_sorted = sorted(VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index], reverse=True)
                VUE_index_set_of_direct_RSU_mode = []
                for index in range(self.conf.beam_num_max):
                    this_VUE_index_temp = VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index].index(VUE_task_computation_resource_requirement_in_RSUs_set_sorted[index]) # 取第一大的index
                    this_VUE_index = VUE_index_set_dd[RSU_index][this_VUE_index_temp]
                    VUE_index_set_of_direct_RSU_mode.append(this_VUE_index)
                    VUE_task_computation_resource_requirement_in_RSUs_set[RSU_index][this_VUE_index_temp] = 0
                    
                for i in VUE_index_set_dd[RSU_index]:
                    if i in VUE_index_set_of_direct_RSU_mode:
                        avail_actions = [0]*self.conf.n_actions
                        avail_actions[RSU_index + 1] = 1
                        self.avail_actions[i] = avail_actions
                    else:
                        avail_actions = [1]*self.conf.n_actions
                        avail_actions[RSU_index + 1] = 0
                        self.avail_actions[i] = avail_actions
                        self.real_VUE_index_set.append(i)
        
        #if 0 in self.avail_actions:
        #print(self.avail_actions)
        #print("yes")
        
        self.last_reward = reward # 记录这一步的reward，在下一步用
        
        if reward < 0:
            self.last_bad_reward_count += 1 # 统计这一回合中负惩罚的次数，在下一步用
        """"""
        terminated = False
        return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, relay_latency_max, latency_set_max, latency_set_sum, \
                       latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                       VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, \
                       self.lowzero_gain_count_in_this_episode, self.lowzero_reward_temp_if_interval_count_in_this_episode]
        
        return (reward, terminated, return_part)


    def step_if(self, episodes_count, action_set_if):
        VUE_relay_computing_node_mapping_matrix = [[0 for i in range(2)] for j in range(self.conf.VUE_num)]
        # 存储中继计算节点编号；第一列表示中继VUE的编号；第2列表示中继RSU的编号
        VUE_decision_flag_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*9二维列表，第1列表示直接本地计算；第2~4列表示RSU的直连决策；
        # 后5~7列表示RSU中继决策；第8列表示MBS的中继决策；
        for VUE_index in self.VUE_with_task_index_set:
            if action_set_if[VUE_index] == 0: # 直接本地计算
                VUE_decision_flag_full_matrix[VUE_index][0] = 1
            elif action_set_if[VUE_index] in Interval(1, self.conf.RSU_num): # 如果决策值在这一区间，表示卸载到RSU
                the_RSU_index = int(self.VUE_RSU_index_mapping[VUE_index]) # 直接卸载RSU
                VUE_decision_flag_full_matrix[VUE_index][1 + the_RSU_index] = 1 # int()保证列表索引为int
        VUE_decision_flag_full_matrix_row_sum = [sum(i) for i in zip(*VUE_decision_flag_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_num_served_by_VUE = VUE_decision_flag_full_matrix_row_sum[0] # 直接本地计算的VUE数
        VUE_num_direct_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1: 1+self.conf.RSU_num] # 每个RSU直接服务的VUE数，是一个长度为RSU_num的列表
        VUE_num_relay_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # 每个RSU中继服务的VUE数，长度为3的列表
        VUE_num_served_by_RSU_set = [VUE_decision_flag_full_matrix_row_sum[1] + VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[2] + VUE_decision_flag_full_matrix_row_sum[2+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[3] + VUE_decision_flag_full_matrix_row_sum[3+self.conf.RSU_num]] # RSU服务的用户数量集合
        beam_num_of_RSU_set = VUE_num_direct_served_by_RSU_set
        # ABS和RSU通过sub6，不是通过毫米波，所以这个RSU本地卸载用户就是毫米波波束个数
        overload_RSU_num = len([ele for ele in beam_num_of_RSU_set if ele > self.conf.beam_num_max])
        
        VUE_num_served_by_MBS = VUE_decision_flag_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE数
        VUE_distribution = [VUE_num_served_by_VUE] + VUE_num_direct_served_by_RSU_set + VUE_num_relay_served_by_RSU_set + \
                           VUE_num_served_by_RSU_set + [VUE_num_served_by_MBS]
        
        VUE_task_type_index_full_matrix = [[0 for i in range(self.conf.task_type_num)] for j in range(self.conf.VUE_num + self.conf.RSU_num + 1)]
        # 行为每个节点编号，列为任务类型编号
        local_task_type_index_set = []
        edge_task_type_index_set = []
        for VUE_index in self.VUE_with_task_index_set:
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 本地计算
                VUE_task_type_index_full_matrix[VUE_index][self.VUE_task_type_index_set[VUE_index]] += 1
                local_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            for RSU_index in self.conf.RSU_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][1 + RSU_index] == 1 or \
                   VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + RSU_index] == 1: # RSU计算
                    VUE_task_type_index_full_matrix[self.conf.VUE_num + RSU_index][self.VUE_task_type_index_set[VUE_index]] += 1
                    edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][-1] == 1: # MBS计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
        
        VUE_task_bit_size_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        VUE_task_computation_resource_requirement_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*8二维列表，表示VUE和本地/VUE/RSU/MBS的任务连接映射
        for VUE_index in self.VUE_with_task_index_set:
            for index in range(8): # 遍历本地，直连RSU，中继RSU和中继MBS
                if index == 1 and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                    # 注意此处的行序号，比如如果VUE1中继到VUE3，那么此时就是VEU_index=1，然后赋值VUE_task_computation_resource_requirement_full_matrix[3][1]
                if index in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                elif index != 1 and index not in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = self.VUE_task_computation_resource_requirement_set[VUE_index]
        
        VUE_task_bit_size_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_bit_size_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_bit_size_relay_served_by_RSU_set = VUE_task_bit_size_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # RSU中继服务的用户任务量集合
        VUE_task_bit_size_relay_served_by_MBS = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        VUE_task_bit_size_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set + [VUE_task_bit_size_relay_served_by_MBS])
        VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set)
        # ABS中继的总任务量
        
        VUE_task_computation_resource_requirement_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_computation_resource_requirement_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_computation_resource_requirement_served_by_RSU_set = [VUE_task_computation_resource_requirement_full_matrix_row_sum[1] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3 + self.conf.RSU_num]]
        # RSU中继服务的用户任务量集合
        VUE_task_computation_resource_requirement_served_by_MBS = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num]
        # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
        
        VX_distance_set = [[0 for i in range(1 + self.conf.RSU_num)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*(1+RSU_num)二维列表，前两列表示VUE到RSU的距离，最后一列表示VUE到ABS的距离
        for VUE_index in self.conf.VUE_index_set:
            VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - \
                                                                           np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])])) # 单位m
            VX_distance_set[VUE_index][-1] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.ABS_coordinate))
        
        AX_distance_set = [0]*(1 + self.conf.RSU_num)
        for RSU_index in self.conf.RSU_index_set:
            AX_distance_set[RSU_index] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.RSU_coordinate_set[RSU_index]))
        AX_distance_set[-1] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.MBS_coordinate))
        
        local_latency_set = [0]*self.conf.VUE_num
        RSU_direct_latency_set = [0]*self.conf.VUE_num
        RSU_relay_latency_set = [0]*self.conf.VUE_num
        MBS_relay_latency_set = [0]*self.conf.VUE_num
        VUE_latency_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*9二维列表
        relay_transmission_latency_sum = 0
               
        for VUE_index in self.VUE_with_task_index_set: # 遍历VUE
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                this_VUE_local_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                   self.conf.VUE_computing_resource) * 1e3 # 本地计算时延(ms)
                # 如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                local_latency_set[VUE_index] = this_VUE_local_computing_latency
                #print("local_latency_set[VUE_index]:", int(local_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][0] = int(local_latency_set[VUE_index])
                
            if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]: # 如果选择直连RSU
                VUE_direct_served_RSU_index = VUE_decision_flag_full_matrix[VUE_index].index(1) - 1 # 此VUE直连的RSU编号
                this_VR_distance = VX_distance_set[VUE_index][VUE_direct_served_RSU_index]
                this_VR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VR_distance ** (-self.conf.VR_power_decay_exponent), 10)
                this_VR_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_mmW_antenna_gain + self.conf.RSU_rx_mmW_antenna_gain + this_VR_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * self.conf.mmW_bandwidth, 10)
                """
                if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VR_transmission_rate = self.conf.mmW_bandwidth * math.log(1 + 10**(this_VR_SNR/10), 2)
                this_VR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VR_transmission_rate) * 1e3 # 单位为ms
                # 20+34+91-(20*math.log(4*math.pi*28*10**9 / (3*10**8), 10) + 10*2*math.log(200,10) + np.random.normal(loc=0.0, scale=4, size=None))
                # 如果任务为CA，(1e6 / 1.7e9) * 1000 = 0.57, 毫米波速度非常快
                
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] error")
                this_VUE_RSU_direct_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_RSU) * 1e3 # 单位为ms
                # 如果任务为CA，分配了50%计算资源，(1e6*150/(6e9*50/100))*1000 = 50 ms
                RSU_direct_latency_set[VUE_index] = this_VR_transmission_latency + this_VUE_RSU_direct_computing_latency
                #print("RSU_direct_latency_set[VUE_index]:", int(RSU_direct_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + VUE_direct_served_RSU_index] = int(RSU_direct_latency_set[VUE_index])
        
        latency_set = [ele for ele in (local_latency_set + RSU_direct_latency_set + RSU_relay_latency_set + MBS_relay_latency_set) if ele > 0] # 单位ms
        edge_latency_set = [ele for ele in (RSU_direct_latency_set + RSU_relay_latency_set + MBS_relay_latency_set) if ele > 0] # 单位ms
        latency_set_sum = round(sum(latency_set), 3)
        local_latency_if_set_sum = round(sum(self.local_latency_if_set), 3) # 如果本地计算的时延总和
        latency_set_max = round(max(latency_set), 3) # 最大用户时延值
        local_latency_if_set_max = round(max(self.local_latency_if_set), 3) # 如果本地计算的最大时延
        latency_max_interval = local_latency_if_set_max - latency_set_max # 本地计算模式和卸载模式的最大时延差，如果为正，则卸载效果好
        offloading_mode_gain_sum = int(local_latency_if_set_sum - latency_set_sum) # 如果本地时延与实际时延总和的差值，即选择卸载模式之后的增益
        
        offloading_mode_gain_set = [0]*self.conf.VUE_num # 每个用户的卸载增益
        offloading_mode_revised_gain_sum = 0 # 修改的增益总和。不同于offloading_mode_gain_sum，这个会对增益为负的用户做惩罚
        lowzero_gain_index_set = [] # 负增益的边缘节点编号
        good_gain_extra_score_sum = 0 # 正增益额外加的分
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:]) # 增益为正才好
                  
                if offloading_mode_gain_set[VUE_index] == 0:
                    offloading_mode_revised_gain_sum += -50 # 如果增益为0，则扣掉100？要不要扣？
                elif offloading_mode_gain_set[VUE_index] < 0: # 为负
                    if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]: # 直接RSU
                        lowzero_gain_index_set.append(VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num].index(1))
                    if 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]: # 中继RSU
                        lowzero_gain_index_set.append(self.conf.RSU_num + VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num].index(1))
                    if VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] == 1: # 中继MBS
                        lowzero_gain_index_set.append(2*self.conf.RSU_num)
                    
                    if episodes_count < self.conf.change_penalty_episode:
                        bad_gain_penalty0 = -400
                    else:
                        bad_gain_penalty0 = -600
                    if offloading_mode_gain_set[VUE_index] in Interval(-20, -1):
                        offloading_mode_revised_gain_sum += bad_gain_penalty0
                    elif offloading_mode_gain_set[VUE_index] in Interval(-50, -21):
                        offloading_mode_revised_gain_sum += bad_gain_penalty0 + 10*(offloading_mode_gain_set[VUE_index] + 20)
                    elif offloading_mode_gain_set[VUE_index] in Interval(-100, -51):
                        offloading_mode_revised_gain_sum += bad_gain_penalty0 + 10*(-30) + 5*(offloading_mode_gain_set[VUE_index] + 50) # 250+150+100+150
                    elif offloading_mode_gain_set[VUE_index] < -100:
                        offloading_mode_revised_gain_sum += bad_gain_penalty0 + 10*(-30) + 5*(-50) + 3*(offloading_mode_gain_set[VUE_index] + 100)
                        # 如果为-150， 400+300+250+150 = -1100
                    """"""
                elif offloading_mode_gain_set[VUE_index] > 0: # 为正
                    if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index] + 20 # 如果直接卸载到RSU
                        good_gain_extra_score_sum += 20
                    elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index] + 20 # 如果中继卸载到RSU
                        good_gain_extra_score_sum += 20
                    elif VUE_decision_flag_full_matrix[VUE_index][-1] == 1:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index] * 0.3 # 如果中继卸载到MBS
                        good_gain_extra_score_sum += -(offloading_mode_gain_set[VUE_index] * 0.7)
        
        
        offloading_mode_revised_gain_sum = int(offloading_mode_revised_gain_sum)
        zero_num_in_offloading_mode_gain_set = len([ele for ele in offloading_mode_gain_set if ele == 0]) # 增益为0的用户数
        lowzero_gains = [ele for ele in offloading_mode_gain_set if ele < 0] # 负增益集合
        if len(lowzero_gains) == 0:
            lowzero_gains_sum = 0
        elif len(lowzero_gains) > 0:
            lowzero_gains_sum = int(sum(lowzero_gains)) # 所有负增益的和
            offloading_mode_revised_gain_sum += -good_gain_extra_score_sum # 如果有负增益，则把正增益加的分全部扣了
        
        offloading_mode_revised_gain_sum_nor = max(min(round( (offloading_mode_revised_gain_sum - 800) / self.conf.reward_scale_factor, 4),  10), -10) # 裁剪，防止过大
        
        if len(edge_latency_set) > 0:
            edge_latency_set_max = max(edge_latency_set)
            if edge_latency_set_max >= 230:
                edge_latency_set_max_nor = 0
            if edge_latency_set_max in Interval(130, 229):
                edge_latency_set_max_nor = 0.1*(230 - edge_latency_set_max)
            elif edge_latency_set_max < 130:
                edge_latency_set_max_nor = 10
        else:
            edge_latency_set_max = 0
            edge_latency_set_max_nor = 0
        
        reward_if = 0.6*offloading_mode_revised_gain_sum_nor + 0.2*edge_latency_set_max_nor
        
        bad_flag = False
        
        #if (offloading_mode_revised_gain_sum < 600 or offloading_mode_gain_sum < 1500) and (lowzero_gains_sum < 0 or reward_temp_if_interval < 0):
        if offloading_mode_revised_gain_sum < 600 or offloading_mode_gain_sum < 1500:
            bad_flag = True
        if overload_RSU_num > 0:
            bad_flag = True
        if latency_max_interval < 0:
            bad_flag = True
        
        if bad_flag:
            reward_if = 0
        
        return reward_if


    def step_if2(self, action_set):
        latency_max_interval = 0
        zero_num_in_offloading_mode_gain_set = 0
        offloading_mode_gain_sum = 0
        bad_offloading_flag_num = 0
        RSU_empty_flag = 0
        MBS_empty_flag = 0
        generated_task_num_record = self.VUE_with_task_num  # 记录此数据return传给utils
        good_offloading_VUE_num = 0
        bad_offloading_flag_set = [0]*self.conf.bad_flag_num
        
        VUE_relay_computing_node_mapping_matrix = [[0 for i in range(2)] for j in range(self.conf.VUE_num)]
        # 存储中继计算节点编号；第一列表示中继VUE的编号；第2列表示中继RSU的编号
        VUE_decision_flag_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*9二维列表，第1列表示直接本地计算；第2~4列表示RSU的直连决策；
        # 后5~7列表示RSU中继决策；第8列表示MBS的中继决策；
        for VUE_index in self.VUE_with_task_index_set:
            if action_set[VUE_index] == 0: # 直接本地计算
                VUE_decision_flag_full_matrix[VUE_index][0] = 1
            elif action_set[VUE_index] in Interval(1, self.conf.RSU_num): # 如果决策值在这一区间，表示卸载到RSU
                the_RSU_index = action_set[VUE_index] - 1
                if the_RSU_index == int(self.VUE_RSU_index_mapping[VUE_index]): # 直接卸载RSU
                    VUE_decision_flag_full_matrix[VUE_index][1 + the_RSU_index] = 1 # int()保证列表索引为int
                    # 如果VUE_RSU_index_mapping[VUE_index]=0，则在VUE_decision_flag_full_matrix[VUE_index]中位于2+0列
                else: # 中继RSU
                    VUE_relay_computing_node_mapping_matrix[VUE_index][1] = the_RSU_index # 记录此VUE的中继RSU编号
                    VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + the_RSU_index] = 1
            elif action_set[VUE_index] == self.conf.RSU_num + 1: # 中继MBS
                VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] = 1
        VUE_decision_flag_full_matrix_row_sum = [sum(i) for i in zip(*VUE_decision_flag_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_num_served_by_VUE = VUE_decision_flag_full_matrix_row_sum[0] # 直接本地计算的VUE数
        VUE_num_direct_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1: 1+self.conf.RSU_num] # 每个RSU直接服务的VUE数，是一个长度为RSU_num的列表
        VUE_num_relay_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # 每个RSU中继服务的VUE数，长度为3的列表
        VUE_num_served_by_RSU_set = [VUE_decision_flag_full_matrix_row_sum[1] + VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[2] + VUE_decision_flag_full_matrix_row_sum[2+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[3] + VUE_decision_flag_full_matrix_row_sum[3+self.conf.RSU_num]] # RSU服务的用户数量集合
        beam_num_of_RSU_set = VUE_num_direct_served_by_RSU_set
        # ABS和RSU通过sub6，不是通过毫米波，所以这个RSU本地卸载用户就是毫米波波束个数
        
        VUE_num_served_by_MBS = VUE_decision_flag_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE数
        VUE_distribution = [VUE_num_served_by_VUE] + self.VUE_with_task_num_in_RSU_set + VUE_num_direct_served_by_RSU_set + VUE_num_relay_served_by_RSU_set + \
                           VUE_num_served_by_RSU_set + [VUE_num_served_by_MBS]
        
        
        
        VUE_task_type_index_full_matrix = [[0 for i in range(self.conf.task_type_num)] for j in range(self.conf.VUE_num + self.conf.RSU_num + 1)]
        # 行为每个节点编号，列为任务类型编号
        local_task_type_index_set = []
        edge_task_type_index_set = []
        for VUE_index in self.VUE_with_task_index_set:
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 本地计算
                VUE_task_type_index_full_matrix[VUE_index][self.VUE_task_type_index_set[VUE_index]] += 1
                local_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            for RSU_index in self.conf.RSU_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][1 + RSU_index] == 1 or \
                   VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + RSU_index] == 1: # RSU计算
                    VUE_task_type_index_full_matrix[self.conf.VUE_num + RSU_index][self.VUE_task_type_index_set[VUE_index]] += 1
                    edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][-1] == 1: # MBS计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
        
        VUE_task_bit_size_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        VUE_task_computation_resource_requirement_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*8二维列表，表示VUE和本地/VUE/RSU/MBS的任务连接映射
        for VUE_index in self.VUE_with_task_index_set:
            for index in range(8): # 遍历本地，直连RSU，中继RSU和中继MBS
                if index == 1 and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                    # 注意此处的行序号，比如如果VUE1中继到VUE3，那么此时就是VEU_index=1，然后赋值VUE_task_computation_resource_requirement_full_matrix[3][1]
                if index in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                elif index != 1 and index not in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = self.VUE_task_computation_resource_requirement_set[VUE_index]
        
        VUE_task_bit_size_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_bit_size_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_bit_size_relay_served_by_RSU_set = VUE_task_bit_size_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # RSU中继服务的用户任务量集合
        VUE_task_bit_size_relay_served_by_MBS = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        VUE_task_bit_size_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set + [VUE_task_bit_size_relay_served_by_MBS])
        VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set)
        # ABS中继的总任务量
        
        VUE_task_computation_resource_requirement_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_computation_resource_requirement_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_computation_resource_requirement_served_by_RSU_set = [VUE_task_computation_resource_requirement_full_matrix_row_sum[1] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3 + self.conf.RSU_num]]
        # RSU中继服务的用户任务量集合
        VUE_task_computation_resource_requirement_served_by_MBS = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num]
        # 索引[1 + 2*self.conf.RSU_num]为中继卸载到MBS的VUE任务量
        
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
        
        VX_distance_set = [[0 for i in range(1 + self.conf.RSU_num)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*(1+RSU_num)二维列表，前两列表示VUE到RSU的距离，最后一列表示VUE到ABS的距离
        for VUE_index in self.conf.VUE_index_set:
            VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - \
                                                                           np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])])) # 单位m
            VX_distance_set[VUE_index][-1] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.ABS_coordinate))
        
        AX_distance_set = [0]*(1 + self.conf.RSU_num)
        for RSU_index in self.conf.RSU_index_set:
            AX_distance_set[RSU_index] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.RSU_coordinate_set[RSU_index]))
        AX_distance_set[-1] = np.linalg.norm(np.array(self.conf.ABS_coordinate) - np.array(self.conf.MBS_coordinate))
        
        local_latency_set = [0]*self.conf.VUE_num
        RSU_direct_latency_set = [0]*self.conf.VUE_num
        RSU_relay_latency_set = [0]*self.conf.VUE_num
        MBS_relay_latency_set = [0]*self.conf.VUE_num
        VUE_latency_full_matrix = [[0 for i in range(8)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*9二维列表
        relay_transmission_latency_sum = 0
               
        for VUE_index in self.VUE_with_task_index_set: # 遍历VUE
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                this_VUE_local_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                   self.conf.VUE_computing_resource) * 1e3 # 本地计算时延(ms)
                # 如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                local_latency_set[VUE_index] = this_VUE_local_computing_latency
                #print("local_latency_set[VUE_index]:", int(local_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][0] = int(local_latency_set[VUE_index])
                
            if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]: # 如果选择直连RSU
                VUE_direct_served_RSU_index = VUE_decision_flag_full_matrix[VUE_index].index(1) - 1 # 此VUE直连的RSU编号
                this_VR_distance = VX_distance_set[VUE_index][VUE_direct_served_RSU_index]
                this_VR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VR_distance ** (-self.conf.VR_power_decay_exponent), 10)
                this_VR_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_mmW_antenna_gain + self.conf.RSU_rx_mmW_antenna_gain + this_VR_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * self.conf.mmW_bandwidth, 10)
                """
                if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VR_transmission_rate = self.conf.mmW_bandwidth * math.log(1 + 10**(this_VR_SNR/10), 2)
                this_VR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VR_transmission_rate) * 1e3 # 单位为ms
                # 20+34+91-(20*math.log(4*math.pi*28*10**9 / (3*10**8), 10) + 10*2*math.log(200,10) + np.random.normal(loc=0.0, scale=4, size=None))
                # 如果任务为CA，(1e6 / 1.7e9) * 1000 = 0.57, 毫米波速度非常快
                
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] error")
                this_VUE_RSU_direct_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_RSU) * 1e3 # 单位为ms
                # 如果任务为CA，分配了50%计算资源，(1e6*150/(6e9*50/100))*1000 = 50 ms
                RSU_direct_latency_set[VUE_index] = this_VR_transmission_latency + this_VUE_RSU_direct_computing_latency
                #print("RSU_direct_latency_set[VUE_index]:", int(RSU_direct_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + VUE_direct_served_RSU_index] = int(RSU_direct_latency_set[VUE_index])
                
            elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]: # 如果选择中继到RSU
                VUE_relay_served_RSU_index = VUE_relay_computing_node_mapping_matrix[VUE_index][1] # 此VUE中继的RSU编号
                this_VA_distance = VX_distance_set[VUE_index][-1]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/37e6)*1000 = 27 ms
                
                this_AR_distance = AX_distance_set[VUE_relay_served_RSU_index]
                this_AR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_AR_distance ** (-self.conf.AR_power_decay_exponent), 10)
                if VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS > 0:
                    this_RSU_downlink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS error")
                this_AR_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.RSU_rx_sub6_antenna_gain + this_AR_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_RSU_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AR_transmission_rate = this_RSU_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AR_SNR/10), 2)
                this_AR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AR_transmission_rate) * 1e3 # 多个VUE的任务从ABS一起传输到RSU
                # 如果任务为CA， (1e6/96e6)*1000 = 10 ms
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] error")
                this_VUE_RSU_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_RSU) * 1e3
                RSU_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AR_transmission_latency + this_VUE_RSU_relay_computing_latency
                #print("RSU_relay_latency_set[VUE_index]:", int(RSU_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + self.conf.RSU_num + VUE_relay_served_RSU_index] = int(RSU_relay_latency_set[VUE_index])
                relay_transmission_latency_sum += this_VA_transmission_latency + this_AR_transmission_latency
                
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] == 1: # 如果选择中继到MBS
                this_VA_distance = VX_distance_set[VUE_index][-1]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB +\
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                
                this_AM_distance = AX_distance_set[-1]
                this_AM_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_AM_distance ** (-self.conf.AM_power_decay_exponent), 10)
                MBS_downlink_bandwidth_allocated_by_ABS = self.conf.sub6_bandwidth # MBS独占AM带宽
                this_AM_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_AM_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * MBS_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AM_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AM_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AM_transmission_rate = MBS_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AM_SNR/10), 2)
                this_AM_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AM_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/126e6)*1000 = 7.9 ms
                if VUE_task_computation_resource_requirement_served_by_MBS > 0:
                    this_VUE_computing_resource_allocated_by_MBS = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_MBS) * \
                                                                   self.MBS_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_MBS error")
                this_VUE_MBS_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_MBS) * 1e3
                MBS_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AM_transmission_latency + this_VUE_MBS_relay_computing_latency
                #print("MBS_relay_latency_set[VUE_index]:", int(MBS_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][-1] = int(MBS_relay_latency_set[VUE_index])
                relay_transmission_latency_sum += this_VA_transmission_latency + this_AM_transmission_latency
                
        latency_set = [ele for ele in (local_latency_set + RSU_direct_latency_set + RSU_relay_latency_set + MBS_relay_latency_set) if ele > 0] # 单位ms
        latency_set_sum = round(sum(latency_set), 3)
        local_latency_if_set_sum = round(sum(self.local_latency_if_set), 3) # 如果本地计算的时延总和
        latency_set_max = round(max(latency_set), 3) # 最大用户时延值
        local_latency_if_set_max = round(max(self.local_latency_if_set), 3) # 如果本地计算的最大时延
        latency_max_interval = local_latency_if_set_max - latency_set_max # 本地计算模式和卸载模式的最大时延差，如果为正，则卸载效果好
        offloading_mode_gain_sum = local_latency_if_set_sum - latency_set_sum # 如果本地时延与实际时延总和的差值，即选择卸载模式之后的增益
        
        offloading_mode_gain_set = [0]*self.conf.VUE_num # 每个用户的卸载增益
        offloading_mode_revised_gain_sum = 0 # 修改的增益总和。不同于offloading_mode_gain_sum，这个会对增益为负的用户做惩罚
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:]) # 增益为正才好
                if offloading_mode_gain_set[VUE_index] == 0:
                    offloading_mode_revised_gain_sum += 0 # 如果增益为0，则扣掉100？要不要扣？
                elif offloading_mode_gain_set[VUE_index] < 0: # 为负
                    offloading_mode_revised_gain_sum += 0 # 如果增益为负，则扣分
                elif offloading_mode_gain_set[VUE_index] > 0: # 为正
                    if VUE_decision_flag_full_matrix[VUE_index][-1] == 1:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index] + 0 # 如果卸载到MBS
                    elif 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index] + 0 # 如果直接卸载到RSU，加分
                    else:
                        offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                    
        zero_num_in_offloading_mode_gain_set = len([ele for ele in offloading_mode_gain_set if ele == 0]) # 增益为0的用户数
        
        action_set_if_not_relay = [0]*self.VUE_with_task_num
        action_set_all_direct_RSU = [0]*self.VUE_with_task_num
        for VUE_index in self.VUE_with_task_index_set:
            if action_set[VUE_index] in Interval(1 + self.conf.RSU_num, 1 + 2*self.conf.RSU_num): # 中继卸载到RSU/MBS
                action_set_if_not_relay[VUE_index] = self.VUE_RSU_index_mapping[VUE_index]
            else:
                action_set_if_not_relay[VUE_index] = action_set[VUE_index]
            
            action_set_all_direct_RSU[VUE_index] = self.VUE_RSU_index_mapping[VUE_index]
        
        offloading_mode_gain_sum_if_not_relay, offloading_mode_gain_set_if_not_relay = self.step_if(action_set_if_not_relay)
        # 如果agent的选择中继的用户不选择中继，而不选择中继的用户保持action不变，计算其总增益
        offloading_mode_gain_sum_if_all_direct_RSU, offloading_mode_gain_set_if_all_direct_RSU = self.step_if(action_set_all_direct_RSU)
        # 如果所有用户都直接卸载到RSU，其总增益
        
        #offloading_mode_revised_gain_sum_exp = round(math.pow(self.conf.reward_exp_factor2, offloading_mode_revised_gain_sum / 3000) - 0.4, 4)
        offloading_mode_revised_gain_sum_nor = min(round( (offloading_mode_revised_gain_sum - 2000) / 90, 4), 12) # 裁剪，防止过大
        offloading_mode_revised_gain_sum_nor = max(offloading_mode_revised_gain_sum_nor, -0.1)
        # offloading_mode_revised_gain_sum越大越好，大概在[-2000, 2000]。  reward_exp_factor2=1.5，单调递增。
        
        
        reward = offloading_mode_revised_gain_sum_nor
        
        bad_offloading_flag_set = [0]*self.conf.bad_flag_num
        """"""
        if offloading_mode_gain_sum == 0 or min(offloading_mode_gain_set) < 0:
            bad_offloading_flag_num += 1
        
        if offloading_mode_gain_sum < max(offloading_mode_gain_sum_if_not_relay, offloading_mode_gain_sum_if_all_direct_RSU):
            bad_offloading_flag_num += 1
        
        if offloading_mode_gain_sum < 1600:
            bad_offloading_flag_num += 1
        
        """
        if len([ele for ele in beam_num_of_RSU_set if ele > self.conf.beam_num_max]) > 0:
            bad_offloading_flag_num += 1
        
        
        
        if 0 in VUE_num_served_by_RSU_set:
            bad_offloading_flag_num += 1
        
        if latency_max_interval < 0:
            bad_offloading_flag_num += 1
        """
        return bad_offloading_flag_num
