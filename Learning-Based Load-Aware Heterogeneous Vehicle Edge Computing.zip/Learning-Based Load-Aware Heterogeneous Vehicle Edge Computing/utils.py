import numpy as np
import torch
from torch.distributions import one_hot_categorical
import time 
import threading

class RolloutWorker:
    def __init__(self, env, agents, conf):
        super().__init__()
        self.conf = conf
        self.agents = agents
        self.env = env
        self.episode_limit = conf.episode_limit
        self.n_actions = conf.n_actions # conf.n_actions=10
        self.n_agents = conf.n_agents
        self.state_shape = conf.state_shape
        self.obs_shape = conf.obs_shape

        self.anneal_epsilon = conf.anneal_epsilon
        self.end_epsilon = conf.end_epsilon
        print('Rollout Worker inited!')
        
    def generate_episode(self, episodes_count, epsilon, episode_num=None, evaluate=False): # evaluate是啥？
        o, u, r, s, avail_u, u_onehot, terminate, padded = [], [], [], [], [], [], [], []
        self.env.reset() # 重置环境 # 上面由于main函数中传入的实参episode_idx（形参episode_num）为0，则环境已被关闭，现在又重置环境。所以上面关闭环境是刷新？
        terminated = False
        episode_reward = 0
        last_action = np.zeros((self.conf.n_agents, self.conf.n_actions)) # 初始化last_action，由智能体个数和动作个数决定
        # last_action: numpy array of previous actions for each agent，用来存储每个智能体上一次执行的动作
        self.agents.policy.init_hidden(1) # agents类函数中调用policy的init_hidden(1)函数，输入参数1是初始化？
        epsilon = 0 if evaluate else epsilon
        
        ##### 每回合刷新
        nt_step_rewards_in_this_episode = []
        nt_step_zero_offloading_gains_in_this_episode = []
        nt_step_offloading_gain_sums_in_this_episode = []
        nt_step_offloading_revised_gain_sums_in_this_episode = []
        nt_step_MBS_relay_VUE_num_in_this_episode = []
        
        nt_step_relay_latency_maxs_in_this_episode = []
        nt_step_latency_set_maxs_in_this_episode = []
        nt_step_latency_set_sums_in_this_episode = []
        
        nt_step_latency_max_intervals_in_this_episode = []
        nt_step_RSU_empty_flags_in_this_episode = []
        nt_step_MBS_empty_flags_in_this_episode = []
        
        nt_step_VUE_distribution_in_RSU_in_this_episode = []
        nt_step_RSU_direct_VUE_num_in_this_episode = []
        nt_step_RSU_relay_VUE_num_in_this_episode = []
        nt_step_RSU_VUE_num_in_this_episode = []
        
        t_flag_in_this_episode = 0
        moving_nt_step_num_in_this_episode = 0
        t_reward_in_this_episode = 0
        
        lowzero_gain_count_in_this_episode = 0
        lowzero_reward_temp_if_interval_count_in_this_episode = 0
        
        action_masking_count_set_in_this_episode = []
        
        episode_data_record = [nt_step_rewards_in_this_episode, nt_step_zero_offloading_gains_in_this_episode, nt_step_offloading_gain_sums_in_this_episode, \
                               nt_step_offloading_revised_gain_sums_in_this_episode, nt_step_MBS_relay_VUE_num_in_this_episode, \
                               nt_step_relay_latency_maxs_in_this_episode, nt_step_latency_set_maxs_in_this_episode, nt_step_latency_set_sums_in_this_episode, \
                               nt_step_latency_max_intervals_in_this_episode, nt_step_RSU_empty_flags_in_this_episode, nt_step_MBS_empty_flags_in_this_episode, \
                               nt_step_VUE_distribution_in_RSU_in_this_episode, nt_step_RSU_direct_VUE_num_in_this_episode, \
                               nt_step_RSU_relay_VUE_num_in_this_episode, nt_step_RSU_VUE_num_in_this_episode, \
                               t_flag_in_this_episode, moving_nt_step_num_in_this_episode, t_reward_in_this_episode, \
                               lowzero_gain_count_in_this_episode, lowzero_reward_temp_if_interval_count_in_this_episode, \
                               action_masking_count_set_in_this_episode]
        
        step = 0
        while not terminated and step < self.episode_limit: # episode_limit=200是每回合的步数阈值，一回合要么遇到终止状态，要么步数大于等于200，此回合就结束
            obs = np.array(self.env.obs) # 此obs变量是一个长度为VUE_num=7，包含所有agent的obs的列表，列表第i个元素是第i个智能体的obs，是一个长度为obs_shape=3的一维array，比如array([1,2,3])
            # 例如，obs=[array([1,1]), array([2,2]), array([3,3])]
            state = self.env.state
            #print("obs:", obs)
            #print("state:", state)
            actions, avail_actions, actions_onehot = [], [], []
            q_value_set = []
            for agent_id in range(self.n_agents): # 对每一个智能体循环
                avail_action = self.env.avail_actions[agent_id]
                #avail_action = [1]*self.conf.n_actions
                
                action, actions_idx, q_value = self.agents.choose_action(obs[agent_id], last_action[agent_id], agent_id, avail_action, epsilon, evaluate) # epsilon=start_epsilon=1
                q_value_set.append(q_value)
                #print("obs[agent_id]:", obs[agent_id])
                # choose_action函数的输入为(第agent_id个智能体的观测obs；第agent_id个智能体的)上一个动作last_action；智能体编号；第agent_id个智能体的可用智能体；???）
                # 生成动作的onehot编码
                action_onehot = np.zeros(self.n_actions) # n_actions=10， action_onehot是一个长度为10的一维数组
                action_onehot[action] = 1
                actions.append(action) # actions的每个元素是一个标量
                actions_onehot.append(action_onehot) # actions_onehot的每个元素是长度为n_actions的一个array
                avail_actions.append(avail_action)
                last_action[agent_id] = action_onehot # 将第agent_id个智能体这次采取的onehot编码动作赋值给last_action
            
            #bad_offloading_flag_num = self.env.step_if2(actions)
            
            action_masking_count = 0
            """
            while step < 11 and epsilon < 0.2 and bad_offloading_flag_num > 0 and action_masking_count <= 50: # 动作不行就重新选动作
            #while step < 11 and bad_offloading_flag_num > 0 and action_masking_count <= 300:
                actions, actions_onehot = [], []
                for agent_id in range(self.n_agents): # 对每一个智能体循环
                    avail_action = self.env.avail_actions[agent_id]
                    if 1 in avail_action:
                        if np.random.uniform() < epsilon: # 概率贪婪策略
                            action = np.random.choice(actions_idx)
                        else:
                            action = torch.argmax(q_value_set[agent_id])
                        action_onehot = np.zeros(self.n_actions) # n_actions=10， action_onehot是一个长度为10的一维数组
                        action_onehot[action] = 1
                        actions.append(action) # actions的每个元素是一个标量
                        actions_onehot.append(action_onehot) # actions_onehot的每个元素是长度为n_actions的一个array
                        last_action[agent_id] = action_onehot # 将第agent_id个智能体这次采取的onehot编码动作赋值给last_action
                    else:
                        action = 0
                        action_onehot = np.zeros(self.n_actions) # n_actions=10， action_onehot是一个长度为10的一维数组
                        action_onehot[action] = 1
                        actions.append(action) # actions的每个元素是一个标量
                        actions_onehot.append(action_onehot) # actions_onehot的每个元素是长度为n_actions的一个array
                        last_action[agent_id] = action_onehot # 将第agent_id个智能体这次采取的onehot编码动作赋值给last_action
                #print("actions:", actions)
                bad_offloading_flag_num = self.env.step_if2(actions)
                action_masking_count += 1
                #if action_masking_count == 51:
                #    print("action_masking_count:", [action_masking_count, bad_offloading_flag_num])
            """
            reward, terminated, return_part = self.env.step(episodes_count, step, actions) # 在环境中执行动作，获得奖励
            
            return_part = [round(reward, 2)] + return_part
            if not terminated: # 非终止态
                for index in range(len(episode_data_record) - 6):
                    episode_data_record[index].append(return_part[index])
                
            if terminated:
                if 1 in return_part[-3]: # 如果有1，那一定是回合异常终止
                    episode_data_record[-6] = return_part[-3].index(1)
                else: # 如果没1，则正常终止
                    episode_data_record[-6] = self.conf.bad_flag_num
                
                episode_data_record[-5] = step # 此时step还没有自增1，因此就是非终态总步数
                episode_data_record[-4] = reward
                episode_data_record[-3] = return_part[-2]
                #print("return_part[-2]:", return_part[-2])
                episode_data_record[-2] = return_part[-1]
            
            # 最终的reward应该是一个联合奖励，不是各自agent分别获得奖励
            o.append(obs) # obs是一维列表，列表每个元素为长度obs_shape的一维array
            s.append(state) # state是长度为state_shape的一维array
            u.append(np.reshape(actions, [self.n_agents, 1])) # 将一维列表actions重组为n_agents*1的二维数组。例如：[1,2,3]变成array([[1],[2],[3]])
            # u的每个元素为shape(n_agents,1)的二维array
            u_onehot.append(actions_onehot) # 一个actions_onehot二维列表为n_agents*n_actions
            avail_u.append(avail_actions)
            r.append([reward / 10])
            terminate.append([terminated])
            padded.append([0.]) # 这个是啥？？？
            episode_reward = round(episode_reward + reward, 3) # 这一回合的奖励累积，循环结束就是这一回合的总奖励
            step += 1 # 步数迭代 # 这个while循环是按步数迭代，每一次循环就是一步，这个循环终止了就是一个回合？
            
            if self.conf.epsilon_anneal_scale == 'step':
                epsilon = epsilon - self.anneal_epsilon if epsilon > self.end_epsilon else epsilon
            """"""
            episode_data_record[-1].append(action_masking_count)
        
        episode_data_record[-1] = [ele for ele in episode_data_record[-1] if ele > 0]
        if len(episode_data_record[-1]) > 0:
            episode_data_record[-1] = [step, episode_data_record[-1]]
        else:
            episode_data_record[-1] = [step]
        
        if step == 12: terminated = False
        # 最后一个动作 # 跟上面的while循环结合起来看，如果不满足循环条件，此回合达到终止状态或者超过最大步数阈值了就执行最后下述代码
        o.append(obs) # 跳出上面while循环前的最后的obs数据。即这一回合最后的next_obs
        s.append(state) # 跳出上面while循环前的最后的state数据。即这一回合最后的next_state
        o_ = o[1:] # list[a:]，对列表切片，从索引a开始取值形成新列表。
        s_ = s[1:]
        o = o[:-1] # 去掉o的最后一个元素
        s = s[:-1]
        # 为啥分别对这四个切掉第一个元素或切掉最后一个元素？？？
        
        # 当step<self.episode_limit时，输入数据加padding # ??? 这是啥意思
        # 应该是训练过程中都安装最大步数的数据来训练，统一格式。episode_limit=200，比如一回合的训练数据都是长度为200的一维数组，
        # 那么如果某一回合步数不够，则用零填充形成长度为200的一维数组
        avail_actions = []
        for agent_id in range(self.n_agents):
            avail_action = self.env.avail_actions[agent_id]
            avail_actions.append(avail_action)
        avail_u.append(avail_actions)
        avail_u_ = avail_u[1:]
        avail_u = avail_u[:-1]
        
        """
        rr = np.array(r).flatten()
        r_max_in_this_episode = np.min(rr) if np.max(abs(rr)) == abs(np.min(rr)) else np.max(rr)
        rr = rr / abs(r_max_in_this_episode)
        rr = np.expand_dims(rr, axis=1)
        r = rr.tolist()
        """
        for i in range(step, self.episode_limit): # 对于[step, self.episode_limit]这一范围，填充零元素
            o.append(np.zeros((self.n_agents, self.obs_shape))) # obs_shape是一个agent的观测数据的长度，而上面的obs = self.env.get_obs()是所有agents拼接起来的数据长度
            # o.append(obs)中的obs是一个一维列表，为什么此处添加的零元素是二维array?
            # 假如n_agents=2, obs_shape=2; o的第一个元素为[np.array([1,1]), np.array([2,2])]，每个agent的obs为一个长度为2的array，这个列表有两个array
            # 第二个元素为[np.array([3,3]), np.array([4,4])]，两个列表组成新列表为[[array([1, 1]), array([2, 2])], [array([3, 3]), array([4, 4])]]
            # 然后添加0元素.append(np.zeros((2, 2)))=   [[array([1, 1]), array([2, 2])], [array([3, 3]), array([4, 4])], array([[0., 0.], [0., 0.]])]
            # 零元素和前面的有值元素不统一
            u.append(np.zeros([self.n_agents, 1]))
            s.append(np.zeros(self.state_shape)) # state_shape就是所有agents的总的state拼接后的数组长度。state_shape=61
            # 这一句创建了长度为state_shape的一维数组
            r.append([0.])
            o_.append(np.zeros((self.n_agents, self.obs_shape)))
            s_.append(np.zeros(self.state_shape))
            u_onehot.append(np.zeros((self.n_agents, self.n_actions)))
            avail_u.append(np.zeros((self.n_agents, self.n_actions)))
            avail_u_.append(np.zeros((self.n_agents, self.n_actions)))
            padded.append([1.]) # 上面while循环中是填0，这儿为什么是填1？？？
            terminate.append([1.]) # 终止标志也填1？？？
        
        # 用字典统计存储这一回合的所有数据。dict里面等号前面就是key，等号后面就是key的值
        # 比如，o=[1,1]; s=[2,2]；episode={'o':[1,1], 's':[2,2]}
        #print("o:", o)
        episode = dict(
                    o=o.copy(),
                    s=s.copy(),
                    u=u.copy(),
                    r=r.copy(),
                    o_=o_.copy(),
                    s_=s_.copy(),
                    avail_u=avail_u.copy(),
                    avail_u_=avail_u_.copy(),
                    u_onehot=u_onehot.copy(),
                    padded = padded.copy(),
                    terminated = terminate.copy()
                )
        for key in episode.keys(): # 这个循环把字典的所有值变换为array，episode={'o':array([[1,1]]), 's':array([[2,2]])}
            episode[key] = np.array([episode[key]])
        #print("episode_reward:",     round(episode_reward, 2))
        episode_data_return = [episode, episode_reward, episode_data_record, evaluate]
        return episode_data_return
        # 返回这一回合的数据

class ReplayBuffer:
    def __init__(self, conf):
        self.conf = conf
        self.episode_limit = conf.episode_limit
        self.n_actions = conf.n_actions
        self.n_agents = conf.n_agents
        self.state_shape = conf.state_shape
        self.obs_shape = conf.obs_shape
        self.size = conf.buffer_size # buffer_size=100

        self.current_idx = 0
        self.current_size = 0

        self.buffers = {'o': np.empty([self.size, self.episode_limit, self.n_agents, self.obs_shape]),
                        # 四维数组，倒着看，前两维是所有agent的obs_shape，n*agents*obs_shape; 随后是一回合的所有步数的所有agent的obs_shape
                        # 最后是size=100个buffer的所有步数的所有agent的obs_shape，size就是回合数，一个回合的数据占用了一个buffer
                        # [self.episode_limit, self.n_agents, self.obs_shape]就是上面一个episode字典的数据，然后前面加上size维度，就是size个episode的数据
                        # 通过empty()初始化的数组元素值是随机的，例如第一维[0.00000000e+000, 6.95301869e-310, 4.50587869e-321, nan, 1.12646967e-321]
                        'u': np.empty([self.size, self.episode_limit, self.n_agents, 1]),    
                        's': np.empty([self.size, self.episode_limit, self.state_shape]),    
                        'r': np.empty([self.size, self.episode_limit, 1]),    
                        'o_': np.empty([self.size, self.episode_limit, self.n_agents, self.obs_shape]),  
                        's_': np.empty([self.size, self.episode_limit, self.state_shape]),
                        'avail_u': np.empty([self.size, self.episode_limit, self.n_agents, self.n_actions]),    
                        'avail_u_': np.empty([self.size, self.episode_limit, self.n_agents, self.n_actions]),  
                        'u_onehot': np.empty([self.size, self.episode_limit, self.n_agents, self.n_actions]),    
                        'padded': np.empty([self.size, self.episode_limit, 1]),    
                        'terminated': np.empty([self.size, self.episode_limit, 1]),    
            }
        self.lock = threading.Lock() # 为啥会加线程？？？
        print("Replay Buffer inited!")

    def store_episode(self, episode_batch):
        batch_size = episode_batch['o'].shape[0] # 200 # 一个episode字典的'o'的维度是self.episode_limit*self.n_agents*self.obs_shape=200*3*42
        # episode_batch是所有回合的数据压缩后形成的，回合数n_eposodes=1,因此维度是(n_eposodes-1+self.episode_limit)*self.n_agents*self.obs_shape=200*3*42
        # 因此batch_size=200
        
        with self.lock:
            idxs = self._get_storage_idx(inc=batch_size) # buffers['o']包括size=100个buffer的数据，buffers['o'][idx]是编号为idx的这个buffer的数据，一个buffer就是一个回合的数据
            self.buffers['o'][idxs] = episode_batch['o']
            self.buffers['u'][idxs] = episode_batch['u']
            self.buffers['s'][idxs] = episode_batch['s']
            self.buffers['r'][idxs] = episode_batch['r']
            self.buffers['o_'][idxs] = episode_batch['o_']
            self.buffers['s_'][idxs] = episode_batch['s_']
            self.buffers['avail_u'][idxs] = episode_batch['avail_u']
            self.buffers['avail_u_'][idxs] = episode_batch['avail_u_']
            self.buffers['u_onehot'][idxs] = episode_batch['u_onehot']
            self.buffers['padded'][idxs] = episode_batch['padded']
            self.buffers['terminated'][idxs] = episode_batch['terminated']

    def sample(self, batch_size): # batch_size=conf.batch_size=4
        temp_buffer = {}
        idx = np.random.randint(0, self.current_size, batch_size) # 取batch_size=4个在[0,self.current_size)的随机整数值，比如np.array([0,1,0,2])
        for key in self.buffers.keys():
            temp_buffer[key] = self.buffers[key][idx] # idx是长度为batch_size的一维数组，以此为索引从buffers中取元素。即取出在buffers['o']中以idx中元素值为索引的数据
            # buffers['o']包括size=100个buffer的数据，idx=np.array([0,1,0,2])，就是取出buffers['o']中索引为0，1，0，2的四个数据，即这四个回合的数据
        return temp_buffer # 这是从buffers中随机采样的部分buffer数据

    def _get_storage_idx(self, inc=None): # 这个函数没看懂？？？
        inc = inc or 1
        # inc传进来的是def store_episode中的batch_size=episode_limit，self.size=conf.buffer_size
        # self.current_idx在每次进入这个函数时是会变的，第一次值为0
        if self.current_idx + inc <= self.size:
            idx = np.arange(self.current_idx, self.current_idx+inc) # 生成一个一维递增列表，比如array([0,1,2])
            self.current_idx += inc
        elif self.current_idx < self.size:
            overflow = inc - (self.size - self.current_idx)
            idx_a = np.arange(self.current_idx, self.size)
            idx_b = np.arange(0, overflow)
            idx = np.concatenate([idx_a, idx_b])
            self.current_idx = overflow
        else:
            idx = np.arange(0, inc)
            self.current_idx = inc
        self.current_size = min(self.size, self.current_size + inc)
        if inc == 1:
            idx = idx[0]
        return idx
