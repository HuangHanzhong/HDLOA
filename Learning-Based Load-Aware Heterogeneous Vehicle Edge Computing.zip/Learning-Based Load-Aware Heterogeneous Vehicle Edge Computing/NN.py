import torch.nn as nn
import torch
import torch.nn.functional as F

# DRQN类参考：https://zhuanlan.zhihu.com/p/203405689
# super()函数表示DRQN类继承自nn.Module类。DRQN类完成神经网络构建，其中，__init__函数用于创建子模块，forward函数用于拼接子模块
class DRQN(nn.Module): # DRQN是单个智能体的网络模型
    def __init__(self, input_shape, conf): # input_shape=21+7+301=329
        super(DRQN, self).__init__()
        self.conf = conf
        self.fc1 = nn.Linear(input_shape, conf.drqn_hidden_dim) # nn.Linear()设置网络中的全连接层，需要注意的是全连接层的输入与输出都是二维张量
        # input_shape应该是状态输入向量
        self.rnn = nn.GRUCell(conf.drqn_hidden_dim, conf.drqn_hidden_dim) # 门控循环单元GRU
        # agent_network，采用循环神经网络GRU，上一回合输出的隐藏做为当前回合的输入。
        self.fc2 = nn.Linear(conf.drqn_hidden_dim, conf.n_actions) # 输出为动作个数，n_actions=10（其赋值在main函数中）

    def forward(self, obs, hidden_state):
        x = F.relu(self.fc1(obs)) # obs为1*309的二维tensor
        h_in = hidden_state.reshape(-1, self.conf.drqn_hidden_dim)
        h = self.rnn(x, h_in)
        q = self.fc2(h)
        return q, h

class QMIXNET(nn.Module):
    def __init__(self, conf):
        super(QMIXNET, self).__init__()
        """
        生成的hyper_w1需要是一个矩阵，但是torch NN的输出只能是向量；
        因此先生成一个（行*列）的向量，再reshape
        """
        """
        因为生成的hyper_w1需要是一个矩阵，而pytorch神经网络只能输出一个向量，
        所以就先输出长度为需要的 矩阵行*矩阵列 的向量，然后再转化成矩阵
        
        args.n_agents是使用hyper_w1作为参数的网络的输入维度，args.qmix_hidden_dim是网络隐藏层参数个数
        从而经过hyper_w1得到(经验条数，args.n_agents * args.qmix_hidden_dim)的矩阵
        """
        # print(conf.state_shape)
        self.conf = conf
        if self.conf.two_hyper_layers:
            self.hyper_w1 = nn.Sequential(nn.Linear(self.conf.state_shape, self.conf.hyper_hidden_dim),
                nn.ReLU(),
                nn.Linear(self.conf.hyper_hidden_dim, self.conf.n_agents*self.conf.qmix_hidden_dim))
            # 经过hyper_w2得到(经验条数, 1)的矩阵
            self.hyper_w2 = nn.Sequential(nn.Linear(self.conf.state_shape, self.conf.hyper_hidden_dim),
                nn.ReLU(),
                nn.Linear(self.conf.hyper_hidden_dim, self.conf.qmix_hidden_dim))
        else:
            self.hyper_w1 = nn.Linear(self.conf.state_shape, self.conf.n_agents*self.conf.qmix_hidden_dim)
            # 经过hyper_w2得到(经验条数, 1)的矩阵
            self.hyper_w2 = nn.Linear(self.conf.state_shape, self.conf.qmix_hidden_dim*1)
        
        # hyper_w1得到的(经验条数，args.qmix_hidden_dim)矩阵需要同样维度的hyper_b1
        self.hyper_b1 = nn.Linear(self.conf.state_shape, self.conf.qmix_hidden_dim)
        # hyper_w2得到的(经验条数，1)的矩阵需要同样维度的hyper_b1
        self.hyper_b2 = nn.Sequential(nn.Linear(self.conf.state_shape, self.conf.qmix_hidden_dim),
                        nn.ReLU(), nn.Linear(self.conf.qmix_hidden_dim, 1))

    # input: (batch_size, n_agents, qmix_hidden_dim)
    # q_values: (episode_num, max_episode_len, n_agents)
    # states shape: (episode_num, max_episode_len, state_shape)
    def forward(self, q_values, states): # states的shape为(episode_num, max_episode_len， state_shape)
        # 传入的q_values是三维的，shape为(episode_num, max_episode_len， n_agents)
        # print(self.conf.state_shape)
        episode_num = q_values.size(0)
        q_values = q_values.view(-1, 1, self.conf.n_agents) # (episode_num * max_episode_len, 1, n_agents) = (1920,1,5) # q_values似乎没变？
        states = states.reshape(-1, self.conf.state_shape) # (episode_num * max_episode_len, state_shape) # states降了第一维

        w1 = torch.abs(self.hyper_w1(states))  # (1920, 160)
        b1 = self.hyper_b1(states) # (1920, 32)
        w1 = w1.view(-1, self.conf.n_agents, self.conf.qmix_hidden_dim) # (1920, 5, 32)
        b1 = b1.view(-1, 1, self.conf.qmix_hidden_dim) # (1920, 1, 32)

        hidden = F.elu(torch.bmm(q_values, w1) + b1) # (1920, 1, 32)

        w2 = torch.abs(self.hyper_w2(states)) # (1920, 32)
        b2 = self.hyper_b2(states) # (1920, 1)
        w2 = w2.view(-1, self.conf.qmix_hidden_dim, 1) # (1920, 32, 1)
        b2 = b2.view(-1, 1, 1) # (1920, 1， 1)

        q_total = torch.bmm(hidden, w2) + b2 # (1920, 1, 1)
        q_total = q_total.view(episode_num, -1, 1) # (32, 60, 1)

        return q_total
