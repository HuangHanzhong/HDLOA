import torch
import os 
from NN import DRQN, QMIXNET

# import sys
# sys.setrecursionlimit(100000) #例如这里设置为十万 

class QMIX:
    
    def __init__(self, conf):
        self.conf = conf
        self.device = self.conf.device # conf.device指定CPU或GPU
        self.n_actions = self.conf.n_actions
        self.n_agents = self.conf.n_agents
        self.state_shape = self.conf.state_shape
        self.obs_shape = self.conf.obs_shape
        input_shape = self.obs_shape

        # print(self.device, self.n_actions, self.n_agents, self.state_shape, self.obs_shape, input_shape)

        # DRQN 的参数
        if self.conf.last_action:
            input_shape += self.n_actions
        if self.conf.reuse_network: 
            input_shape += self.n_agents
        
        # NET
        # 将DRQN和QMIXNET两个类实例化的对象赋值给QMIX类的属性self.
        self.eval_drqn_net = DRQN(input_shape, self.conf).to(self.device) # 建立单智能体的评估网络
        self.target_drqn_net = DRQN(input_shape, self.conf).to(self.device) # 建立单智能体的目标网络

        self.eval_qmix_net = QMIXNET(self.conf).to(self.device) # 建立混合训练的评估网络
        self.target_qmix_net = QMIXNET(self.conf).to(self.device) # 建立混合训练的目标网络
        
        self.model_load_source_path = self.conf.env_name + conf.policy_name + self.conf.last_test_name + self.conf.model_dir
        self.model_dir = self.conf.env_name + conf.policy_name + self.conf.test_name + self.conf.model_dir # conf.model_dir = './models/';  conf.map_name = '3s_vs_4z'. 
        # 这是文件目录？
        
        if self.conf.load_model:
            if os.path.exists(self.model_load_source_path + '/' + str(self.conf.saved_model_index) + '_drqn_net_params.pkl'): # 判断文件是否存在
                drqn_path = self.model_load_source_path + '/' + str(self.conf.saved_model_index) + '_drqn_net_params.pkl'
                qmix_path = self.model_load_source_path + '/' + str(self.conf.saved_model_index) + '_qmix_net_params.pkl'
                map_location = 'cuda:2' if self.conf.cuda else 'cpu'
                self.eval_drqn_net.load_state_dict(torch.load(drqn_path, map_location=map_location)) # 加载模型参数
                self.eval_qmix_net.load_state_dict(torch.load(qmix_path, map_location=map_location))
                print("successfully load models")
            else:
                raise Exception("No model!")
        
        # copy eval net params to target net # 将评估网络参数复制给目标网络参数
        self.target_drqn_net.load_state_dict(self.eval_drqn_net.state_dict())
        self.target_qmix_net.load_state_dict(self.eval_qmix_net.state_dict())

        self.eval_parameters = list(self.eval_qmix_net.parameters()) + list(self.eval_drqn_net.parameters())
        # 评估网络参数用RMS来优化
        if self.conf.optimizer == "RMS":
            self.optimizer = torch.optim.RMSprop(self.eval_parameters, lr=self.conf.learning_rate)

        # 学习时，为每个agent维护一个eval_hidden, target_hidden # ？？？
        self.eval_hidden = None
        self.target_hidden = None

        print("init qmix nets finished!")

    def learn(self, writer, batch, max_episode_len, train_step, epsilon=None):
    # train_step表示是第几次学习，用来控制更新target_net网络的参数
        """
        batch: train data, obs: (batch_size, episode_limit, n_agents, obs_shape),(64, -53- ,3,42)
        max_episode_len: max episode length
        train_step: step record for updating target network parameters 
        """
        episode_num = batch['o'].shape[0]
        self.init_hidden(episode_num)
        for key in batch.keys(): # 把batch里的数据转化成tensor
            if key == 'u':
                batch[key] = torch.tensor(batch[key], dtype=torch.long)
            else:
                batch[key] = torch.tensor(batch[key], dtype=torch.float32)

        s, s_, u, r, avail_u, avail_u_, terminated = batch['s'], batch['s_'], batch['u'], batch['r'], \
                                                     batch['avail_u'], batch['avail_u_'], batch['terminated']
        mask = 1 - batch['padded'].float() # 把填充经验的TD-error置0，防止影响学习
        # 用来把那些填充的经验的TD-error置0，从而不让它们影响到学习
        
        # 得到每个agent对应的Q值，维度为(episode个数, max_episode_len， n_agents， n_actions)
        q_evals, q_targets = self.get_q_values(batch, max_episode_len)
        s = s.to(self.device)
        u = u.to(self.device)
        r = r.to(self.device)
        s_ = s_.to(self.device)
        terminated = terminated.to(self.device)
        mask = mask.to(self.device)

        # 取每个agent动作对应的Q值，并且把最后不需要的一维去掉，因为最后一维只有一个值了
        # print("q_evals1 shape: ", q_evals.size()) #[batch_size, max_episode_len, n_agents, n_actions]
        q_evals = torch.gather(q_evals, dim=3, index=u).squeeze(3)
        # 得到target_q
        q_targets[avail_u_ == 0.0] = -9999999
        q_targets = q_targets.max(dim=3)[0]
        # print("q_evals2 shape: ", q_evals.size()) # [batch_size, max_episode_len, n_agents]
        
        q_total_eval = self.eval_qmix_net(q_evals, s)
        q_total_target = self.target_qmix_net(q_targets, s_)

        targets = r + self.conf.gamma * q_total_target *    (1-terminated) # Q值更新
        #targets = r + self.conf.gamma * q_total_target
        
        td_error = (q_total_eval - targets.detach())
        mask_td_error = mask * td_error # 抹掉填充的经验的td_error
        
        # 不能直接用mean，因为还有许多经验是没用的，所以要求和再比真实的经验数，才是真正的均值
        loss = (mask_td_error ** 2).sum() / mask.sum()
        
        writer.add_scalar("loss", loss, train_step)
        
        self.optimizer.zero_grad() #把模型中参数的梯度初始化为0，或者是清空过往梯度？？？ 
        loss.backward() # 反向传播，计算当前梯度
        #print("self.eval_parameters:", self.eval_parameters)
        torch.nn.utils.clip_grad_norm_(self.eval_parameters, self.conf.grad_norm_clip)
        
        # clip_grad_norm_，设置一个梯度剪切的阈值，如果在更新梯度的时候，梯度超过这个阈值，则会将其限制在这个范围之内，防止梯度爆炸。
        self.optimizer.step() # 根据梯度更新网络参数

        if train_step > 0 and train_step % self.conf.update_target_params == 0:
            self.target_drqn_net.load_state_dict(self.eval_drqn_net.state_dict())
            self.target_qmix_net.load_state_dict(self.target_qmix_net.state_dict())
        

    def get_q_values(self, batch, max_episode_len):
        episode_num = batch['o'].shape[0]
        q_evals, q_targets = [], []
        for transition_idx in range(max_episode_len):
            inputs, inputs_ = self._get_inputs(batch, transition_idx) # 给obs加last_action、agent_id # 调用_get_inputs函数
            inputs = inputs.to(self.device)  # [batch_size*n_agents, obs_shape+n_agents+n_actions]
            # .to(device)可以指定CPU或GPU，将数据加载到指定的设备上
            inputs_ = inputs_.to(self.device)
            
            self.eval_hidden = self.eval_hidden.to(self.device) # eval_hidden是一个torch tensor类型的数据
            self.target_hidden = self.target_hidden.to(self.device)
            q_eval, self.eval_hidden = self.eval_drqn_net(inputs, self.eval_hidden) # (n_agents, n_actions)
            # inputs维度为(40,96)，得到的q_eval维度为(40,n_actions)
            # eval_drqn_net是单智能体的评估网络，接收输入，得到输出
            q_target, self.target_hidden = self.target_drqn_net(inputs_, self.target_hidden)

            # 把q_eval维度重新变回(8, 5,n_actions)
            q_eval = q_eval.view(episode_num, self.n_agents, -1) #(batch_size, n_agents, n_actions) # torch.view()可以将数据重新排列
            q_target = q_target.view(episode_num, self.n_agents, -1)
            q_evals.append(q_eval)  # 所有评估Q值存储
            q_targets.append(q_target)  # 所有目标Q值存储
        
        # 得的q_eval和q_target是一个列表，列表里装着max_episode_len个数组，数组的的维度是(episode个数, n_agents，n_actions)
        # 把该列表转化成(batch_size, max_episode_len， n_agents，n_actions)的数组
        q_evals = torch.stack(q_evals, dim=1) # torch.stack()沿着一个新维度对输入张量序列进行连接。 序列中所有的张量都应该为相同形状。
        q_targets = torch.stack(q_targets, dim=1)
        return q_evals, q_targets


    def _get_inputs(self, batch, transition_idx):
        # 取出所有episode上该transition_idx的经验，u_onehot要取出所有，因为要用到上一条
        o, o_, u_onehot = batch['o'][:, transition_idx], batch['o_'][:, transition_idx], batch['u_onehot'][:] # u_onehot取全部，要用上一条
        episode_num = o.shape[0] # batch_size
        inputs, inputs_ = [], []
        inputs.append(o)
        inputs_.append(o_)
        
        # 给obs添加上一个动作、agent编号
        if self.conf.last_action:
            if transition_idx == 0: # 如果是第一条经验，就让前一个动作为0向量
                inputs.append(torch.zeros_like(u_onehot[:, transition_idx]))
            else:
                inputs.append(u_onehot[:, transition_idx-1])
            inputs_.append(u_onehot[:, transition_idx])

        if self.conf.reuse_network:
            """
            因为当前的obs三维的数据，每一维分别代表(episode编号，agent编号，obs维度)，直接在dim_1上添加对应的向量
            即可，比如给agent_0后面加(1, 0, 0, 0, 0)，表示5个agent中的0号。而agent_0的数据正好在第0行，那么需要加的
            agent编号恰好就是一个单位矩阵，即对角线为1，其余为0
            """
            inputs.append(torch.eye(self.n_agents).unsqueeze(0).expand(episode_num, -1, -1))
            inputs_.append(torch.eye(self.n_agents).unsqueeze(0).expand(episode_num, -1, -1))

        # 要把obs中的三个拼起来，并且要把episode_num个episode、self.args.n_agents个agent的数据拼成40条(40,96)的数据
        # 把batch_size、n_agents个agent的obs拼起来，
        # 因为这里所有agent共享一个神经网络，每条数据中带上了自己的编号，所以还是自己的数据
        # (batch_size, n_agents, n_actions) -> (batch_size*n_agents, n_actions)
        inputs = torch.cat([x.reshape(episode_num*self.n_agents, -1) for x in inputs], dim=1)
        inputs_ = torch.cat([x.reshape(episode_num*self.n_agents, -1) for x in inputs_], dim=1)
        
        return inputs, inputs_

    def init_hidden(self, episode_num): # 初始化隐藏层参数？？？
        self.eval_hidden = torch.zeros((episode_num, self.n_agents, self.conf.drqn_hidden_dim))
        self.target_hidden = torch.zeros((episode_num, self.n_agents, self.conf.drqn_hidden_dim))
    
    def save_model(self, train_step):
        num = str((train_step+1) // self.conf.save_frequency) # //表示整数除法
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)
        #print("save model: {} epoch.".format(num))
        # 将两个评估网络的参数保存在相应文件夹中
        torch.save(self.eval_drqn_net.state_dict(), self.model_dir+'/'+num+'_drqn_net_params.pkl')
        torch.save(self.eval_qmix_net.state_dict(), self.model_dir+'/'+num+'_qmix_net_params.pkl')

