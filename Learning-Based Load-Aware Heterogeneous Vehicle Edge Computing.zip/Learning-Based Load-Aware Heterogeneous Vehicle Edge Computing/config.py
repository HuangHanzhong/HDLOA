import torch
import numpy as np
from interval import Interval
class Config:
    def __init__(self):
        self.test_index = 32
        #self.chosed_policy = 'QMIX'
        self.chosed_policy = 'VDN'
        #self.chosed_policy = 'IQL'
        #self.chosed_policy = 'QTRAN_ALT'
        self.start_show_epoch = 2100
        self.start_show_episode = 1000
        self.n_epochs = 3500
        self.bad_flag_num = 2
        self.change_penalty_episode = 1800
        self.reward_scale_factor = 140

        self.start_epsilon = 1
        self.load_model = False # test setting
        # self.load_model = True
        self.saved_model_index = 55
        self.last_test_back_index = 1
        self.anneal_steps = 300 # 这个参数大概就是经过这么多次更新降到end_epsilon # 原参数20 # 50000
        self.update_target_params = 100 # 200
        self.gamma = 0.9          # gamma值大小似乎会影响loss大小，正比关系
        self.dnn_num = 64
        self.learning_rate = 3e-4  # 原参数 5e-4
        self.ABS_energy_initial = 20
        self.episode_limit = 20
        self.batch_size = 64 # 32
        self.buffer_size = 2600
        self.two_hyper_layers = True
        self.n_eposodes = 1 # 每个epoch有多少episodes
        #self.epsilon_down_start_epoch = 300
        
        self.penalty_factor = -0.9
        self.ABS_energy_out_penalty = 0
        self.RSU_empty_to_empty_penalty = 0
        self.RSU_direct_overload = 0
        self.fail_link_penalty = 0
        self.bad_reward_penalty = 0
        self.MBS_empty_penalty = 0
        self.RSU_noempty_to_empty_penalty = 0
        self.offloading_mode_gain_sum_is_zero_penalty = 0
        self.bad_offloading_penalty = 0
        self.not_good_reward = 0.1
        
        self.test_name = 'test_' + str(self.test_index)
        if self.test_index > 1:
            self.last_test_name = 'test_' + str(self.test_index - self.last_test_back_index)
        else:
            self.last_test_name = 'test_' + str(self.test_index)
        
        self.result_print_interval = 20
        self.reward_exp_factor1 = 0.5
        self.reward_exp_factor2 = 1.5
        self.reward_scaling_factor1 = 1500
        self.reward_scaling_factor2 = 50
        self.reward_scaling_factor3 = 2000
        
        self.reward_average_update = 10
        self.step_rewards_average_set_threshold = 20
        self.step_rewards_average_candidate_num = 8
        
        self.VUE_num = 18
        self.RSU_num = 3
        """
        self.action_space = list(range(0, 1 + self.VUE_num + self.RSU_num + 1)) # 动作空间[0,1, ...]
        # action_space = 0 本地计算
        # action_space = [1, VUE_num] 中继VUE
        # action_space = [VUE_num + 1, VUE_num + RSU_num] RSU
        # action_space = VUE_num + RSU_num + 1 中继MBS
        """
        self.action_space = list(range(0, 1 + self.RSU_num + 1)) # 动作空间[0,1, ...]
        # action_space = 0 本地计算
        # action_space = [1, RSU_num] RSU
        # action_space = 1 + RSU_num 中继MBS
        
        self.n_agents = self.VUE_num
        self.n_actions = len(self.action_space)
        self.obs_shape = 5 # 单个智能体的obs长度 【车辆坐标； 任务大小； 计算需求值】 如果没有生成任务，后面两个都为0
        self.state_shape = self.RSU_num + 2 + self.n_agents*self.n_actions
        
        self.VUE_index_set = list(range(0, self.VUE_num))  # 生成[0, 1, 2, 3, 4]
        self.RSU_index_set = list(range(0, self.RSU_num))  # 生成[0, 1]
        self.VUE_height = 1 # m
        self.VUE_x1 = 3 # m 向右行驶的车道的车辆x轴坐标值
        self.VUE_x2 = -self.VUE_x1 # m 向左行驶的车辆x轴坐标值
        self.RSU_height = 6 # m
        self.RSU_radius = 200 # m
        self.ABS_height = 200 # m
        self.MBS_height = 25 # m
        self.MBS_x = -2*self.RSU_radius-100
        self.beam_num_max = 4 # 最大波束
        
        self.coordinate_y_begin = -3*self.RSU_radius # m 坐标轴y轴左侧边界
        self.coordinate_y_end = -self.coordinate_y_begin # m 坐标轴y轴右侧边界
        self.coordinate_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_end) # y轴闭区间范围，[coordinate_y_begin, coordinate_y_end]
        self.RSU0_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_begin + 2*self.RSU_radius, upper_closed = False)
        # RSU0 y轴闭开区间范围，[coordinate_y_begin, self.coordinate_y_begin + 2*self.RSU_radius)
        self.RSU1_y_range = Interval(self.coordinate_y_begin + 2*self.RSU_radius, self.coordinate_y_begin + 4*self.RSU_radius, upper_closed = False)
        # RSU1 y轴闭开区间范围，[a, b)
        self.RSU2_y_range = Interval(self.coordinate_y_begin + 4*self.RSU_radius, self.coordinate_y_begin + 6*self.RSU_radius)
        # RSU2 y轴闭区间范围，[a, b]
        self.RSU_y_range_set = [self.RSU0_y_range, self.RSU1_y_range, self.RSU2_y_range]
        
        self.RSU0_coordinate = [0, -2*self.RSU_radius, self.RSU_height]
        self.RSU1_coordinate = [0, 0, self.RSU_height]
        self.RSU2_coordinate = [0, 2*self.RSU_radius, self.RSU_height]
        self.RSU_coordinate_set = [self.RSU0_coordinate, self.RSU1_coordinate, self.RSU2_coordinate]
        self.ABS_coordinate = [0, 0, self.ABS_height]
        self.MBS_coordinate = [self.MBS_x, 0, self.MBS_height]
        
        #self.VUE_x1_num = 6 # 前面向右行驶的车辆数（x轴正轴）
        #self.VUE_x2_num = self.VUE_num - self.VUE_x1_num # 后面向左行驶的车辆数（x轴负轴）
        
        self.VUE1_x1_coordinate_y_initial = self.coordinate_y_begin + 1 # x轴正方向侧的第一个车辆的初始坐标
        self.VUE1_x2_coordinate_y_initial = self.coordinate_y_end - 1 # x轴负方向侧的第一个车辆的初始坐标
        self.VUE_min_interval = 50 # 车辆安全距离
        self.coordinate_candidates_num = int(6*self.RSU_radius / self.VUE_min_interval) - 1 # 初始化车辆坐标时可选的候选坐标点个数
        
        self.x1_coordinate_candidates = [] # x正轴初始化坐标点候选集
        for coordinate_candidates_index in range(self.coordinate_candidates_num):
            self.x1_coordinate_candidates.append(self.VUE1_x1_coordinate_y_initial + coordinate_candidates_index*self.VUE_min_interval)
        
        self.x2_coordinate_candidates = [] # x负轴初始化坐标点候选集
        for coordinate_candidates_index in range(self.coordinate_candidates_num):
            self.x2_coordinate_candidates.append(self.VUE1_x2_coordinate_y_initial - coordinate_candidates_index*self.VUE_min_interval)
        
        self.task_generation_lambda = 13
        self.task_type_num = 3
        self.CA_task_bit_size = 1*10**6  # bit
        self.CA_task_computation_density = 150  # CPU cycles/bit
        self.CA_task_computation_resource_requirement = self.CA_task_bit_size*self.CA_task_computation_density
        self.CA_task_delay_threshold = 100  # ms
        
        self.HPA_task_bit_size = 1.5*10**6  # bit
        self.HPA_task_computation_density = 100  # CPU cycles/bit
        self.HPA_task_computation_resource_requirement = self.HPA_task_bit_size*self.HPA_task_computation_density
        self.HPA_task_delay_threshold = 200  # ms
        
        self.LPA_task_bit_size = 2*10**6  # bit
        self.LPA_task_computation_density = 50  # CPU cycles/bit
        self.LPA_task_computation_resource_requirement = self.LPA_task_bit_size*self.LPA_task_computation_density
        self.LPA_task_delay_threshold = 300  # ms
        
        self.task_bit_size_set = [self.CA_task_bit_size, self.HPA_task_bit_size, self.LPA_task_bit_size]
        self.task_computation_density_set = [self.CA_task_computation_density, self.HPA_task_computation_density, self.LPA_task_computation_density]
        self.task_computation_resource_requirement_set = [self.CA_task_computation_resource_requirement, self.HPA_task_computation_resource_requirement,
                                                          self.LPA_task_computation_resource_requirement]
        self.task_delay_threshold_set = [self.CA_task_delay_threshold, self.HPA_task_delay_threshold, self.LPA_task_delay_threshold]
        
        self.task_bit_size_max = max(self.task_bit_size_set) # 最大任务数据量，用于归一化
        self.task_computation_resource_requirement_max = max(self.task_computation_resource_requirement_set) # 最大计算资源需求，用于归一化
        
        self.task_type_prob = np.array([0.3, 0.4, 0.3]) # 产生三种任务类型的概率
        self.VUE_with_task_num_min = 9 # 有任务的用户数最小值
        
        self.VUE_computing_resource = 0.5*10**9  # CPU cycles/second
        self.RSU_computing_resource = 6*10**9  # CPU cycles/second
        self.Poisson_factor = 3
        self.MBS_computing_resource_up = 10
        self.local_computing_latency_max = round((self.task_computation_resource_requirement_max / self.VUE_computing_resource) * 1e3, 3)
        # 本地计算最大时延
        
        self.VUE_x1_move_direction_flag = 1 # 车辆行驶方向，取值1或2
        self.VUE_x2_move_direction_flag = 1
        self.VUE_speed_set = [0]*self.VUE_num
        self.truncated_normal_mean = 60
        self.truncated_normal_stddev = 21**0.5
        self.VUE_speed_unit_factor = round(1e3/36000, 4) # 将km/h换算成m/(100ms)， 考虑每100ms的决策
        
        self.light_speed = 3*10**5  # 3*10^8 m/s
        
        self.sub6_frequency = 3.5*10**3  # 3*10^5 MHz； 0.3 THz
        self.mmW_frequency = 28*10**3  # MHz; 28 GHz
        self.sub6_bandwidth = 20*10**6  # Hz;  20 MHz
        self.mmW_bandwidth = 200*10**6  # Hz;  100 MHz
        self.Boltzmann_constant = 1.3806505*10**(-23)  # J/K
        self.Kelvin_temperature = 300  # K
        self.THz_molecular_absorption_coefficient = 1.6  # 1.6/km; 0.0016/m
        self.Gaussian_noise_psd_dBm_per_Hz = -174  # unit is dBm/Hz, noise power = Gaussian_noise_psd_dBm_per_Hz*Bandwidth
        self.channel_power_gain_at_reference_distance_dB = -65  # dB
        
        self.VR_power_decay_exponent = 2.5
        self.VA_power_decay_exponent = 2
        self.AV_power_decay_exponent = 2
        self.AR_power_decay_exponent = 2
        self.AM_power_decay_exponent = 2
        
        self.VUE_tx_sub6_antenna_gain = 17  # dBi
        self.VUE_rx_sub6_antenna_gain = 17  # dBi
        self.ABS_rx_sub6_antenna_gain = 0  # dBi
        self.VUE_tx_mmW_antenna_gain = 17  # dBi
        self.RSU_rx_mmW_antenna_gain = 17  # dBi
        self.ABS_tx_sub6_antenna_gain = 17  # dBi
        self.RSU_rx_sub6_antenna_gain = 0  # dBi
        self.MBS_rx_sub6_antenna_gain = 0  # dBi
        
        #VUE_tx_power_W = 1  # 1 W
        #VUE_tx_power_dBm = 10 * math.log(1000*VUE_tx_power_W, 10) # 30 dBm
        #ABS_tx_power_W = 1  # 1 W
        #ABS_tx_power_dBm = 10 * math.log(1000*ABS_tx_power_W, 10) # 30 dBm
        self.VUE_tx_power_dBm = 20 # dBm
        self.ABS_tx_power_dBm = 20 # dBm
        
        self.ABS_energy_threshold = 10
        self.SNR_threshold = 10 # SNR阈值
        
        
        # train setting 
        self.train = True
        self.seed = 133
        self.cuda = False
        
        self.last_action = True # 使用最新动作选择动作 # ???
        self.reuse_network = True # 对所有智能体使用同一个网络
        
        self.evaluate_epoch = 5 # 20
        self.evaluate_per_epoch = 20 # 100
        self.save_frequency = 20 # 5000
        self.data_moving_save_frequency = 20
        self.train_steps = 1 # 每个epoch有多少train steps # episodes和train_steps的关系？？？
        self.grad_norm_clip = 10 # prevent gradient explosion
        
        self.log_dir = './logs/'
        self.result_dir = './results/' # 会在main函数同文件夹下建立results文件夹
        self.moving_result_dir = './moving_results/'
        if self.chosed_policy == 'QMIX':
            self.policy_name = './policy_QMIX_record/'
        elif self.chosed_policy == 'VDN':
            self.policy_name = './policy_VDN_record/'
        elif self.chosed_policy == 'IQL':
            self.policy_name = './policy_IQL_record/'
        elif self.chosed_policy == 'QTRAN_ALT':
            self.policy_name = './policy_QTRAN_ALT_record/'
        
        # VEC_env setting
        self.env_name = './3RSU_18VUE/'
        self.step_mul = 8 # 多少步执行一次动作 #？？？
        self.difficulty = '4'
        self.game_version = 'latest'
        self.replay_dir = './replay_buffer/'

        if self.cuda:
            self.device = torch.device("cpu")
        else:
            self.device = torch.device("cuda: 2" if torch.cuda.is_available() else "cpu")

        ### QMIX model structure
        # drqn net
        self.drqn_hidden_dim = self.dnn_num   # 原参数64
        # qmix net
        # input: (batch_size, n_agents, qmix_hidden_dim)
        self.qmix_hidden_dim = int(self.dnn_num/2)    # 原参数32
        self.hyper_hidden_dim = self.dnn_num  # 原参数64
        ###
        
        ### VDN model structure
        self.critic_dim = self.dnn_num   # 原参数64
        self.rnn_hidden_dim = int(self.dnn_num/2)    # 原参数32
        ###
        
        # QTRAN lambda
        self.qtran_hidden_dim = 64
        self.lambda_opt = 1
        self.lambda_nopt = 1
        
        
        self.model_dir = './models/'
        self.optimizer = "RMS"

        # epsilon greedy
        
        self.end_epsilon = 0.05
        self.anneal_epsilon = (self.start_epsilon - self.end_epsilon) / self.anneal_steps
        self.epsilon_anneal_scale = 'step'
        
        