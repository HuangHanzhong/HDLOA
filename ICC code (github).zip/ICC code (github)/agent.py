import numpy as np
import torch
from torch.distributions import Categorical

class Agents:
    def __init__(self, conf, writer):
        self.conf = conf
        self.device = conf.device
        self.n_actions = conf.n_actions 
        self.n_agents = conf.n_agents 
        self.state_shape = conf.state_shape # state_shape=61，就是所有agents的总的state拼接后的一维数组长度
        self.obs_shape = conf.obs_shape # obs_shape=42，就是一个agent的观测数据的一维数组长度
        self.episode_limit = conf.episode_limit
        self.writer = writer
        
        if self.conf.chosed_policy == 'QMIX':
            from policy_QMIX import QMIX
            self.policy = QMIX(conf)
        elif self.conf.chosed_policy == 'VDN':
            from policy_VDN import VDN
            self.policy = VDN(conf) # self.policy是policy文件中的VDN类的实例对象
        elif self.conf.chosed_policy == 'IQL':
            from policy_IQL import IQL
            self.policy = IQL(conf)
        elif self.conf.chosed_policy == 'QTRAN_ALT':
            from policy_qtran_alt import QtranAlt
            self.policy = QtranAlt(conf)
        
        print("Agents inited!")

    def choose_action(self, obs, last_action, agent_num, availible_actions, epsilon, evaluate=False): # 函数choose_action在文件utils中被调用
    # 这个函数为单个智能体选择动作，其输入参数都是第agent_id个智能体的参数
        inputs = obs.copy() # 是从env中获取的完整obs中提取的第agent_id个智能体的观测，即完整obs列表的第agent_id个元素，长度为obs_shape的一维array
        availible_actions_idx = np.nonzero(availible_actions)[0]
        actions_idx = np.array(list(range(0, self.n_actions)))
        agents_id = np.zeros(self.n_agents) # 所有agents的编号初始化
        agents_id[agent_num] = 1. # agent_num是智能体编号，第agent_num个智能体
        
        if self.conf.last_action: # conf.last_action = True # 使用上一个动作选择动作？？？
        # choose_action函数的形参last_action和conf.last_action不是一个东西。last_action: numpy array of previous actions for each agent，用来存储每个智能体上一次执行的动作？
            inputs = np.hstack((inputs, last_action)) # np.hstack((a,b))将两个向量按水平叠加，[1,2], [3,4]变成[1,2,3,4]
            # 将上一个动作加入inputs
        if self.conf.reuse_network: # conf.reuse_network = True # 对所有智能体使用同一个网络
            inputs = np.hstack((inputs, agents_id))
            # 将智能体编号加入inputs
        # 上述两个if，如果conf.last_action = True，则把agent的上一次动作加到inputs中；conf.reuse_network = True，则重用网络参数，将智能体编号加到inputs中
            
        hidden_state = self.policy.eval_hidden[:, agent_num, :] # ？？？

        inputs = torch.tensor(inputs, dtype=torch.float32).unsqueeze(0).to(self.device) # (42,) -> (1,42)
        availible_actions = torch.tensor(availible_actions, dtype=torch.float32).unsqueeze(0).to(self.device)
        # 这个inputs要与policy中的input_shape维度一致
        # inputs包括：obs[agent_id]+last_action+agents_id=self.obs_shape+self.n_actions+n_agents  # unsqueeze()增加数据维度
        # 原本inputs=[array([1, 1]), array([2, 2])]; 转换之后变为tensor([[[1., 1.], [2., 2.]]])
        # 为啥会对inputs增加维度？？？
        
        # get q value
        # 将第agent_num个智能体的状态inputs输入到智能体评估网络eval_drqn_net获取q值
        if self.conf.chosed_policy == 'QMIX':
            q_value, self.policy.eval_hidden[:, agent_num, :] = self.policy.eval_drqn_net(inputs, hidden_state) # 获取Q值
        elif self.conf.chosed_policy == 'VDN':
            q_value, self.policy.eval_hidden[:, agent_num, :] = self.policy.eval_rnn(inputs, hidden_state) # 获取Q值
        elif self.conf.chosed_policy == 'IQL':
            q_value, self.policy.eval_hidden[:, agent_num, :] = self.policy.eval_rnn(inputs, hidden_state) # 获取Q值
        elif self.conf.chosed_policy == 'QTRAN_ALT':
            q_value, self.policy.eval_hidden[:, agent_num, :] = self.policy.eval_rnn(inputs, hidden_state)
        # eval_drqn_net的网络输入为该智能体的历史动作-观测序列信息，输出该智能体分解之后的Q值函数。#分解？？？
        # 返回的第二个变量self.policy.eval_hidden[:, agent_num, :]没用？
        q_value[availible_actions == 0.0] = -float("inf")
        # choose action form q value
        
        
        if np.random.uniform() < epsilon: # 概率贪婪策略
            action = np.random.choice(availible_actions_idx)
        else:
            action = torch.argmax(q_value) # torch.argmax(dim)会返回dim维度上张量最大值的索引。
        """
        action = np.random.choice(availible_actions_idx) # 随机选择策略
        """
        return action, actions_idx, q_value

    def _get_max_episode_len(self, batch): # batch是一个字典，为经验池中随机抽样的多个样本。 这个函数的作用？？？
        terminated = batch["terminated"]
        episode_num = terminated.shape[0] # 从utils文件中的ReplayBuffer类可以看出，terminated.shape[0]就是回合数
        max_episode_len = 0
        for episode_idx in range(episode_num): #对每一回合循环
            for transition_idx in range(self.episode_limit): # episode_limit=200，对第episode_idx这一回合的每一步循环
                if terminated[episode_idx, transition_idx, 0] == 1:
                    if transition_idx+1 >= max_episode_len:
                        max_episode_len = transition_idx + 1 # 找出所有回合的最大步数，最大步数不超过200
                    break
        return max_episode_len # 找出最大步数应该是为了数据长度统一，方便后续处理

    def train(self, batch, train_step, epsilon=None):
        # 不同的episode的数据长度不同，因此需要得到最大长度
        # batch样本中有多个回合的样本，每个回合的长度不一样，就取最大回合长度？？？
        max_episode_len = self._get_max_episode_len(batch)
        for key in batch.keys():
            batch[key] = batch[key][:, :max_episode_len] # 取batch[key]中所有行，第0列到第max_episode_len列的数据
        self.policy.learn(self.writer, batch, max_episode_len, train_step, epsilon) # 此policy是文件policy中QMIX类定义的函数，调用policy类函数中的learn函数
        if train_step > 0 and (train_step+1) % self.conf.save_frequency == 0:
            self.policy.save_model(train_step)

 