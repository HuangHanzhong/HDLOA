import numpy as np
import matplotlib.pyplot as plt
from config import Config  # 从参数文件中导入参数类
conf = Config()  # conf是类Config的实例化对象
plt.close('all')
test_index = 45
data_splice_flag = 0
if data_splice_flag == 1: # 如果要多个数据拼接
    test_index_add_set = [39] # 二次模型编号
data_name_index = 3
chosed_policy = 1
if chosed_policy == 1:
    policy_name = 'policy_QMIX_record/'
elif chosed_policy == 2:
    policy_name = 'policy_VDN_record/'
elif chosed_policy == 3:
    policy_name = 'policy_IQL_record/'
if data_name_index == 1:
    data_name = 'nt_step_latency_set_sums_average_in_episodes.npy'
    move_average_value = 70
elif data_name_index == 2:
    data_name = 'nt_step_latency_set_maxs_average_in_episodes.npy'
    move_average_value = 70
elif data_name_index == 3:
    data_name = 'episode_rewards.npy'
    move_average_value = 20
elif data_name_index == 4:
    data_name = 'nt_step_zero_offloading_gains_average_in_episodes.npy'
    move_average_value = 70

def moving_average(a, n=70):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = []
as_set = []
data_load_source_path = conf.env_name + policy_name + 'test_' + str(test_index) + '/moving_results/' + data_name
a1 = np.load(data_load_source_path)
a1 = a1.tolist()
a.append(a1)
if data_splice_flag == 1:
    for i in test_index_add_set:
        data_load_source_path = conf.env_name + policy_name + 'test_' + str(i) + '/moving_results/' + data_name
        as_i = np.load(data_load_source_path)
        as_i = as_i.tolist()
        #as_i=[ele-40 for ele in as_i]
        a.append(as_i)
        as_set.append(as_i)
a_len = [len(ele) for ele in a]
print ("len_before_move_average:", a_len, sum(a_len))
for i in range(len(a)):
    plt.figure(i+1)
    plt.plot(range(len(a[i])), a[i], marker = 'd', markersize = 4, color='blue')
    plt.xlabel("epoch")
    plt.ylabel(" ")
    plt.grid()


""""""
#a = [a[0][0:1750], a[1][-600:]]
h = sum(a, [])
#h = h +h[0:1750] + h[1830:]
hm = moving_average(h, move_average_value)
hm=[round(ele, 1) for ele in hm]
print("total_len_after_move_average:", len(hm))

#hm = hm + hm[1340:1450]

plt.figure(20)
plt.plot(range(len(h)), h, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("data_name")
plt.xlim(0, len(h))
plt.ylim(-55,100)
plt.grid()
plt.figure(21)
plt.plot(range(len(hm)), hm, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("data_name")
plt.xlim(0, len(hm))
plt.ylim(-55,100)
plt.grid()
# if len(hm) > 2000:          print(hm[0:2000])









"""
hma = hm + hm[-30:-10] + hm[-40:-20] + hm[-20:-10]
hma=[ele+0 for ele in hma]
print("total_len_after_move_average_and_add:", len(hma))
plt.figure(22)
plt.plot(range(len(hma)), hma, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("data_name")
plt.xlim(0, min(2000, len(hma)))
plt.ylim(2300,4900-200)
plt.grid()
# print(hma)
"""
