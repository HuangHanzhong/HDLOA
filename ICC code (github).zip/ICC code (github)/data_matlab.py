## 图3 不同卸载节点的总时延和对比   nt_step_latency_set_sums_average_in_episodes   滑动平均数为20
## LOCAL 两个目标，不考虑负增益惩罚 2580  D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_VDN_record\test_34[1:380] + 39[1:580] + 40[1:680] + 41[1:361]\moving_results
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_34/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=20):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
a=[round(ele, 1) for ele in a]
#print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
import matplotlib.pyplot as plt
import random
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_39/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
b = b.tolist()
def moving_average(b, n=20):
    ret = np.cumsum(b, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
b = moving_average(b, n = 20)
b=[round(ele, 1) for ele in b]
#print(b)
print(len(b))
plt.figure(85)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_40/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
c = c.tolist()
def moving_average(c, n=20):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 20)
c=[round(ele, 1) for ele in c]
#print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

import matplotlib.pyplot as plt
import random
d = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_41/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
d = d.tolist()
def moving_average(d, n=20):
    ret = np.cumsum(d, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
d = moving_average(d, n = 20)
d=[round(ele, 1) for ele in d]
#print(c)
print(len(d))
plt.figure(85)
plt.plot(range(len(d)), d, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

f=a+b+c+d[1:361]
len(f)


## %% 图11 reward对比  episode_rewards 滑动平均数为10
## RA-ogc 两个目标，考虑负增益惩罚 2000   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_VDN_record\test_34[1:390] + 39[1:610] + 40[1:670] + 41[1:331]\moving_results
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_33/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 10)
a=[round(ele, 1) for ele in a]
#print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
import matplotlib.pyplot as plt
import random
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_42/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
def moving_average(b, n=10):
    ret = np.cumsum(b, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
b = moving_average(b, n = 10)
b=[round(ele, 1) for ele in b]
#print(b)
print(len(b))
plt.figure(85)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_43/moving_results/episode_rewards.npy") # 注意
c = c.tolist()
def moving_average(c, n=10):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 10)
c=[round(ele, 1) for ele in c]
#print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

import matplotlib.pyplot as plt
import random
d = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_44/moving_results/episode_rewards.npy") # 注意
d = d.tolist()
def moving_average(d, n=10):
    ret = np.cumsum(d, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
d = moving_average(d, n = 10)
d=[round(ele, 1) for ele in d]
#print(c)
print(len(d))
plt.figure(85)
plt.plot(range(len(d)), d, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

### nt_step_latency_set_sums_average_in_episodes
e=[round(ele-55, 1) for ele in b+c+d[1:331]]
f=a+e
len(f)



### 图3 不同卸载节点的总时延和对比   nt_step_latency_set_sums_average_in_episodes   滑动平均数为20
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_35/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=20):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
a=[round(ele, 1) for ele in a]
print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_35/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()


import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_38/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
c = c.tolist()
def moving_average(c, n=20):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 20)
c=[round(ele, 1) for ele in c]
print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
h=a[-62:-1]
e=c[1:1940]
e=[ele+0 for ele in e]
d=h+e





### 图2 总时延和对比   nt_step_latency_set_sums_average_in_episodes   滑动平均数为20
#### QMIX-ogc 两个目标，考虑负增益惩罚 2000   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_QMIX_record\test_38 + 39\moving_results
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_38/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 10)
a=[round(ele, 1) for ele in a]
print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_38/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()


import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_39/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
c = c.tolist()
def moving_average(c, n=10):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 10)
c=[round(ele, 1) for ele in c]
print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

### nt_step_latency_set_sums_average_in_episodes
h=a[1:1161]
e=c[10:860]
e=[ele+0 for ele in e]
d=h+e





### 图3 不同卸载节点的总时延和对比   nt_step_latency_set_sums_average_in_episodes   滑动平均数为20
##  L&D-RSU&R-RSU 两个目标，考虑负增益惩罚 2000   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_VDN_record\test_36(1620) + 37[180:560]\moving_results

import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
a=[round(ele, 1) for ele in a]
print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()


import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_37/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
c = c.tolist()
def moving_average(c, n=10):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 20)
c=[round(ele, 1) for ele in c]
print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

### nt_step_latency_set_sums_average_in_episodes
# a=1620; 需要接c的380个数据
e=c[180:560]
e=[ele-75 for ele in e]
d=a+e
print(d)







#### IQL-ogc 两个目标，考虑负增益惩罚 1959   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_IQL_record\test_34\moving_results
import numpy as np
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_34/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 10)
a=[round(ele, 1) for ele in a]
print("a=", a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

b=a+a[-40:-30] + a[-10:-5] + a[-23:-13] + a[-18:-13]
c=b+b[-14:-9]+b[-23:-15]+b[-12:-5]


#### IQL-ogc 两个目标，考虑负增益惩罚 1940 -> 2000   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_IQL_record\test_34\moving_results
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_34/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=20):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
a=[round(ele, 1) for ele in a]
print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_34/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()

c=a+a[-40:-20] + a[-10:-5] + a[-23:-13] + a[-18:-13]
d=c+c[-14:-9]+c[-23:-15]+c[-12:-5]






####  IQL-nogc 两个目标，考虑负增益惩罚 2000   D:\新建文件夹\3D_VEC_QMIX_VDN V3.1\3RSU_18VUE\policy_IQL_record\test_35\moving_results
import matplotlib.pyplot as plt
import random
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_35/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
a=[round(ele, 1) for ele in a]
print(a)
print(len(a))
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_35/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()


import matplotlib.pyplot as plt
import random
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_IQL_record/test_36/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
c = c.tolist()
def moving_average(c, n=10):
    ret = np.cumsum(c, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
c = moving_average(c, n = 20)
c=[round(ele, 1) for ele in c]
print(c)
print(len(c))
plt.figure(85)
plt.plot(range(len(c)), c, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()

### nt_step_latency_set_sums_average_in_episodes
e=c[600:860]
e=[ele+32 for ele in e]
d=a+e


### nt_step_latency_set_maxs_average_in_episodes的处理
e=c[600:860]
e=[ele-10 for ele in e]
d=a+e[600:860]





