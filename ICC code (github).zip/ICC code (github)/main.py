# cd D:\新建文件夹\3D_VEC_QMIX_VDN V1.6\3RSU_18VUE\policy_QMIX_record\test_
# tensorboard --logdir=logs
#cmd --->cd 到需要运行的文件路径----》tensorboard --logdir 文件或者文件夹   # tensorboard --logdir = path / to / logs / directory
"""

import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_1/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 20)
#a=a[-600:]
#print(a)
plt.figure(98)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
import numpy as np
import matplotlib.pyplot as plt
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_1/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
#b=b[-600:]
#print(b)
plt.figure(99)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()

import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/desktop/ICC code V1.0 (update)/3RSU_18VUE/policy_VDN_record/test_3/moving_results/epoch_info_set.npy", allow_pickle=True) # 注意
a = a.tolist()
#a=a[-600:]
print(a)

import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
c = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.0/3RSU_18VUE/policy_QMIX_record/test_1/moving_results/nt_step_RSU_relay_VUE_num_average_in_episodes.npy") # 注意
c = c.tolist()
for index in range(3):
    a = [i[index] for i in c]
    plt.figure(70+index)
    plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
    plt.xlabel("epoch")
    plt.ylabel("nt_step_RSU_relay_VUE_num_average_in_episodes")
    plt.grid()
d = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.0/3RSU_18VUE/policy_QMIX_record/test_1/moving_results/nt_step_MBS_relay_VUE_num_average_in_episodes.npy") # 注意
d = d.tolist()
plt.figure(77)
plt.plot(range(len(d)), d, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_MBS_relay_VUE_num_average_in_episodes")
plt.grid()


import numpy as np
import matplotlib.pyplot as plt
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_7/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
#a=a[-600:]
#print(a)
plt.figure(87)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
import numpy as np
import matplotlib.pyplot as plt
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_7/moving_results/nt_step_relay_latency_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
#a=a[-600:]
#print(a)
plt.figure(88)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
import numpy as np
import matplotlib.pyplot as plt
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_7/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
#a=a[-600:]
#print(a)
plt.figure(89)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()


"""

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
from AP_VEC_environment import VEC_env
from agent import Agents
from utils import RolloutWorker, ReplayBuffer
import matplotlib.pyplot as plt
from tensorboardX import SummaryWriter
from interval import Interval
import random
import time
import shutil
from config import Config  # 从参数文件中导入参数类
conf = Config()  # conf是类Config的实例化对象

def train():
    
    log_path = conf.env_name + conf.policy_name + conf.test_name + conf.log_dir
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    """
    if os.path.exists(log_path):  # 如果文件存在
    # 删除文件，可使用以下两种方法。
        os.remove(log_path)  
        #os.unlink(path)
    else:
        print('no log file')  # 则返回文件不存在
        os.makedirs(log_path)
    """
    env = VEC_env(conf)
    writer = SummaryWriter(log_path)
    agents = Agents(conf, writer)  # 将conf作为类输入变量传递给agent文件中的Agents类，实例化对象agents
    rollout_worker = RolloutWorker(env, agents, conf) # utils文件中有RolloutWorker类，通过传入类的3个输入参数，实例化了一个此类的对象rollout_worker
    buffer = ReplayBuffer(conf) # 实例化类对象buffer
    
    
    moving_save_path = conf.env_name + conf.policy_name + conf.test_name + conf.moving_result_dir # 文件夹存储路径。这个文件夹用来存储什么内容？？？这个变量只在此处出现过
    if os.path.exists(moving_save_path):
        shutil.rmtree(moving_save_path) 
    if not os.path.exists(moving_save_path):
        os.makedirs(moving_save_path) # 如果没有此文件夹就创建新文件夹
    
    # save plt and pkl
    save_path = conf.env_name + conf.policy_name + conf.test_name + conf.result_dir # 文件夹存储路径。这个文件夹用来存储什么内容？？？这个变量只在此处出现过
    if not os.path.exists(save_path):
        os.makedirs(save_path) # 如果没有此文件夹就创建新文件夹
    #evaluate_episode_rewards = []
    fig_plot_flag = False
    
    train_steps = 0
    epsilon = conf.start_epsilon
    anneal_epsilon = conf.anneal_epsilon
    start_epsilon = conf.start_epsilon
    epsilon_set = []
    epoch_info_set = []
    
    episodes_count = 0 # 回合计数，（epoch+1)*(episode_idx+1)
    episode_rewards = []
    accumulative_episode_rewards = []
    
    #######
    nt_step_rewards_in_episodes = []  # 记录每一回合中每一非终态step的reward。二维列表，每个元素是一个一维列表，为一个回合的非终态reward记录
    nt_step_rewards_average_in_episodes = [] # 记录每个回合所有非终态step的reward均值
    
    nt_step_zero_offloading_gains_in_episodes = [] # 记录每一回合中每一个非终态step的zero_offloading_gain
    nt_step_zero_offloading_gains_average_in_episodes = []
    
    nt_step_offloading_gain_sums_in_episodes = [] # 每一非终态step
    nt_step_offloading_gain_sums_average_in_episodes = []
    
    nt_step_offloading_revised_gain_sums_in_episodes = [] # 每一非终态
    nt_step_offloading_revised_gain_sums_average_in_episodes = []
    
    nt_step_MBS_relay_VUE_num_in_episodes = []
    nt_step_MBS_relay_VUE_num_average_in_episodes = []
    
    nt_step_relay_latency_maxs_in_episodes = []
    nt_step_relay_latency_maxs_average_in_episodes = []
    
    nt_step_latency_set_maxs_in_episodes = []
    nt_step_latency_set_maxs_average_in_episodes = []
    
    nt_step_latency_set_sums_in_episodes = []
    nt_step_latency_set_sums_average_in_episodes = []
    
    
    nt_step_latency_max_intervals_in_episodes = [] # 记录每一回合中每一个非终态step的latency_max_interval
    nt_step_latency_max_intervals_sum_in_episodes = [] # 记录每一回合的所有非终态step的latency_max_intervals的和
    
    nt_step_RSU_empty_flags_in_episodes = []
    nt_step_RSU_empty_flags_sum_in_episodes = []
    
    nt_step_MBS_empty_flags_in_episodes = []
    nt_step_MBS_empty_flags_sum_in_episodes = []
    
    nt_step_VUE_distribution_in_RSU_in_episodes = [] # 记录每一回合中非终态step的每个RSU分布的用户数
    nt_step_VUE_distribution_in_RSU_average_in_episodes = []
    
    nt_step_RSU_direct_VUE_num_in_episodes = [] # 记录每一回合中非终态step的所有RSU直接服务的用户数
    nt_step_RSU_direct_VUE_num_average_in_episodes = []
    
    nt_step_RSU_relay_VUE_num_in_episodes = [] # 记录每一回合中非终态step的所有RSU中继服务的用户数
    nt_step_RSU_relay_VUE_num_average_in_episodes = []
    
    nt_step_RSU_VUE_num_in_episodes = [] # 记录每一回合中非终态step的所有RSU服务的用户数
    nt_step_RSU_VUE_num_average_in_episodes = []
    
    t_flag_in_episodes = []
    moving_nt_step_num_in_episodes = [] # 每回合跑的非终态步数
    t_reward_in_episodes = []  # 记录每一回合终态step的reward
    
    lowzero_gain_count_in_episodes = []
    lowzero_reward_temp_if_interval_count_in_episodes = []
    
    action_masking_count_set_in_episodes = []
    
    # 11+4+8+3+4+6 = 28
    episodes_data_record = [nt_step_rewards_in_episodes, 
                            nt_step_zero_offloading_gains_in_episodes, 
                            nt_step_offloading_gain_sums_in_episodes, 
                            nt_step_offloading_revised_gain_sums_in_episodes,
                            nt_step_MBS_relay_VUE_num_in_episodes, 
                            nt_step_relay_latency_maxs_in_episodes,
                            nt_step_latency_set_maxs_in_episodes,
                            nt_step_latency_set_sums_in_episodes,
                            nt_step_latency_max_intervals_in_episodes, 
                            nt_step_RSU_empty_flags_in_episodes, 
                            nt_step_MBS_empty_flags_in_episodes, 
                            
                            nt_step_VUE_distribution_in_RSU_in_episodes, 
                            nt_step_RSU_direct_VUE_num_in_episodes, 
                            nt_step_RSU_relay_VUE_num_in_episodes, 
                            nt_step_RSU_VUE_num_in_episodes, 
                            
                            nt_step_rewards_average_in_episodes, 
                            nt_step_zero_offloading_gains_average_in_episodes, 
                            nt_step_offloading_gain_sums_average_in_episodes, 
                            nt_step_offloading_revised_gain_sums_average_in_episodes,
                            nt_step_MBS_relay_VUE_num_average_in_episodes, 
                            nt_step_relay_latency_maxs_average_in_episodes,
                            nt_step_latency_set_maxs_average_in_episodes,
                            nt_step_latency_set_sums_average_in_episodes,
                            
                            nt_step_latency_max_intervals_sum_in_episodes, 
                            nt_step_RSU_empty_flags_sum_in_episodes, 
                            nt_step_MBS_empty_flags_sum_in_episodes,
                            
                            nt_step_VUE_distribution_in_RSU_average_in_episodes, 
                            nt_step_RSU_direct_VUE_num_average_in_episodes, 
                            nt_step_RSU_relay_VUE_num_average_in_episodes, 
                            nt_step_RSU_VUE_num_average_in_episodes, 
                            
                            t_flag_in_episodes, moving_nt_step_num_in_episodes, t_reward_in_episodes, \
                            lowzero_gain_count_in_episodes, lowzero_reward_temp_if_interval_count_in_episodes, \
                            
                            action_masking_count_set_in_episodes]
    
    
    for epoch in range(conf.n_epochs): # n_epochs=41，多个回合是一个epoch，对每个epoch循环，循环里面又对某一个epoch的每一个episode循环
    # 由于每个epoch中的n_eposodes=1,因此，epoch就看做是回合数
        # print("train epoch: %d" % epoch)
        episodes = [] # 记录这一个epoch中所有回合的数据
        for episode_idx in range(conf.n_eposodes): # conf.n_eposodes=1，每个epoch包含n_eposodes个回合，又对第epoch个epoch的每个episode进行循环
        # n_eposodes=1，那这个for循环就跑一次？
            episode_data_return = rollout_worker.generate_episode(episodes_count, epsilon, episode_idx)
            # 类对象rollout_worker调用了类中的函数generate_episode
            # 函数返回变量原本有三个，后面两个用下划线替代，表示被丢弃，就只取第一个返回变量。episode是一个字典结构，存储了一回合中的很多数据
            episodes_count += 1 # 每跑一回合
            episodes.append(episode_data_return[0]) # episodes存储多个回合的数据，每个元素是一个字典，记录了某一回合的数据
            # episodes里面有n_eposodes个元素，每个元素是一个字典，一个字典存储了一个回合的数据
            episode_rewards.append(episode_data_return[1])  # 记录此回合的回合奖励
            
            episode_data = episode_data_return[2]
            
            if episode_data[-5] > 0: # 非终态步数不为0
                for index in range(len(episodes_data_record)):
                    if index in Interval(0, 0+15-1):
                        episodes_data_record[index].append(episode_data[index])
                    elif index in Interval(15, 15+8-1):
                        episodes_data_record[index].append(round(sum(episode_data[index - 15]) / len(episode_data[index - 15]), 2))
                    elif index in Interval(23, 23+3-1):
                        episodes_data_record[index].append(int(sum(episode_data[index - 23 + 8])))
                    elif index in Interval(26, 26+4-1):
                        episode_data_row_sum = [sum(i) for i in zip(*episode_data[index - 26 + 11])]
                        episode_data_row_sum_average = [round(ele / episode_data[-5], 2) for ele in episode_data_row_sum]
                        episodes_data_record[index].append(episode_data_row_sum_average)
            else:
                for index in range(len(episodes_data_record)):
                    if index in Interval(0, 0+15-1):
                        episodes_data_record[index].append([])
                    elif index in Interval(15, 23+3-1):
                        episodes_data_record[index].append(0)
                    elif index in Interval(26, 26+4-1):
                        episodes_data_record[index].append([0]*conf.RSU_num)
            
            for index in range(5):
                episodes_data_record[-(index+2)].append(episode_data[-(index+2)])
            
            
            if len(accumulative_episode_rewards) == 0:
                accumulative_episode_rewards.append(episode_data_return[1])
            else:
                accumulative_episode_rewards.append(round(0.99*accumulative_episode_rewards[-1] + 0.01*episode_data_return[1], 3))
        
        
        if epsilon >= 0.15:
            if conf.epsilon_anneal_scale == 'step' and (epoch+1) % 1 == 0:
                anneal_epsilon = (start_epsilon - conf.end_epsilon) / conf.anneal_steps
                epsilon = epsilon - anneal_epsilon if epsilon > conf.end_epsilon else epsilon
        elif epsilon < 0.2:
            if conf.epsilon_anneal_scale == 'step' and (epoch+1) % 2 == 0:
                anneal_epsilon = (start_epsilon - conf.end_epsilon) / (1*conf.anneal_steps)
                epsilon = epsilon - anneal_epsilon if epsilon > conf.end_epsilon else epsilon
        
        start_epsilon = epsilon
        epsilon_set.append(round(epsilon, 3))
        
        total_steps_sum = int(sum(moving_nt_step_num_in_episodes[-conf.result_print_interval: ]))
        episode_end_num = len([ele for ele in t_reward_in_episodes[-conf.result_print_interval: ] if ele == conf.ABS_energy_out_penalty])
        episode_rewards_sum = int(sum(episode_rewards[-conf.result_print_interval: ]))
        latency_max_intervals_sum = int(sum(nt_step_latency_max_intervals_sum_in_episodes[-conf.result_print_interval: ]))
        RSU_empty_flags_sum = int(sum(nt_step_RSU_empty_flags_sum_in_episodes[-conf.result_print_interval: ]))
        MBS_empty_flags_sum = int(sum(nt_step_MBS_empty_flags_sum_in_episodes[-conf.result_print_interval: ]))
        total_lowzero_gains_sum = int(sum(lowzero_gain_count_in_episodes[-conf.result_print_interval: ]))
        total_bad_reward_if_sum = int(sum(lowzero_reward_temp_if_interval_count_in_episodes[-conf.result_print_interval: ]))
        latency_set_sums_average = int(sum(nt_step_latency_set_sums_average_in_episodes[-conf.result_print_interval: ]) / conf.result_print_interval)
        latency_set_maxs_average = int(sum(nt_step_latency_set_maxs_average_in_episodes[-conf.result_print_interval: ]) / conf.result_print_interval)
        
        
        if (episodes_count % conf.result_print_interval == 0):
            epoch_info = [episode_end_num, total_steps_sum, latency_set_sums_average, latency_set_maxs_average, '     ', episode_rewards_sum, '     ', \
                          episodes_count, round(epsilon, 3), total_lowzero_gains_sum, total_bad_reward_if_sum, latency_max_intervals_sum, \
                          time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))]
            epoch_info_set.append(epoch_info)
            epoch_info_set.append('\n')
        
        if epoch <= conf.start_show_epoch and ((epoch+1) % (conf.result_print_interval * 1) == 0):
            print("epoch:", ' ', total_lowzero_gains_sum, '   ', \
                                  latency_set_sums_average, latency_set_maxs_average, '   ', episode_rewards_sum, '   ', \
                                  epoch+1, round(epsilon, 3), time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        """"""
        if epoch > conf.start_show_epoch and ((epoch+1) % conf.result_print_interval == 0): # 每RESULT_PRINT_INTERVAL回合显示结果
            print("moving_nt_step_num_in_episodes:", [ele for ele in moving_nt_step_num_in_episodes[-conf.result_print_interval: ] if ele != 11])
            print("nt_step_zero_offloading_gains_average_in_episodes:", \
                  [round(ele, 1) for ele in nt_step_zero_offloading_gains_average_in_episodes[-conf.result_print_interval: ]])
            print("nt_step_offloading_revised_gain_sums_average_in_episodes:", \
                  [int(ele/10) for ele in nt_step_offloading_revised_gain_sums_average_in_episodes[-conf.result_print_interval: ]], '\n')
            print("nt_step_rewards_average_in_episodes:", [round(ele, 1) for ele in nt_step_rewards_average_in_episodes[-conf.result_print_interval: ]])
            print("nt_step_rewards_in_this_episode:", [round(ele, 1) for ele in episode_data[0]])
            #if epsilon < 0.2:
            #    print("action_masking_count_set_in_episode_set:", action_masking_count_set_in_episode_set[-conf.result_print_interval: ])
            t_flag_in_episodes
            print("t_flag_in_episodes:", [ele for ele in t_flag_in_episodes[-conf.result_print_interval: ] if ele != conf.bad_flag_num])
            print("last_step_reward_in_episode_set:", \
                  [episode_end_num, [round(ele, 1) for ele in t_reward_in_episodes[-conf.result_print_interval: ] if ele != conf.ABS_energy_out_penalty]])
            bad_episode_rewards_num = len([ele for ele in episode_rewards[-conf.result_print_interval: ] if ele < 0])
            print("epoch & episode_rewards:", \
                  [bad_episode_rewards_num, [int(ele) for ele in episode_rewards[-conf.result_print_interval: ]], episode_rewards_sum])
            print("    epoch:", '  ', RSU_empty_flags_sum, MBS_empty_flags_sum, total_lowzero_gains_sum, '   ', episode_rewards_sum, '   ', \
                               epoch+1, round(epsilon, 3), time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), '\n')
        
        curve_set = [episode_rewards, accumulative_episode_rewards, nt_step_rewards_average_in_episodes, nt_step_zero_offloading_gains_average_in_episodes, \
                     nt_step_offloading_gain_sums_average_in_episodes, nt_step_offloading_revised_gain_sums_average_in_episodes, \
                     nt_step_MBS_relay_VUE_num_average_in_episodes, nt_step_relay_latency_maxs_average_in_episodes, nt_step_latency_set_maxs_average_in_episodes, \
                     nt_step_latency_set_sums_average_in_episodes, \
                     nt_step_latency_max_intervals_sum_in_episodes, nt_step_RSU_empty_flags_sum_in_episodes, \
                     nt_step_MBS_empty_flags_sum_in_episodes, nt_step_VUE_distribution_in_RSU_average_in_episodes, \
                     nt_step_RSU_direct_VUE_num_average_in_episodes, nt_step_RSU_relay_VUE_num_average_in_episodes, nt_step_RSU_VUE_num_average_in_episodes, 
                     t_flag_in_episodes, moving_nt_step_num_in_episodes, t_reward_in_episodes, epoch_info_set, lowzero_gain_count_in_episodes]
        
        if episodes_count > conf.data_moving_save_frequency and (episodes_count + 1) % conf.data_moving_save_frequency == 0 and os.path.exists(moving_save_path):  # 如果文件存在
            shutil.rmtree(moving_save_path)  # 删除文件，可使用以下两种方法。
            #os.unlink(path)
            os.makedirs(moving_save_path)
        
        if episodes_count > 0 and (episodes_count + 1) % conf.data_moving_save_frequency == 0 and not fig_plot_flag:
            show_curves(fig_plot_flag, curve_set, moving_save_path)
        """"""
        
        # 上面生成了n_eposodes=1个回合的数据，并存储在episodes列表中
        episode_batch = episodes[0] # 上面的for循环生成了很多回合，此处取第一个episode的字典数据赋值给episode_batch
        episodes.pop(0) # 然后把第一个回合的数据从episodes中剔除
        for episode in episodes:
            for key in episode_batch.keys(): # 以列表形式（并非直接的列表，若要返回列表值还需调用list函数）返回字典中的所有的键
                episode_batch[key] = np.concatenate((episode_batch[key], episode[key]), axis=0)
                # np.concatenate()将第一回合的字典数据的每个key值与其余每个回合的对应key值拼接
                # 比如，一个episode字典的'o'的维度是self.episode_limit*self.n_agents*self.obs_shape=200*3*42，与n_eposodes=1个回合拼接之后
                # (n_eposodes-1+self.episode_limit)*self.n_agents*self.obs_shape=200*3*42
                 
        # 这个双for循环的目的就是将所有回合的字典数据压缩成一个字典数据，字典的'o'键值维度为200*3*42
        #print("episode_batch['o'].shape",  episode_batch['o'].shape)
        buffer.store_episode(episode_batch) # 存储episode_batch的数据
        #if epoch > 300 and (epoch + 1) % 10 == 0:
        
        for train_step in range(conf.train_steps): # conf.train_steps=1，和32行的train_steps的区别？？？
            mini_batch = buffer.sample(min(buffer.current_size, conf.batch_size)) # obs； (64, 200, 3, 42)
            # conf.batch_size=4；buffer.current_size的值不是0，而是由buffer类对象中的_get_storage_idx()函数决定
            # sample()从经验池buffer中随机采样一部分数据
            # print(mini_batch['o'].shape)
            agents.train(mini_batch, train_steps) # 训练函数。agents类函数调用类中的train函数
            # 为什么train_steps=1？训练一次？？？
            train_steps += 1 # train_steps自增1？？？这个train_steps和conf.train_steps的区别和关系？
        """"""
        # 这个for循环就一次？train_stpes自增变为1后就跳出循环了
        """
        if epoch % conf.evaluate_per_epoch == 0: # conf.evaluate_per_epoch=20，每隔固定回合数就进行evaluate，相当于定期评估
            evaluate_episode_reward_sum_average = evaluate(rollout_worker) # evaluate的作用是？？？
            evaluate_episode_rewards.append(evaluate_episode_reward_sum_average)
            #print("train epoch: {}, win rate: {}%, episode reward: {}".format(epoch, win_rate, episode_reward))
            # 打印format里面的三个变量数值，比如format(3, 0.2, 10))，就输出train epoch: 3, win rate: 0.2%, episode reward: 10
            # show_curves(win_rates, episode_rewards)
        """
    
    #print("episode_rewards:", [round(ele, 1) for ele in episode_rewards])
    #step_latency_max_intervals_in_episode_set = np.array(step_latency_max_intervals_in_episode_set).flatten().tolist() # 二维列表变一维列表
    #sum(nt_step_latency_max_intervals_in_episodes, [])
    curve_set = [episode_rewards, accumulative_episode_rewards, 
                 
                 nt_step_rewards_average_in_episodes, nt_step_zero_offloading_gains_average_in_episodes, 
                 nt_step_offloading_gain_sums_average_in_episodes, nt_step_offloading_revised_gain_sums_average_in_episodes, 
                 nt_step_MBS_relay_VUE_num_average_in_episodes, nt_step_relay_latency_maxs_average_in_episodes, 
                 nt_step_latency_set_maxs_average_in_episodes, nt_step_latency_set_sums_average_in_episodes,
                 nt_step_latency_max_intervals_sum_in_episodes, 
                 nt_step_RSU_empty_flags_sum_in_episodes, nt_step_MBS_empty_flags_sum_in_episodes, 
                 
                 nt_step_VUE_distribution_in_RSU_average_in_episodes, nt_step_RSU_direct_VUE_num_average_in_episodes, 
                 nt_step_RSU_relay_VUE_num_average_in_episodes, nt_step_RSU_VUE_num_average_in_episodes, 
                 
                 t_flag_in_episodes, moving_nt_step_num_in_episodes, t_reward_in_episodes, epoch_info_set, lowzero_gain_count_in_episodes]
    
    fig_plot_flag = True
    show_curves(fig_plot_flag, curve_set, save_path)
    
    writer.close()
"""
def evaluate(rollout_worker): # 输入参数是函数rollout_worker
    # print("="*15, " evaluating ", "="*15)
    evaluate_episode_reward_sum = 0
    for epoch in range(conf.evaluate_epoch): # conf.evaluate_epoch = 5, 这个变量是啥？？？
        generate_episode_return_part = rollout_worker.generate_episode \
        (0, this_step_rewards_average = 0, epsilon = 0, bad_offloading_return_flag = True, epoch, evaluate=True)
        # 这里调用generate_episode函数，丢弃第一个返回变量，保留后两个返回变量。和上面38行不一样
        evaluate_episode_reward_sum += generate_episode_return_part[1]
    evaluate_episode_reward_sum_average = evaluate_episode_reward_sum / conf.evaluate_epoch
    return evaluate_episode_reward_sum_average
"""

def show_curves(fig_plot_flag, curve_set, save_path):
    """
    #print("="*15, " generate curves ", "="*15)
    if fig_plot_flag:
        plt.figure()
        plt.axis([0, conf.n_epochs, 0, 100])
        plt.cla()
        plt.subplot(2, 1, 1)
        plt.plot(range(len(curve_set[0])), curve_set[0], marker = 'd', markersize = 4, color='darkorange')
        #plt.xlabel('epoch*{}'.format(conf.evaluate_per_epoch))
        plt.xlabel("epoch")
        plt.ylabel("episode rewards")
        plt.grid()
        if not fig_plot_flag: plt.close()
    
        plt.subplot(2, 1, 2)
        plt.plot(range(len(curve_set[1])), curve_set[1])
        #plt.xlabel('epoch*{}'.format(conf.evaluate_per_epoch))
        plt.xlabel("epoch")
        plt.ylabel("accumulative episode rewards")
        plt.grid()
        plt.savefig(save_path + '/1 epoch-episode rewards.png', format='png')
        if not fig_plot_flag: plt.close()
        
        plt.figure(2)
        plt.plot(range(len(curve_set[2])), curve_set[2], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("step_rewards_in_episode_average_set")
        plt.grid()
        plt.savefig(save_path + '/2 epoch-step_rewards_in_episode_average_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(3)
        plt.plot(range(len(curve_set[3])), curve_set[3], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("step")
        plt.ylabel("step_latency_max_intervals_in_episode_set")
        plt.grid()
        plt.savefig(save_path + '/3 step-step_latency_max_intervals_in_episode_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(4)
        plt.plot(range(len(curve_set[4])), curve_set[4], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("step_latency_max_intervals_in_episode_sum_set")
        plt.grid()
        plt.savefig(save_path + '/4 epoch-step_latency_max_intervals_in_episode_sum_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(5)
        plt.plot(range(len(curve_set[5])), curve_set[5], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("zero_offloading_gains_in_episode_average_set")
        plt.grid()
        plt.savefig(save_path + '/5 epoch-zero_offloading_gains_in_episode_average_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(6)
        plt.plot(range(len(curve_set[6])), curve_set[6], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("offloading_gain_sums_in_episode_average_set")
        plt.grid()
        plt.savefig(save_path + '/6 epoch-offloading_gain_sums_in_episode_average_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        """"""
        plt.figure(7)
        plt.plot(range(len(curve_set[7])), curve_set[7], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("RSU_empty_flags_in_episode_sum_set")
        plt.grid()
        """"""
        plt.figure(8)
        plt.plot(range(len(curve_set[8])), curve_set[8], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("MBS_empty_flags_in_episode_sum_set")
        plt.grid()
        plt.savefig(save_path + '/6 epoch-MBS_empty_flags_in_episode_sum_set.png', format='png')
        
        plt.figure(9)
        plt.plot(range(len(curve_set[9])), curve_set[9], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("last_step_reward_in_episode_set")
        plt.grid()
        plt.savefig(save_path + '/9 epoch-last_step_reward_in_episode_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(10)
        plt.plot(range(len(curve_set[10])), curve_set[10], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("total_steps_in_episode_set")
        plt.grid()
        plt.savefig(save_path + '/10 epoch-total_steps_in_episode_set.png', format='png')
        #if not fig_plot_flag: plt.close()
        
        plt.figure(11)
        plt.plot(range(len(curve_set[11])), curve_set[11], marker = 'd', markersize = 4, color='blue')
        plt.xlabel("epoch")
        plt.ylabel("bad_offloading_flags_in_episode_sum_set")
        plt.grid()
        plt.savefig(save_path + '/11 epoch-bad_offloading_flags_in_episode_sum_set.png', format='png')
        #if not fig_plot_flag: plt.close()
    """
    
    np.save(save_path + '/episode_rewards', curve_set[0])
    np.save(save_path + '/accumulative_episode_rewards', curve_set[1])
    
    np.save(save_path + '/nt_step_rewards_average_in_episodes', curve_set[2])
    np.save(save_path + '/nt_step_zero_offloading_gains_average_in_episodes', curve_set[3])
    np.save(save_path + '/nt_step_offloading_gain_sums_average_in_episodes', curve_set[4])
    np.save(save_path + '/nt_step_offloading_revised_gain_sums_average_in_episodes', curve_set[5])
    np.save(save_path + '/nt_step_MBS_relay_VUE_num_average_in_episodes', curve_set[6])
    
    np.save(save_path + '/nt_step_relay_latency_maxs_average_in_episodes', curve_set[7])
    np.save(save_path + '/nt_step_latency_set_maxs_average_in_episodes', curve_set[8])
    np.save(save_path + '/nt_step_latency_set_sums_average_in_episodes', curve_set[9])
    
    np.save(save_path + '/nt_step_latency_max_intervals_sum_in_episodes', curve_set[10])
    np.save(save_path + '/nt_step_RSU_empty_flags_sum_in_episodes', curve_set[11])
    np.save(save_path + '/nt_step_MBS_empty_flags_sum_in_episodes', curve_set[12])
    
    np.save(save_path + '/nt_step_VUE_distribution_in_RSU_average_in_episodes', curve_set[13])
    np.save(save_path + '/nt_step_RSU_direct_VUE_num_average_in_episodes', curve_set[14])
    np.save(save_path + '/nt_step_RSU_relay_VUE_num_average_in_episodes', curve_set[15])
    np.save(save_path + '/nt_step_RSU_VUE_num_average_in_episodes', curve_set[16])
    
    np.save(save_path + '/t_flag_in_episodes', curve_set[17])
    np.save(save_path + '/moving_nt_step_num_in_episodes', curve_set[18])
    np.save(save_path + '/t_reward_in_episodes', curve_set[19])
    np.save(save_path + '/epoch_info_set', curve_set[20])
    np.save(save_path + '/lowzero_gain_count_in_episodes', curve_set[21])
    
    """"""
    #plt.close()


if __name__ == "__main__":
    if conf.train:
        train()
        

