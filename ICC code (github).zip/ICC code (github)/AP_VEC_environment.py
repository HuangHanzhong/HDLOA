"""
Created on Tue Nov 10 06:17:06 2020
@author: leisureronaldo
This function is used for uplink computation offloading
"""
import numpy as np
import random
import math
import copy
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
from interval import Interval
from math import ceil

class VEC_env:
    def Rician_value(self, VUE_number, k_factor):
        Omega = 1
        x = np.random.randn(1, VUE_number) # randn 生成正态分布随机数
        y = np.random.randn(1, VUE_number)
        
        ss = math.sqrt(Omega / (2 * (1 + k_factor)))
        vv = math.sqrt(Omega * k_factor / (1 + k_factor))
        xx = ss*x+vv
        yy = ss*y
        xx_row = xx.shape[0]
        xx_col = xx.shape[1]
        xx = [ [math.pow(ele1, 2) for ele1 in ele0] for ele0 in xx.tolist() ] # 二维列表每个元素平方
        yy = [ [math.pow(ele1, 2) for ele1 in ele0] for ele0 in yy.tolist() ]
        
        channel_gain = [[0 for i in range(xx_col)] for j in range(xx_row)]
        for i in range(len(xx)):
           # 迭代输出列
           for j in range(len(xx[0])):
               channel_gain[i][j] = xx[i][j] + yy[i][j]
        #channel_gain_dB = [int(10*math.log(ele, 10)) for ele in channel_gain[0]]
        return channel_gain
    
    # https://blog.csdn.net/qq_27009517/article/details/109616809 tf的变量不能放在迭代中，否则内存会容易溢出
    def truncated_normal_model(self, VUE_num):
        VUE_speed_set_tensor = tf.random.truncated_normal( # 通过tf.random.truncated_normal生成长度为VUE_num的一维截断高斯数组
                                                          [VUE_num],
                                                          mean = self.conf.truncated_normal_mean,
                                                          stddev = self.conf.truncated_normal_stddev,
                                                          dtype = tf.dtypes.float32,
                                                          seed = None,
                                                          name = None)
        with tf.Session() as sess: # 假如长度为5，上述输出的VUE_speed_set_tensor为<tf.Tensor 'truncated_normal:0' shape=(5,) dtype=float32>
        # 需要tf.Session()和sess.run()，才能输出一维数组array([53.789173, 62.596733, 61.138756, 68.24399 , 60.86609 ], dtype=float32)
            VUE_speed_set = list(sess.run(VUE_speed_set_tensor)) # 然后再转换为list
        VUE_speed_set = [ele*self.conf.VUE_speed_unit_factor for ele in VUE_speed_set] # 速度单位是m/100ms
        return VUE_speed_set
    
    def __init__(self, conf):
        self.conf = conf
        # 下面是类实例变量，即实例化的特定类对象独有。在reset和step函数中通用
        self.VUE_x1_num = 0
        self.VUE_x2_num = 0
        self.VUE_coordinate_y_set = [0]*self.conf.VUE_num
        self.VUE_RSU_index_mapping = [-1]*self.conf.VUE_num
        self.VUE_MBS0_index_mapping = [0]*self.conf.VUE_num
        
        self.VM0_channel_gain_set = [0]*self.conf.VUE_num
        self.VH_channel_gain_set = [0]*(self.conf.VUE_num + 1)
        
        self.VUE_with_task_num = 0
        self.VUE_with_task_index_set = []
        self.VUE_task_type_index_set = [0]*self.conf.VUE_num
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num
        self.local_latency_if_set = [0]*self.conf.VUE_num
        self.obs = [0]*self.conf.VUE_num
        
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        self.ABS_available_energy = self.conf.ABS_energy_initial
        self.MBS_computing_resource_set = [0] * self.conf.MBS_num
        self.last_action = np.zeros((self.conf.n_agents, self.conf.n_actions), dtype=np.float32)
        self.state = np.empty(self.conf.state_shape, dtype=np.float32)
        self.avail_actions = []
        
        self.lowzero_gain_count_in_this_episode = 0
        self.lowzero_reward_temp_if_interval_count_in_this_episode = 0
        
    def reset(self): # 初始化每回合开始的obs和state
        self.VUE_x1_num = 0
        self.VUE_x2_num = 0
        """
        while self.VUE_x1_num == 0:
            self.VUE_x1_num = (random.sample(self.conf.VUE_index_set, 1))[0] # sample的结果是一个列表，要取出元素
        """
        self.VUE_x1_num = 10
        self.VUE_x2_num = self.conf.VUE_num - self.VUE_x1_num # 后面向左行驶的车辆数（x轴负轴）
        
        self.VUE_coordinate_y_set = [0]*self.conf.VUE_num
        VUE_x1_coordinate_y_set = random.sample(self.conf.x1_coordinate_candidates, self.VUE_x1_num) # 从坐标点候选集随机初始化车辆坐标
        VUE_x1_coordinate_y_set.sort() # 由小到大排序
        VUE_x2_coordinate_y_set = random.sample(self.conf.x2_coordinate_candidates, self.VUE_x2_num)
        VUE_x2_coordinate_y_set.sort()
        
        self.VUE_coordinate_y_set = VUE_x1_coordinate_y_set + VUE_x2_coordinate_y_set # 合并两条路的车辆坐标
        
        VUE_coordinate_y_set_candidate = []
        VUE_coordinate_y_set_candidate.append([-699, -649, -351, -301, -299, 199, 250, 301, 351, -660, -610, -550, -301, -180, -130, -80, -30, 30, 210, 260]) # [8, 1, 6, 3, 2]
        #VUE_coordinate_y_set_candidate.append([-149, -99, 101, 201, 301, 501, -251, -151, -51, 49, 99, 199, 249, 349, 449, 499, 549, 599]) # [1, 8, 9]
        #VUE_coordinate_y_set_candidate.append([-599, -449, 51, 251, 401, 501, -501, -401, -301, -201, -151, -51, 49, 99, 149, 349, 549, 599]) # [6, 6, 6]
        
        """
        VUE_coordinate_y_set_candidate.append([-99, 101, 201, 251, 401, 501, -451, -351, -101, -51, 49, 99, 299, 349, 399, 449, 499, 599]) # [2, 6, 10]
        VUE_coordinate_y_set_candidate.append([-549, -299, -49, 301, 401, 501, -451, -401, -351, -251, -101, 249, 349, 399, 449, 499, 549, 599]) # [6, 2, 4]
        VUE_coordinate_y_set_candidate.append([-599, -399, -349, -149, 51, 251, -451, -401, -351, -251, -201, 199, 249, 299, 349, 399, 449, 549]) # [8, 3, 7]
        VUE_coordinate_y_set_candidate.append([-449, -249, 151, 301, 401, 451, -501, -251, -201, -51, 49, 99, 149, 299, 349, 399, 549, 599]) # [5, 5, 8]
        VUE_coordinate_y_set_candidate.append([-549, 51, 201, 251, 401, 451, -501, -401, -251, -201, -1, 199, 249, 299, 349, 399, 499, 549]) # [5, 3, 10]
        VUE_coordinate_y_set_candidate.append([-399, -299, -249, -99, -49, 151, -501, -451, -401, -351, -201, -151, -101, 99, 199, 299, 499, 599]) # [8, 7, 3]
        #VUE_coordinate_y_set_candidate.append([-349, -199, -99, 251, 351, 501, -501, -451, -351, -151, -101, -1, 49, 199, 299, 349, 449, 549]) # [4, 7, 7]
        """
        VUE_coordinate_y_set_candidate_index = list(range(0, len(VUE_coordinate_y_set_candidate)))
        VUE_coordinate_y_set_index = random.sample(VUE_coordinate_y_set_candidate_index, 1)[0]
        self.VUE_coordinate_y_set = VUE_coordinate_y_set_candidate[VUE_coordinate_y_set_index]
        """"""
        self.VUE_RSU_index_mapping = [-1]*self.conf.VUE_num
        # 车辆与RSU的编号映射，比如第i个车辆在第j个RSU中，则self.VUE_RSU_index_mapping[i] = j。因为其元素有可能为0，即RSU编号0，因此初始化为-1
        self.VUE_MBS0_index_mapping = [0]*self.conf.VUE_num # 车辆与MBS0的编号映射，比如第i个车辆在第j个RSU中，则self.VUE_RSU_index_mapping[i] = j。
        for VUE_index in self.conf.VUE_index_set:
            for RSU_index in self.conf.RSU_index_set:
                if self.VUE_coordinate_y_set[VUE_index] in self.conf.RSU_y_range_set[RSU_index]:  # 如果VUE y坐标在此RSU范围内
                    self.VUE_RSU_index_mapping[VUE_index] = RSU_index # VUE与RSU的连接映射
            if self.VUE_coordinate_y_set[VUE_index] in self.conf.MBS0_y_range:  # 如果VUE y坐标在此MBS范围内
                self.VUE_MBS0_index_mapping[VUE_index] = 1 # VUE与MBS0的连接映射
                #self.VUE_index_in_MBS0_range_set.append(VUE_index) # 只要此车辆在MBS0内，就可以加到此列表中
        # 指数分布参考 https://blog.csdn.net/robert_chen1988/article/details/82887820
        # np.random.poisson(5, [2,2]) # 生成2*2的均值为5的泊松数组
        # random.expovariate(0.2) # 生成一个均值为0.2的指数分布随机数
        # generated_task_num = int(np.random.exponential(self.conf.exp_lambda, size=1)[0]) # 生成size=1的一维数组，取出元素再加int即一个随机整数
        
        ##### ------------------- 车辆与MBS0，HIBS的信道增益初始化 -------------------
        VUE_num_in_MBS0 = sum(self.VUE_MBS0_index_mapping)
        #if 
        VM0_channel_gain_set_temp = self.Rician_value(VUE_num_in_MBS0, self.conf.k_factor_VM)[0] # 先生成VUE_num_in_MBS0个增益值，此时还没有与VUE编号对应起来
        # 生成的是二维的列表，需要取0降成一维
        self.VM0_channel_gain_set = [0]*self.conf.VUE_num # 初始化
        for VUE_index in self.conf.VUE_index_set:
            if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 将增益值与在VM0范围内的VUE编号对应起来
                self.VM0_channel_gain_set[VUE_index] = VM0_channel_gain_set_temp[0] # 在MBS0中的VUE就有增益值，否则为0
                del VM0_channel_gain_set_temp[0]
        
        self.VH_channel_gain_set = [0]*(self.conf.VUE_num + 1) # 初始化
        self.VH_channel_gain_set = self.Rician_value(self.conf.VUE_num + 1, self.conf.k_factor_VH)[0] # 每个用户都在HIBS覆盖下
        
        
        generated_task_num = 0 # 初始化
        while generated_task_num not in Interval(self.conf.VUE_with_task_num_min, self.conf.VUE_num):
            generated_task_num = int(np.random.poisson(self.conf.task_generation_lambda, [1])[0])
            # 生成size=1的一维数组，取出元素再加int即一个随机整数
        """"""
        generated_task_num = self.conf.VUE_num
        
        self.VUE_with_task_num = 0 # 初始化
        self.VUE_with_task_num = generated_task_num
        
        self.VUE_with_task_index_set = [] # 初始化
        self.VUE_with_task_index_set = random.sample(self.conf.VUE_index_set, generated_task_num)
        self.VUE_with_task_index_set.sort()
        
        self.VUE_task_type_index_set = [0]*self.conf.VUE_num # 初始化
        self.VUE_task_type_index_set = np.random.choice(list(range(0, self.conf.task_type_num)), self.conf.VUE_num, p = self.conf.task_type_prob.ravel()).tolist()
        # 生成self.VUE_num个任务编号，下面只取有任务生成的车辆编号进行任务数据和计算需求赋值
        
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num # 初始化
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num # 初始化
        self.local_latency_if_set = [0]*self.conf.VUE_num # 初始化
        self.obs = [0]*self.conf.VUE_num
        last_gain_states = [0]*self.conf.VUE_num # 初始化
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                self.VUE_task_bit_size_set[VUE_index] = self.conf.task_bit_size_set[self.VUE_task_type_index_set[VUE_index]]
                self.VUE_task_computation_resource_requirement_set[VUE_index] = self.conf.task_computation_resource_requirement_set[self.VUE_task_type_index_set[VUE_index]]
                
                this_VUE_local_computing_latency_if = (self.VUE_task_computation_resource_requirement_set[VUE_index] / self.conf.VUE_computing_resource) * 1e3
                # 本地计算时延(ms)。如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                self.local_latency_if_set[VUE_index] = round(this_VUE_local_computing_latency_if, 3)
            
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + \
                                               [self.VUE_task_bit_size_set[VUE_index] / self.conf.task_bit_size_max] + \
                                               [self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max] + \
                                               [self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                      self.conf.task_computation_resource_requirement_max] + \
                                               [last_gain_states[VUE_index]] + self.last_action[VUE_index].tolist(), dtype=np.float32)
                # [round(self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max, 4)]
            else:
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + [0]*(self.conf.obs_shape - 1), dtype=np.float32)
        
        
        #VUE_speed_set = self.truncated_normal_model(self.conf.VUE_num)
        """
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
        """
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        VUE_index_set_in_each_RSU_mapping = [[], [], []] # 每个RSU中对应的VUE的编号集合
        VUE_task_computation_resource_requirement_set_in_each_RSU_mapping = [[], [], []] # 每个RSU里面的所有VUE的计算资源需求
        for VUE_index in self.VUE_with_task_index_set:
            RSU_index_for_this_VUE = int(self.VUE_RSU_index_mapping[VUE_index])
            self.VUE_with_task_num_in_RSU_set[RSU_index_for_this_VUE] += 1
            VUE_index_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(VUE_index)
            VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(self.VUE_task_computation_resource_requirement_set[VUE_index])
        
        #print("self.VUE_coordinate_y_set:", self.VUE_coordinate_y_set)
        #print("self.VUE_with_task_num_in_RSU_set:", self.VUE_with_task_num_in_RSU_set)
        #self.MBS_computing_resource = random.randint(self.conf.MBS_computing_resource_down, self.conf.MBS_computing_resource_up) * 1e9
        self.ABS_available_energy = self.conf.ABS_energy_initial
        
        self.MBS_computing_resource_set = [0] * self.conf.MBS_num
        for MBS_index in range(self.conf.MBS_num):
            if np.random.uniform() >= 0.1:
                self.MBS_computing_resource_set[MBS_index] = (self.conf.MBS_computing_resource_up - np.random.poisson(self.conf.Poisson_factor, size=1))[0] * 1e9
            else:
                self.MBS_computing_resource_set[MBS_index] = 0 # MBS资源有概率为0
        # CPU cycles/second MBS还要服务其余的用户等，因此设定随机可用计算资源
        
        self.last_action = np.zeros((self.conf.n_agents, self.conf.n_actions), dtype=np.float32)
        self.state = np.empty(self.conf.state_shape, dtype=np.float32)
        self.state = np.array([ele/self.conf.VUE_num for ele in self.VUE_with_task_num_in_RSU_set] + \
                              [self.ABS_available_energy / self.conf.ABS_energy_initial] + \
                              [ele/(self.conf.MBS_computing_resource_up*1e9) for ele in self.MBS_computing_resource_set], dtype=np.float32)
                              #+ \ self.last_action.flatten().tolist()
        self.avail_actions = [0]*self.conf.VUE_num
        #self.real_VUE_index_set = []
        
        for VUE_index in self.conf.VUE_index_set:
            this_avail_actions = [0]*self.conf.n_actions
            if VUE_index not in self.VUE_with_task_index_set:
                this_avail_actions[-1] = 1
            elif VUE_index in self.VUE_with_task_index_set:
                this_RSU_index = self.VUE_RSU_index_mapping[VUE_index]
                if this_RSU_index != -1: # 如果在某一RSU内
                    if len(VUE_index_set_in_each_RSU_mapping[this_RSU_index]) <= self.conf.beam_num_max: # 如果此RSU的用户数小于波束数
                        this_avail_actions[1 + this_RSU_index] = 1 # 则只能选择直连RSU
                        #continue # 这个用户只有一个可选动作，因此直接跳出此轮for循环
                    elif len(VUE_index_set_in_each_RSU_mapping[this_RSU_index]) > self.conf.beam_num_max:
                        VUE_task_computation_resource_requirement_set_in_each_RSU_mapping_sorted = sorted(VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index], reverse=True)
                        VUE_index_set_of_direct_RSU_mode = []
                        for index in range(len(VUE_index_set_in_each_RSU_mapping[this_RSU_index])):
                            # 取第一大的index
                            this_VUE_index_temp = VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index].index(VUE_task_computation_resource_requirement_set_in_each_RSU_mapping_sorted[index])
                            this_VUE_index = VUE_index_set_in_each_RSU_mapping[this_RSU_index][this_VUE_index_temp]
                            if len(VUE_index_set_of_direct_RSU_mode) < self.conf.beam_num_max:
                                VUE_index_set_of_direct_RSU_mode.append(this_VUE_index)
                            VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index][this_VUE_index_temp] = 0
                        
                        if VUE_index in VUE_index_set_of_direct_RSU_mode:
                            this_avail_actions[1 + RSU_index] = 1
                            #continue
                        else:
                            this_avail_actions = [1]*self.conf.n_actions
                            this_avail_actions[-1] = 0
                            this_avail_actions[1 + RSU_index] = 0 # 不能直连所在RSU，但可以中继到其他RSU
                            for MBS_index in range(self.conf.MBS_num):
                                if self.MBS_computing_resource_set[MBS_index] == 0: # 如果此MBS资源为空，则不能卸载到此MBS
                                    this_avail_actions[1 + self.conf.RSU_num + MBS_index] = 0
                elif this_RSU_index == -1: # 如果不在任一RSU内，除非MBS资源为空，否则本地。RSU，MBS，云都可以卸载
                    this_avail_actions = [1]*self.conf.n_actions
                    this_avail_actions[-1] = 0
                    for MBS_index in range(self.conf.MBS_num):
                        if self.MBS_computing_resource_set[MBS_index] == 0: # 如果此MBS资源为空，则不能卸载到此MBS
                            this_avail_actions[1 + self.conf.RSU_num + MBS_index] = 0
                
            self.avail_actions[VUE_index] = this_avail_actions
        
        self.lowzero_gain_count_in_this_episode = 0
        self.lowzero_reward_temp_if_interval_count_in_this_episode = 0
        
    def step(self, episodes_count, step, action_set):
        #bad_offloading_flag_num = 0
        generated_task_num_record = self.VUE_with_task_num  # 记录此数据return传给utils
        #good_offloading_VUE_num = 0
        
        local_num = 0
        offloading_mode_gain_sum = 0
        offloading_mode_revised_gain_sum = 0
        VUE_num_served_by_MBS = 0
        relay_latency_max = 0
        latency_set_max = 0
        latency_average = 0
        latency_set_sum = 0
        latency_max_interval = 0
        RSU_empty_flag = 0
        MBS_empty_flag = 0
        VUE_num_direct_served_by_RSU_set = [0]*self.conf.RSU_num
        VUE_num_relay_served_by_RSU_set = [0]*self.conf.RSU_num
        VUE_num_served_by_RSU_set = [0]*self.conf.RSU_num
        bad_offloading_flag_set = [0]*self.conf.bad_flag_num
        
        
        return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, relay_latency_max, latency_average, latency_set_sum, \
                       latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                       VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, \
                       self.lowzero_gain_count_in_this_episode, self.lowzero_reward_temp_if_interval_count_in_this_episode]
        
        #####
        if self.ABS_available_energy < self.conf.ABS_energy_threshold: # ABS能量阈值
            #print("ABS energy out")
            reward = self.conf.ABS_energy_out_penalty
            terminated = True
            return (reward, terminated, return_part)
        
        action_set_int = [int(i) for i in action_set]
        self.last_action = np.eye(self.conf.n_actions)[np.array(action_set_int, dtype=np.int)]
        
        VUE_relay_computing_node_mapping_matrix = [[0 for i in range(2)] for j in range(self.conf.VUE_num)]
        # 存储中继计算节点编号；第一列表示中继RSU的编号；第2列表示中继MBS0(如果是中继MBS0，则置为1)
        VUE_decision_flag_full_matrix = [[0 for i in range(1 + 2*self.conf.RSU_num + 2 + 1 + 1)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*11二维列表，第0列表示直接本地计算；第1~3列表示RSU的直连决策；
        # 后4~6列表示RSU中继决策；第7~8列表示MBS0的直连和中继决策；第9列表示MBS1中继决策；第10列表示中继云
        for VUE_index in self.VUE_with_task_index_set:
            if action_set[VUE_index] == 0: # 直接本地计算
                VUE_decision_flag_full_matrix[VUE_index][0] = 1
            elif action_set[VUE_index] in Interval(1, self.conf.RSU_num): # 如果决策值在这一区间，表示卸载到RSU
                the_RSU_index = action_set[VUE_index] - 1
                if the_RSU_index == int(self.VUE_RSU_index_mapping[VUE_index]): # 直接卸载RSU
                    VUE_decision_flag_full_matrix[VUE_index][1 + the_RSU_index] = 1 # int()保证列表索引为int
                    # 如果VUE_RSU_index_mapping[VUE_index]=0，则在VUE_decision_flag_full_matrix[VUE_index]中位于2+0列
                else: # 中继RSU
                    VUE_relay_computing_node_mapping_matrix[VUE_index][0] = the_RSU_index # 记录此VUE的中继RSU编号
                    VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + the_RSU_index] = 1
            elif action_set[VUE_index] == self.conf.RSU_num + 1: # 如果决策值为这个，表示卸载到MBS0
                if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 如果在MBS0中
                    VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] = 1
                elif self.VUE_MBS0_index_mapping[VUE_index] == 0: # 如果不在MBS0中，则中继
                    VUE_relay_computing_node_mapping_matrix[VUE_index][1] = 1 # 记录中继MBS0标识
                    VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1] = 1
            elif action_set[VUE_index] == self.conf.RSU_num + 1 + 1: # 如果决策值为这个，表示中继卸载到MBS1
                VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1] = 1
            elif action_set[VUE_index] == self.conf.RSU_num + 1 + 1 + 1: # 如果决策值为这个，表示中继到云
                VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1 + 1] = 1
        
        VUE_decision_flag_full_matrix_row_sum = [sum(i) for i in zip(*VUE_decision_flag_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_num_served_by_VUE = VUE_decision_flag_full_matrix_row_sum[0] # 直接本地计算的VUE数
        VUE_num_direct_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1: 1+self.conf.RSU_num] # 每个RSU直接服务的VUE数，是一个长度为RSU_num的列表
        VUE_num_relay_served_by_RSU_set = VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # 每个RSU中继服务的VUE数，长度为3的列表
        VUE_num_served_by_RSU_set = [VUE_decision_flag_full_matrix_row_sum[1] + VUE_decision_flag_full_matrix_row_sum[1+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[2] + VUE_decision_flag_full_matrix_row_sum[2+self.conf.RSU_num], \
                                     VUE_decision_flag_full_matrix_row_sum[3] + VUE_decision_flag_full_matrix_row_sum[3+self.conf.RSU_num]] # RSU服务的用户数量集合
        VUE_num_direct_served_by_MBS0 = VUE_decision_flag_full_matrix_row_sum[1 + 2*self.conf.RSU_num] # MBS0直接服务的VUE数
        VUE_num_relay_served_by_MBS0 = VUE_decision_flag_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1] # MBS0中继服务的VUE数
        VUE_num_served_by_MBS0 = VUE_num_direct_served_by_MBS0 + VUE_num_relay_served_by_MBS0
        VUE_num_served_by_MBS1 = VUE_decision_flag_full_matrix_row_sum[1+2*self.conf.RSU_num + 1 + 1] # MBS1中继服务的VUE数
        VUE_num_served_by_cloud = VUE_decision_flag_full_matrix_row_sum[1+2*self.conf.RSU_num + 1 + 1 + 1] # 云中继服务的VUE数
        beam_num_of_RSU_set = VUE_num_direct_served_by_RSU_set
        # ABS和RSU通过sub6，不是通过毫米波，所以这个RSU本地卸载用户就是毫米波波束个数
        
        
        
        # overload_RSU_num = len([ele for ele in beam_num_of_RSU_set if ele > self.conf.beam_num_max])
        # if overload_RSU_num == 1:
        #     overload_RSU_index = []
        #     relay_VUE_num_for_overload_RSU = []
        #     if max(beam_num_of_RSU_set) > self.conf.beam_num_max:
        #         for RSU_index in range(self.conf.RSU_num):
        #             if beam_num_of_RSU_set[RSU_index] > 4:
        #                 overload_RSU_index = RSU_index
        #                 relay_VUE_num_for_overload_RSU = VUE_num_relay_served_by_RSU_set[RSU_index] # 超载RSU对应的中继用户数
        # if overload_RSU_num > 0:
        #     self.lowzero_reward_temp_if_interval_count_in_this_episode += 1
        
        VUE_distribution = [VUE_num_served_by_VUE] + self.VUE_with_task_num_in_RSU_set + [VUE_num_direct_served_by_RSU_set + VUE_num_relay_served_by_RSU_set + \
                            VUE_num_served_by_RSU_set] + [VUE_num_direct_served_by_MBS0, VUE_num_relay_served_by_MBS0, VUE_num_served_by_MBS0] +\
                           [VUE_num_served_by_MBS1] + [VUE_num_served_by_cloud]
        
        """
        if sum(VUE_num_relay_served_by_RSU_set) == 0:
            RSU_empty_flag = 1
        if self.MBS_computing_resource != 0 and VUE_num_served_by_MBS == 0:
            MBS_empty_flag = 1
        """
        VUE_task_type_index_full_matrix = [[0 for i in range(self.conf.task_type_num)] for j in range(self.conf.VUE_num + self.conf.RSU_num + self.conf.MBS_num + 1)]
        # 行为每个节点编号，列为任务类型编号
        local_task_type_index_set = []
        edge_task_type_index_set = []
        for VUE_index in self.VUE_with_task_index_set:
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 本地计算
                VUE_task_type_index_full_matrix[VUE_index][self.VUE_task_type_index_set[VUE_index]] += 1
                local_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            for RSU_index in self.conf.RSU_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][1 + RSU_index] == 1 or \
                   VUE_decision_flag_full_matrix[VUE_index][1 + self.conf.RSU_num + RSU_index] == 1: # RSU计算
                    VUE_task_type_index_full_matrix[self.conf.VUE_num + RSU_index][self.VUE_task_type_index_set[VUE_index]] += 1
                    edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] == 1 or \
               VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1] == 1: # MBS0计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1] == 1: # MBS1计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num + 1][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
            if VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1 + 1] == 1: # cloud计算
                VUE_task_type_index_full_matrix[self.conf.VUE_num + self.conf.RSU_num + self.conf.MBS_num][self.VUE_task_type_index_set[VUE_index]] += 1
                edge_task_type_index_set.append(self.VUE_task_type_index_set[VUE_index])
        
        VUE_task_bit_size_full_matrix = [[0 for i in range(1 + 2*self.conf.RSU_num + 2 + 1 + 1)] for j in range(self.conf.VUE_num)]
        VUE_task_computation_resource_requirement_full_matrix = [[0 for i in range(1 + 2*self.conf.RSU_num + 2 + 1 + 1)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*11二维列表，表示VUE和本地/VUE/RSU/MBS0/MBS1/cloud的任务连接映射
        # 第0列表示直接本地计算；第1~3列表示RSU的直连决策；后4~6列表示RSU中继决策；第7~8列表示MBS0的直连和中继决策；第9列表示MBS1中继决策；第10列表示中继云
        for VUE_index in self.VUE_with_task_index_set:
            for index in range(1 + 2*self.conf.RSU_num + 2 + 1 + 1): # 遍历本地，直连RSU，中继RSU和MBS0, MBS1，cloud
                if VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = self.VUE_task_computation_resource_requirement_set[VUE_index]
                """
                if index == 1 and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_relay_computing_node_mapping_matrix[VUE_index][0]][index] += \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                    # 注意此处的行序号，比如如果VUE1中继到VUE3，那么此时就是VEU_index=1，然后赋值VUE_task_computation_resource_requirement_full_matrix[3][1]
                if index in [4, 5, 6] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                if index in [7, 8] and VUE_decision_flag_full_matrix[VUE_index][index] == 1:
                    VUE_task_bit_size_full_matrix[VUE_index][index] = self.VUE_task_bit_size_set[VUE_index]
                    VUE_task_computation_resource_requirement_full_matrix[VUE_index][index] = \
                                                                             self.VUE_task_computation_resource_requirement_set[VUE_index]
                """
                
        
        VUE_task_bit_size_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_bit_size_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_bit_size_relay_served_by_RSU_set = VUE_task_bit_size_full_matrix_row_sum[1+self.conf.RSU_num: 1+2*self.conf.RSU_num] # RSU中继服务的用户任务量集合
        VUE_task_bit_size_direct_served_by_MBS0 = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num]
        VUE_task_bit_size_relay_served_by_MBS0 = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1] # 索引[1 + 2*self.conf.RSU_num + 1]为中继卸载到MBS0的VUE任务量
        VUE_task_bit_size_relay_served_by_MBS1 = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1 + 1] # 索引[1 + 2*self.conf.RSU_num + 1 + 1]为中继卸载到MBS1的VUE任务量
        VUE_task_bit_size_relay_served_by_cloud = VUE_task_bit_size_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1 + 1 + 1] # 索引[1 + 2*self.conf.RSU_num + 1 + 1 + 1]为中继卸载到云端的VUE任务量
        VUE_task_bit_size_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set + [VUE_task_bit_size_relay_served_by_MBS0])
        #VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS = sum(VUE_task_bit_size_relay_served_by_RSU_set)
        VUE_task_bit_size_relay_served_by_HIBS = sum([VUE_task_bit_size_relay_served_by_MBS1, VUE_task_bit_size_relay_served_by_cloud])
        # ABS中继的总任务量
        
        VUE_task_computation_resource_requirement_full_matrix_row_sum = [sum(i) for i in zip(*VUE_task_computation_resource_requirement_full_matrix)] # 对二维列表按列求和得到一维列表
        VUE_task_computation_resource_requirement_served_by_RSU_set = [VUE_task_computation_resource_requirement_full_matrix_row_sum[1] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[2 + self.conf.RSU_num], \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3] + \
                                                                       VUE_task_computation_resource_requirement_full_matrix_row_sum[3 + self.conf.RSU_num]]
        # RSU中继服务的用户任务量集合
        VUE_task_computation_resource_requirement_served_by_MBS0 = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num] + \
                                                                   VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1]
        # 卸载到MBS0的VUE任务量
        
        VUE_task_computation_resource_requirement_served_by_MBS1 = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1 + 1]
        
        VUE_task_computation_resource_requirement_served_by_cloud = VUE_task_computation_resource_requirement_full_matrix_row_sum[1 + 2*self.conf.RSU_num + 1 + 1 + 1]
        
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
        
        VX_distance_set = [[0 for i in range(self.conf.RSU_num + 3)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*(RSU_num+3)二维列表，前三列表示VUE到RSU的距离，第四列到MBS0，第五列到ABS，第六列到HAPS的距离
        for VUE_index in self.conf.VUE_index_set:
            if self.VUE_RSU_index_mapping[VUE_index] >= 0: # 如果此VUE在某个RSU中。  若不在RSU中，此值会为-1
                VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index], dtype=np.float32) - \
                                                                                         np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])], dtype=np.float32))
            if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 如果在MBS0范围内
                VX_distance_set[VUE_index][3] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index], dtype=np.float32) - np.array(self.conf.MBS0_coordinate, dtype=np.float32))
            VX_distance_set[VUE_index][4] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index], dtype=np.float32) - np.array(self.conf.ABS_coordinate, dtype=np.float32))
            VX_distance_set[VUE_index][5] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index], dtype=np.float32) - np.array(self.conf.HIBS0_coordinate, dtype=np.float32))
        
        
        local_latency_set = [0]*self.conf.VUE_num
        RSU_direct_latency_set = [0]*self.conf.VUE_num
        RSU_relay_latency_set = [0]*self.conf.VUE_num
        MBS0_direct_latency_set = [0]*self.conf.VUE_num
        MBS0_relay_latency_set = [0]*self.conf.VUE_num
        MBS1_relay_latency_set = [0]*self.conf.VUE_num
        cloud_relay_latency_set = [0]*self.conf.VUE_num
        VUE_latency_full_matrix = [[0 for i in range(1 + 2*self.conf.RSU_num + 2 + 1 + 1)] for j in range(self.conf.VUE_num)]
        # 创建self.conf.VUE_num*11二维列表
        #relay_transmission_latency_sum = 0
               
        for VUE_index in self.VUE_with_task_index_set: # 遍历VUE
            if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                this_VUE_local_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                   self.conf.VUE_computing_resource) * 1e3 # 本地计算时延(ms)
                # 如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                local_latency_set[VUE_index] = this_VUE_local_computing_latency
                #print("local_latency_set[VUE_index]:", int(local_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][0] = int(local_latency_set[VUE_index])
                
            if 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]: # 如果选择直连RSU
                VUE_direct_served_RSU_index = VUE_decision_flag_full_matrix[VUE_index].index(1) - 1 # 此VUE直连的RSU编号
                this_VR_distance = VX_distance_set[VUE_index][VUE_direct_served_RSU_index]
                this_VR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VR_distance ** (-self.conf.VR_power_decay_exponent), 10)
                this_VR_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_mmW_antenna_gain + self.conf.RSU_rx_mmW_antenna_gain + this_VR_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * self.conf.mmW_bandwidth, 10)
                """
                if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VR_transmission_rate = self.conf.mmW_bandwidth * math.log(1 + 10**(this_VR_SNR/10), 2)
                this_VR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VR_transmission_rate) * 1e3 # 单位为ms
                # 20+34+91-(20*math.log(4*math.pi*28*10**9 / (3*10**8), 10) + 10*2*math.log(200,10) + np.random.normal(loc=0.0, scale=4, size=None))
                # 如果任务为CA，(1e6 / 1.7e9) * 1000 = 0.57, 毫米波速度非常快
                
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index]) * \
                                                                   self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_direct_served_RSU_index] error")
                this_VUE_RSU_direct_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_RSU) * 1e3 # 单位为ms
                # 如果任务为CA，分配了50%计算资源，(1e6*150/(6e9*50/100))*1000 = 50 ms
                RSU_direct_latency_set[VUE_index] = this_VR_transmission_latency + this_VUE_RSU_direct_computing_latency
                #print("RSU_direct_latency_set[VUE_index]:", int(RSU_direct_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + VUE_direct_served_RSU_index] = int(RSU_direct_latency_set[VUE_index])
                
            elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]: # 如果选择中继到RSU
                VUE_relay_served_RSU_index = VUE_relay_computing_node_mapping_matrix[VUE_index][0] # 此VUE中继的RSU编号
                this_VA_distance = VX_distance_set[VUE_index][-2]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/37e6)*1000 = 27 ms
                
                this_AR_distance = self.conf.AX_distance_set[VUE_relay_served_RSU_index]
                this_AR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                          10*math.log(this_AR_distance ** (-self.conf.AR_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_RSU_downlink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_down_for_VUE_RSU_relay_served_by_ABS error")
                this_AR_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.RSU_rx_sub6_antenna_gain + this_AR_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_RSU_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AR_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AR_transmission_rate = this_RSU_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AR_SNR/10), 2)
                this_AR_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AR_transmission_rate) * 1e3 # 多个VUE的任务从ABS一起传输到RSU
                # 如果任务为CA， (1e6/96e6)*1000 = 10 ms
                if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] > 0:
                    this_VUE_computing_resource_allocated_by_RSU = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index]) * \
                                                                    self.conf.RSU_computing_resource
                else:
                    print("VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] error")
                #if VUE_task_computation_resource_requirement_served_by_RSU_set[VUE_relay_served_RSU_index] == 0:
                #    print(this_VUE_computing_resource_allocated_by_RSU)
                this_VUE_RSU_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_RSU) * 1e3
                RSU_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AR_transmission_latency + this_VUE_RSU_relay_computing_latency
                #print("RSU_relay_latency_set[VUE_index]:", int(RSU_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + self.conf.RSU_num + VUE_relay_served_RSU_index] = int(RSU_relay_latency_set[VUE_index])
                #relay_transmission_latency_sum += this_VA_transmission_latency + this_AR_transmission_latency
                
            
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] == 1: # 如果选择直连到MBS0
                this_VM0_distance = VX_distance_set[VUE_index][self.conf.RSU_num]
                #this_VM0_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB +\
                #                           10*math.log(this_VM0_distance ** (-self.conf.VM_power_decay_exponent), 10)
                #if VUE_task_bit_size_direct_served_by_MBS0 > 0:
                #    this_VUE_uplink_bandwidth_allocated_by_MBS0 = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_direct_served_by_MBS0) * \
                #                                                   self.conf.sub6_bandwidth
                #else:
                #    print("this_VUE_uplink_bandwidth_allocated_by_MBS0 error")
                # 按任务量权重分配MBS0上行带宽
                #this_VM0_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_VM0_channel_gain_dB - \
                #               10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_MBS0, 10)
                """
                if this_VM0_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VM0_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                #this_VM0_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_MBS0 * math.log(1 + 10**(this_VM0_SNR/10), 2)
                
                G_directional = 10**((self.conf.VUE_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain)/10) # dbi转正常值
                c_light = self.conf.light_speed # m/s
                fc = self.conf.sub6_frequency * 10 ** 6 # 3.5*10**9 # 转换为Hz
                this_VM0_rician_channel_gain = self.VM0_channel_gain_set[VUE_index]
                G_H = G_directional * (c_light / (4*math.pi * this_VM0_distance * fc)) ** 2 * this_VM0_rician_channel_gain
                P_max = 10**((self.conf.VUE_tx_power_dBm - 30)/10) # W
                NO = 10**((self.conf.Gaussian_noise_psd_dBm_per_Hz - 30)/10) # 10^(-204/10) * 1e3; W
                # -174 dbm = -174-30 (-204dBW)，要先将dbm换成dBW，因为no最终的单位是W，不能是mW
                # https://www.elecfans.com/tools/dbm.htm (dBm和dBW的换算)
                if VUE_task_bit_size_direct_served_by_MBS0 > 0:
                    this_VUE_uplink_bandwidth_allocated_by_MBS0 = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_direct_served_by_MBS0) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("this_VUE_uplink_bandwidth_allocated_by_MBS0 error")
                # 按任务量权重分配MBS0上行带宽
                this_VM0_SNR = P_max * G_H / (NO * this_VUE_uplink_bandwidth_allocated_by_MBS0)
                #print("this_VM0_SNR:", 10*math.log(this_VM0_SNR, 10))
                """
                if this_VM0_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VM0_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VM0_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_MBS0 * math.log(1 + this_VM0_SNR, 2)
                this_VM0_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VM0_transmission_rate) * 1e3
                
                if VUE_task_computation_resource_requirement_served_by_MBS0 > 0:
                    this_VUE_computing_resource_allocated_by_MBS0 = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                     VUE_task_computation_resource_requirement_served_by_MBS0) * \
                                                                     self.MBS_computing_resource_set[0]
                else:
                    print("VUE_task_computation_resource_requirement_served_by_MBS0 error")
                this_VUE_MBS0_direct_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_MBS0) * 1e3
                MBS0_direct_latency_set[VUE_index] = this_VM0_transmission_latency + this_VUE_MBS0_direct_computing_latency
                #print("MBS0_direct_latency_set[VUE_index]:", int(MBS0_direct_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + 2*self.conf.RSU_num] = int(MBS0_direct_latency_set[VUE_index])
            
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1] == 1: # 如果选择中继到MBS0
                this_VA_distance = VX_distance_set[VUE_index][-2]
                this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB +\
                                          10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_ABS error")
                # 按任务量权重分配ABS上行带宽
                this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
                """
                if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VA_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
                this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
                
                this_AM0_distance = self.conf.AX_distance_set[-1]
                this_AM0_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                                           10*math.log(this_AM0_distance ** (-self.conf.AM_power_decay_exponent), 10)
                #MBS0_downlink_bandwidth_allocated_by_ABS = self.conf.sub6_bandwidth # MBS0独占AM带宽
                if VUE_task_bit_size_relay_served_by_ABS > 0:
                    MBS0_downlink_bandwidth_allocated_by_ABS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_ABS) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("MBS0_downlink_bandwidth_allocated_by_ABS error")
                this_AM0_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_AM0_channel_gain_dB - \
                              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * MBS0_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AM0_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AM0_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_AM0_transmission_rate = MBS0_downlink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_AM0_SNR/10), 2)
                this_AM0_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_AM0_transmission_rate) * 1e3
                # 如果任务为CA， (1e6/126e6)*1000 = 7.9 ms
                if VUE_task_computation_resource_requirement_served_by_MBS0 > 0:
                    this_VUE_computing_resource_allocated_by_MBS0 = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                    VUE_task_computation_resource_requirement_served_by_MBS0) * \
                                                                   self.MBS_computing_resource_set[0]
                else:
                    print("VUE_task_computation_resource_requirement_served_by_MBS0 error")
                this_VUE_MBS0_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                        this_VUE_computing_resource_allocated_by_MBS0) * 1e3
                MBS0_relay_latency_set[VUE_index] = this_VA_transmission_latency + this_AM0_transmission_latency + this_VUE_MBS0_relay_computing_latency
                #print("MBS0_relay_latency_set[VUE_index]:", int(MBS0_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1] = int(MBS0_relay_latency_set[VUE_index])
                # relay_transmission_latency_sum += this_VA_transmission_latency + this_AM0_transmission_latency
            
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1] == 1: # 如果选择中继到MBS1
                this_VH_distance = VX_distance_set[VUE_index][-1] # 单位为m
                #this_VH_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB +\
                #                          10*math.log(this_VH_distance ** (-self.conf.VH_power_decay_exponent), 10)
                #this_VH_channel_gain_dB = 10*math.log(1.42*10**(-4) * math.pow(this_VH_distance, -2), 10) 
                # 参考Intelligent Offloading and Resource Allocation in HAP-Assisted MEC Networks (ICTC 2021)
                
                G_directional = 10**((self.conf.VUE_tx_sub6_antenna_gain + self.conf.HIBS_rx_sub6_antenna_gain)/10) # dbi转正常值
                c_light = self.conf.light_speed # m/s
                fc = self.conf.sub6_frequency * 10 ** 6 # 3.5*10**9 # 转换为Hz
                this_VH_rician_channel_gain = self.VH_channel_gain_set[VUE_index]
                G_H = G_directional * (c_light / (4*math.pi * this_VH_distance * fc)) ** 2 * this_VH_rician_channel_gain
                P_max = 10**((self.conf.VUE_tx_power_dBm - 30)/10) # W
                NO = 10**((self.conf.Gaussian_noise_psd_dBm_per_Hz - 30)/10) # 10^(-204/10) * 1e3; W
                # -174 dbm = -174-30 (-204dBW)，要先将dbm换成dBW，因为no最终的单位是W，不能是mW
                # https://www.elecfans.com/tools/dbm.htm (dBm和dBW的换算)
                if VUE_task_bit_size_relay_served_by_HIBS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_HIBS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_HIBS) * \
                                                                 self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_HIBS error")
                # 按任务量权重分配HIBS上行带宽
                
                this_VH_SNR = P_max * G_H / (NO * this_VUE_uplink_bandwidth_allocated_by_HIBS)
                #this_VH_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.HIBS_rx_sub6_antenna_gain + this_VH_channel_gain_dB - \
                #              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_HIBS, 10) - 10
                """
                if this_VH_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VH_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VH_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_HIBS * math.log(1 + this_VH_SNR, 2)
                this_VH_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VH_transmission_rate) * 1e3
                
                this_HM1_distance = self.conf.HIBS0_MBS1_distance
                #this_HM1_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                #                          10*math.log(this_HM1_distance ** (-self.conf.HM_power_decay_exponent), 10)
                G_directional = 10**((self.conf.HIBS_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain)/10) # dbi转正常值
                c_light = self.conf.light_speed # m/s
                fc = self.conf.sub6_frequency * 10 ** 6 # 3.5*10**9 # 转换为Hz
                this_HM1_rician_channel_gain = self.VH_channel_gain_set[-1]
                G_H = G_directional * (c_light / (4*math.pi * this_HM1_distance * fc)) ** 2 * this_HM1_rician_channel_gain
                P_max = 10**((self.conf.HIBS_tx_power_dBm - 30)/10) # W
                NO = 10**((self.conf.Gaussian_noise_psd_dBm_per_Hz - 30)/10) # 10^(-204/10) * 1e3; W
                # -174 dbm = -174-30 (-204dBW)，要先将dbm换成dBW，因为no最终的单位是W，不能是mW
                # https://www.elecfans.com/tools/dbm.htm (dBm和dBW的换算)
                #MBS1_downlink_bandwidth_allocated_by_HIBS = self.conf.sub6_bandwidth # MBS1独占HM带宽
                if VUE_task_bit_size_relay_served_by_MBS1 > 0:
                    this_VUE_backhaul_bandwidth_allocated_by_MBS1 = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_MBS1) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("this_VUE_backhaul_bandwidth_allocated_by_MBS1 error")
                # 按任务量权重分配MBS1回程带宽
                
                this_HM1_SNR = P_max * G_H / (NO * this_VUE_backhaul_bandwidth_allocated_by_MBS1)
                """
                if this_HM1_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_HM1_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_HM1_transmission_rate = this_VUE_backhaul_bandwidth_allocated_by_MBS1 * math.log(1 + this_HM1_SNR, 2)
                this_HM1_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_HM1_transmission_rate) * 1e3
                this_HM1_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / self.conf.HC_FSO_rate) * 1e3
                # 如果任务为CA， (1e6/126e6)*1000 = 7.9 ms
                if VUE_task_computation_resource_requirement_served_by_MBS1 > 0:
                    this_VUE_computing_resource_allocated_by_MBS1 = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                                     VUE_task_computation_resource_requirement_served_by_MBS1) * \
                                                                     self.MBS_computing_resource_set[1]
                else:
                    print("VUE_task_computation_resource_requirement_served_by_MBS1 error")
                this_VUE_MBS1_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         this_VUE_computing_resource_allocated_by_MBS1) * 1e3
                MBS1_relay_latency_set[VUE_index] = this_VH_transmission_latency + this_HM1_transmission_latency + this_VUE_MBS1_relay_computing_latency
                #print("MBS1_relay_latency_set[VUE_index]:", int(MBS1_relay_latency_set[VUE_index]))
                VUE_latency_full_matrix[VUE_index][-2] = int(MBS1_relay_latency_set[VUE_index])
                #relay_transmission_latency_sum += this_VH_transmission_latency + this_HM_transmission_latency
            
            elif VUE_decision_flag_full_matrix[VUE_index][1 + 2*self.conf.RSU_num + 1 + 1 + 1] == 1: # 如果选择中继到cloud
                this_VH_distance = VX_distance_set[VUE_index][-1]
                G_directional = 10**((self.conf.VUE_tx_sub6_antenna_gain + self.conf.HIBS_rx_sub6_antenna_gain)/10) # dbi转正常值
                c_light = self.conf.light_speed # m/s
                fc = self.conf.sub6_frequency * 10 ** 6 # 3.5*10**9 # 转换为Hz
                this_VH_rician_channel_gain = self.VH_channel_gain_set[VUE_index]
                G_H = G_directional * (c_light / (4*math.pi * this_VH_distance * fc)) ** 2 * this_VH_rician_channel_gain
                P_max = 10**((self.conf.VUE_tx_power_dBm - 30)/10) # W
                NO = 10**((self.conf.Gaussian_noise_psd_dBm_per_Hz - 30)/10) # 10^(-204/10) * 1e3; W
                # -174 dbm = -174-30 (-204dBW)，要先将dbm换成dBW，因为no最终的单位是W，不能是mW
                # https://www.elecfans.com/tools/dbm.htm (dBm和dBW的换算)
                if VUE_task_bit_size_relay_served_by_HIBS > 0:
                    this_VUE_uplink_bandwidth_allocated_by_HIBS = (self.VUE_task_bit_size_set[VUE_index] / VUE_task_bit_size_relay_served_by_HIBS) * \
                                                                   self.conf.sub6_bandwidth
                else:
                    print("VUE_task_bit_size_relay_served_by_HIBS error")
                # 按任务量权重分配HIBS上行带宽
                
                this_VH_SNR = P_max * G_H / (NO * this_VUE_uplink_bandwidth_allocated_by_HIBS)
                #print("this_VH_SNR:", 10*math.log(this_VH_SNR, 10))
                """
                if this_VH_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_VH_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                this_VH_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_HIBS * math.log(1 + this_VH_SNR, 2)
                this_VH_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VH_transmission_rate) * 1e3
                
                #this_HM_distance = self.conf.AX_distance_set[-1]
                #this_AM_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
                #                          10*math.log(this_AM_distance ** (-self.conf.AM_power_decay_exponent), 10)
                #MBS_downlink_bandwidth_allocated_by_ABS = self.conf.sub6_bandwidth # MBS独占AM带宽
                #this_AM_SNR = self.conf.ABS_tx_power_dBm + self.conf.ABS_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_AM_channel_gain_dB - \
                #              10*math.log( 10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * MBS_downlink_bandwidth_allocated_by_ABS, 10)
                """
                if this_AM_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
                    print("faillink:", this_AM_SNR)
                    reward = self.conf.fail_link_penalty
                    terminated = True
                    return (reward, terminated)
                """
                
                # ##### HIBS-RHIBS回程链路在当前时隙能够传输的比特数 #####-------------------------------------------
                #this_HH_distance = np.linalg.norm(np.array(self.conf.HIBS0_coordinate) - np.array(self.conf.HIBS1_coordinate)) / 1000 # km
                #this_HH_channel_gain_dB = self.conf.FSO_channel_gain_part * math.pow(self.conf.FSO_wavelength / (4 * math.pi * (self.conf.HIBS_HIBS_interval / 1000)), 2)
                #this_HH_transmission_rate = self.conf.FSO_transmission_rate_part * self.conf.HIBS_tx_power_mW * this_HH_channel_gain_dB
                
                this_HH_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / self.conf.HH_FSO_rate) * 1e3
                
                # ##### RHIBS-cloud回程链路在当前时隙能够传输的比特数 #####-------------------------------------------
                #this_HC_distance = np.linalg.norm(np.array(self.HIBS1_coordinate) - np.array(self.cloud_coordinate)) / 1000 # km
                #this_HC_channel_gain_dB = self.conf.FSO_channel_gain_part * math.pow(self.conf.FSO_wavelength /\
                #                          (4 * math.pi * (self.conf.HIBS1_cloud_interval / 1000)), 2) * self.conf.FSO_asl
                #this_HC_transmission_rate = self.conf.FSO_transmission_rate_part * self.conf.HIBS_tx_power_mW * this_HC_channel_gain_dB
                this_HC_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / self.conf.HC_FSO_rate) * 1e3
                
                # 如果任务为CA， (1e6/126e6)*1000 = 7.9 ms
                #if VUE_task_computation_resource_requirement_served_by_cloud > 0:
                #    this_VUE_computing_resource_allocated_by_cloud = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                #                                                      VUE_task_computation_resource_requirement_served_by_cloud) * \
                #                                                      self.conf.cloud_computing_resource
                #else:
                #    print("VUE_task_computation_resource_requirement_served_by_HIBS error")
                this_VUE_HIBS_relay_computing_latency = (self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                         self.conf.cloud_computing_resource) * 1e3
                cloud_relay_latency_set[VUE_index] = this_VH_transmission_latency + this_HH_transmission_latency + this_HC_transmission_latency + this_VUE_HIBS_relay_computing_latency
                # 云计算可以不考虑计算时延
                VUE_latency_full_matrix[VUE_index][-1] = int(cloud_relay_latency_set[VUE_index])
                #relay_transmission_latency_sum += this_VA_transmission_latency + this_AM_transmission_latency
        
        
        #low_step_penalty = 0
        """
        low_step_penalty_initial = -0.5
        if step < 6:
            low_step_penalty = low_step_penalty_initial
        elif step in Interval(6, 10):
            low_step_penalty = low_step_penalty_initial + 0.15 * (step-5)
        """
        
        
        
        
        latency_set = [ele for ele in [y for x in VUE_latency_full_matrix for y in x] if ele > 0] # 单位ms
        # [y for x in VUE_latency_full_matrix for y in x]，可以将二维的VUE_latency_full_matrix降为一维
        #print("self.local_latency_if_set:", self.local_latency_if_set)
        #print("RSU_direct_latency_set   :", RSU_direct_latency_set)
        #print("RSU_relay_latency_set    :", RSU_relay_latency_set)
        #relay_latency_set = [ele for ele in (RSU_relay_latency_set + MBS0_relay_latency_set) if ele > 0] # 单位ms
        #if len(relay_latency_set) > 0:
        #    relay_latency_max = max(relay_latency_set)
        #else:
        #    relay_latency_max = 0
        latency_set_sum = round(sum(latency_set), 3)
        latency_average = round(sum(latency_set) / len(latency_set), 3)
        """
        print("local_latency_set:", [int(ele) for ele in local_latency_set], '\n')
        print("RSU_direct_latency_set:", [int(ele) for ele in RSU_direct_latency_set], '\n')
        print("RSU_relay_latency_set:", [int(ele) for ele in RSU_relay_latency_set], '\n')
        print("MBS0_direct_latency_set:", [int(ele) for ele in MBS0_direct_latency_set], '\n')
        print("MBS0_relay_latency_set:", [int(ele) for ele in MBS0_relay_latency_set], '\n')
        print("MBS1_relay_latency_set:", [int(ele) for ele in MBS1_relay_latency_set], '\n')
        print("cloud_relay_latency_set:", [int(ele) for ele in cloud_relay_latency_set], '\n')
        """
        #print(int(latency_set_sum), int(latency_average), '\n')
        #print("VUE_distribution:", VUE_distribution)
        
        #local_latency_if_set_sum = round(sum(self.local_latency_if_set), 3) # 如果本地计算的时延总和
        #latency_set_max = round(max(latency_set), 3) # 最大用户时延值
        #local_latency_if_set_max = round(max(self.local_latency_if_set), 3) # 如果本地计算的最大时延
        #latency_max_interval = local_latency_if_set_max - latency_set_max # 本地计算模式和卸载模式的最大时延差，如果为正，则卸载效果好
        #offloading_mode_gain_sum = int(local_latency_if_set_sum - latency_set_sum) # 如果本地时延与实际时延总和的差值，即选择卸载模式之后的增益
        
        offloading_mode_gain_set = [0]*self.conf.VUE_num # 每个用户的卸载增益
        offloading_mode_revised_gain_sum = 0 # 修改的增益总和。不同于offloading_mode_gain_sum，这个会对增益为负的用户做惩罚
        #lowzero_gain_index_set = [] # 负增益的边缘节点编号
        #good_gain_extra_score_sum = 0 # 正增益额外加的分
        #RSU_gain_set = [0]*self.conf.RSU_num
        #RSU_direct_gain_set = [[], [], []]
        #RSU_relay_gain_set = [[], [], []]
        #MBS_gain_set = []
        #local_num = 0
        last_gain_states = [0]*self.conf.VUE_num
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                if VUE_decision_flag_full_matrix[VUE_index][0] == 1: # 如果选择直接本地计算
                    offloading_mode_gain_set[VUE_index] = 0
                    #offloading_mode_revised_gain_sum += -20
                    local_num += 1
                elif 1 in VUE_decision_flag_full_matrix[VUE_index][1: ]:
                    offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:])
                    offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                    if offloading_mode_gain_set[VUE_index] < 0: # 为负
                        last_gain_states[VUE_index] = 1 # 如果增益为负，则增益状态置为1
                
                # elif 1 in VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num]:
                #     RSU_index = VUE_decision_flag_full_matrix[VUE_index][1: 1+self.conf.RSU_num].index(1)
                #     """
                #     offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:]) # 增益为正才好
                #     if offloading_mode_gain_set[VUE_index] < 0: # 为负
                #         lowzero_gain_index_set.append(RSU_index)
                #         offloading_mode_gain_set[VUE_index] += -100
                #     else:
                #         good_gain_extra_score_sum += 50
                #         offloading_mode_gain_set[VUE_index] += 50
                #     if beam_num_of_RSU_set[RSU_index] > self.conf.beam_num_max:
                #         offloading_mode_gain_set[VUE_index] = -50
                #     RSU_gain_set[RSU_index] += offloading_mode_gain_set[VUE_index]
                #     RSU_direct_gain_set[RSU_index].append(offloading_mode_gain_set[VUE_index])
                #     offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                #     """
                # elif 1 in VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num]:
                #     RSU_index = (VUE_decision_flag_full_matrix[VUE_index][1+self.conf.RSU_num: 1+2*self.conf.RSU_num].index(1))
                #     offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:])
                #     if offloading_mode_gain_set[VUE_index] < 0: # 为负
                #         lowzero_gain_index_set.append(RSU_index)
                #         #offloading_mode_gain_set[VUE_index] += -500
                #         last_gain_states[VUE_index] = 1 # 如果增益为负，则增益状态置为1
                #     else:
                #         good_gain_extra_score_sum += 30
                #         offloading_mode_gain_set[VUE_index] += 30
                #     RSU_gain_set[RSU_index] += offloading_mode_gain_set[VUE_index]
                #     RSU_relay_gain_set[RSU_index].append(int(offloading_mode_gain_set[VUE_index]))
                #     offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
                # elif VUE_decision_flag_full_matrix[VUE_index][-1] == 1:
                #     offloading_mode_gain_set[VUE_index] = self.local_latency_if_set[VUE_index] - sum(VUE_latency_full_matrix[VUE_index][:])
                #     if offloading_mode_gain_set[VUE_index] < 0: # 为负
                #         lowzero_gain_index_set.append(2*self.conf.RSU_num)
                #         #offloading_mode_gain_set[VUE_index] += -500
                #         last_gain_states[VUE_index] = 1
                #     else:
                #         offloading_mode_gain_set[VUE_index] += -int(offloading_mode_gain_set[VUE_index] * 0.6)
                #     MBS_gain_set.append(int(offloading_mode_gain_set[VUE_index]))
                #     offloading_mode_revised_gain_sum += offloading_mode_gain_set[VUE_index]
        
        #print(RSU_relay_gain_set, MBS_gain_set)
        offloading_mode_gain_set = [int(ele) for ele in offloading_mode_gain_set]
        offloading_mode_revised_gain_sum = int(offloading_mode_revised_gain_sum)
        #RSU_gain_set = [int(ele) for ele in RSU_gain_set]
        #zero_num_in_offloading_mode_gain_set = len([ele for ele in offloading_mode_gain_set if ele == 0]) # 增益为0的用户数
        #upzero_gains = [ele for ele in offloading_mode_gain_set if ele > 0]
        #upzero_gains_num = len(upzero_gains)
        lowzero_gains = [ele for ele in offloading_mode_gain_set if ele < 0] # 负增益集合
        lowzero_gains_num = len(lowzero_gains)
        if lowzero_gains_num == 0:
            lowzero_gains_sum = 0
        elif lowzero_gains_num > 0:
            self.lowzero_gain_count_in_this_episode += 1
            #print("lowzero_gain_count:", self.lowzero_gain_count_in_this_episode)
            lowzero_gains_sum = int(sum(lowzero_gains)) # 所有负增益的和
            #offloading_mode_revised_gain_sum += -good_gain_extra_score_sum # 如果有负增益，则把正增益加的分全部扣了
        
        #if (offloading_mode_revised_gain_sum < 600 or offloading_mode_gain_sum < 1500) and (lowzero_gains_sum < 0 or reward_temp_if_interval < 0):
        #if lowzero_gains_num >= 3:
        #    bad_offloading_flag_set[0] = 1
        #    bad_offloading_flag_num += 1
        """
        if overload_RSU_num > 0:
            bad_offloading_flag_set[1] = 1
            bad_offloading_flag_num += 1
        
        if latency_max_interval < 0:
            bad_offloading_flag_set[2] = 1
            bad_offloading_flag_num += 1
        """
        ######
        #if lowzero_gains_num > 0:
            #offloading_mode_revised_gain_sum += -400 + (-100)*(lowzero_gains_num-1)
        # if lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100:
        #     sRange = [100, 600]
        #     dRange = [0, 9.5]
        #     if offloading_mode_revised_gain_sum in Interval(sRange[0], sRange[1]):
        #         offloading_mode_revised_gain_sum_nor = (offloading_mode_revised_gain_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        #     elif offloading_mode_revised_gain_sum > sRange[1]:
        #         offloading_mode_revised_gain_sum_nor = 10
        # else:
        #     offloading_mode_revised_gain_sum_nor = -1
        """
        else:
            sRange = [-900, 0]
            dRange = [-10, -3]
            if offloading_mode_revised_gain_sum < sRange[0]:
                offloading_mode_revised_gain_sum_nor = -10
            if offloading_mode_revised_gain_sum in Interval(sRange[0], sRange[1]):
                offloading_mode_revised_gain_sum_nor = (offloading_mode_revised_gain_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
            elif offloading_mode_revised_gain_sum > sRange[1]:
                offloading_mode_revised_gain_sum_nor = -2
        """
        
        """
        if not (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100):
            relay_latency_max_nor = 0
        
        if not (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100) and relay_latency_max_nor >= 0:
            relay_latency_max_nor = 0
        if relay_latency_max_nor < 0 and (lowzero_gains_num == 0 and offloading_mode_revised_gain_sum >= 100):
            offloading_mode_revised_gain_sum_nor = 0
        """
        
        
        """
        sRange = [3, 7]
        dRange = [0, 10]
        if upzero_gains_num < sRange[0]:
            upzero_gains_num_nor = 0
        if upzero_gains_num in Interval(sRange[0], sRange[1]):
            upzero_gains_num_nor = (upzero_gains_num-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        elif upzero_gains_num > sRange[1]:
            upzero_gains_num_nor = 10
        """
        
        
        """
        if episodes_count > self.conf.start_show_epoch and 1 in bad_offloading_flag_set:
            print("bad_offloading_flag_set:", bad_offloading_flag_set, ' ', lowzero_gains_sum, ' ', int(offloading_mode_revised_gain_sum), ' ', \
                                              lowzero_gain_index_set, ' ', local_num, self.VUE_with_task_num_in_RSU_set, beam_num_of_RSU_set, \
                                              VUE_num_relay_served_by_RSU_set, VUE_num_served_by_MBS, ' ', '  ', step)
            print("                                 ", RSU_relay_gain_set, '  ', MBS_gain_set, '\n')
        """
        """
        if bad_offloading_flag_set[0] == 1:
            reward = -1
            reward += low_step_penalty
            terminated = True
            return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, \
                           latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                           VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, self.lowzero_gain_count_in_this_episode, \
                           self.lowzero_reward_temp_if_interval_count_in_this_episode]
            return (reward, terminated, return_part)
        
        if latency_max_interval < 0:
            reward = -1
            reward += low_step_penalty
            terminated = True
            return (reward, terminated, return_part)
        """
        """
        reward = 0.65*offloading_mode_revised_gain_sum_nor + 0.35*relay_latency_max_nor
        """
        
        #sRange = [2000, 1200] # generated_task_num随机
        sRange_p1 = [2900, 2500] # generated_task_num = VUE_num
        sRange_p2 = [2500, 1900]
        dRange_p1 = [0, 1]
        dRange_p2 = [0, 10]
        #print(latency_set, int(latency_set_sum))
        if latency_set_sum >= sRange_p1[0]: # [2900, +)
            sRange_sub = [sRange_p1[0] + 200, sRange_p1[0]]
            dRange_sub = [-2, 0]
            if latency_set_sum > sRange_sub[0]: # (3100, +)
                latency_set_sum_nor = dRange_sub[0]
            elif latency_set_sum in Interval(sRange_sub[0], sRange_sub[1]): # [3100, 2900]
                latency_set_sum_nor = (latency_set_sum-sRange_sub[0]) * (dRange_sub[1]-dRange_sub[0]) / (sRange_sub[1]-sRange_sub[0]) + dRange_sub[0]
        elif latency_set_sum in Interval(sRange_p1[0], sRange_p1[1], lower_closed=False): # (2900, 2500]
            # 这里的Interval虽然第一个数比第二个大，但lower_closed是安装参数顺序来设置的，不是按照参数大小设置开闭
            latency_set_sum_nor = (latency_set_sum-sRange_p1[0]) * (dRange_p1[1]-dRange_p1[0]) / (sRange_p1[1]-sRange_p1[0]) + dRange_p1[0]
        elif latency_set_sum in Interval(sRange_p2[0], sRange_p2[1], lower_closed=False): # (2500, 1900]
            latency_set_sum_nor = (latency_set_sum-sRange_p2[0]) * (dRange_p2[1]-dRange_p2[0]) / (sRange_p2[1]-sRange_p2[0]) + dRange_p2[0]
        elif latency_set_sum < sRange_p2[1]: # (1900, -)
            latency_set_sum_nor = dRange_p2[1]
        
        #sRange = [160, 80] # generated_task_num随机
        sRange = [140, 95] # generated_task_num = VUE_num
        dRange = [0, 10]
        #print("latency_average", int(latency_average))
        if latency_average > sRange[0]:
            sRange1 = [sRange[0] + 20, sRange[0]]
            dRange1 = [-2, 0]
            if latency_average > sRange1[0]:
                latency_average_nor = dRange1[0]
            elif latency_average in Interval(sRange1[0], sRange1[1]):
                latency_average_nor = (latency_average-sRange1[0]) * (dRange1[1]-dRange1[0]) / (sRange1[1]-sRange1[0]) + dRange1[0]
        elif latency_average in Interval(sRange[0], sRange[1]):
            latency_average_nor = (latency_average-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
        elif latency_average < sRange[1]:
            latency_average_nor = dRange[1]
            
        #if len(lowzero_gain_index_set) == 0:
        #    lowzero_gain_index_set = 0
        
        ##### rewar 1
        #this_weight = 0.6
        #reward = this_weight*latency_set_sum_nor + (1-this_weight)*latency_set_max_nor
        #reward = latency_average_nor 
        reward = latency_set_sum_nor
        # 经过验证，latency_set_sum_nor和latency_average_nor都可以
        #if self.MBS_computing_resource != 0 and latency_set_max >= 300:
        # if episodes_count in Interval(0, 1299):
        #     this_thre = 3400
        # else:
        #     this_thre = 3300
        """
        if latency_set_sum >= 3200: # or latency_set_max >= 290: # or self.last_reward == 1: #  or latency_set_max <= 260
            if reward > 0: reward *= 0.6
            elif reward < 0: reward *= 2
        
        if latency_set_max <= 260: # or self.last_bad_reward_count >= 3:
            if reward > 0: reward *= 0.8
        """
        flag1 = 0
        flag2 = 0
        lowzero_gains_sum_nor = 0
        #print(lowzero_gains_sum)
        if lowzero_gains_num > 0: # 如果负增益个数大于0
            flag1 = 1
            sRange = [-50, -1]
            dRange = [-10, -5]
            if lowzero_gains_sum < sRange[0]:
                lowzero_gains_sum_nor = dRange[0]
            if lowzero_gains_sum in Interval(sRange[0], sRange[1]):
                lowzero_gains_sum_nor = (lowzero_gains_sum-sRange[0]) * (dRange[1]-dRange[0]) / (sRange[1]-sRange[0]) + dRange[0]
            """"""
        if latency_set_max > self.conf.latency_threshold:
            flag2 = 1
        if sum([flag1, flag2]) > 0:
            reward = lowzero_gains_sum_nor*flag1 - flag2
            
        reward = max(min(reward, 10), -10)
        
        """
        #if 0 in VUE_num_served_by_RSU_set:
        if episodes_count > self.conf.start_show_episode and (episodes_count + 1) % int(self.conf.result_print_interval/1) == 0:
            print("reward:", \
                  [good_offloading_flag+1, round(reward, 2), int(offloading_mode_gain_sum), int(offloading_mode_revised_gain_sum), \
                   round(offloading_mode_revised_gain_sum / 2700, 2)], offloading_mode_gain_set)
            
            print("VUE_num: ", VUE_distribution, '\n', offloading_mode_gain_set, '\n')
            print("end:")
            
            print("local_latency_set:       ", local_latency_set)
            print("RSU_direct_latency_set:  ", RSU_direct_latency_set)
            print("RSU_relay_latency_set:   ", RSU_relay_latency_set)
            print("MBS_relay_latency_set:   ", MBS_relay_latency_set)
            print("VUE_decision_flag_full_matrix:", VUE_decision_flag_full_matrix)
            print("VUE_relay_computing_node_mapping_matrix:", VUE_relay_computing_node_mapping_matrix)
            print("VUE_latency_full_matrix:", VUE_latency_full_matrix)
            print("self.VUE_RSU_index_mapping:", self.VUE_RSU_index_mapping)
            print("action_set:              ", action_set)
            print("yes:")
        """
        
        VUE_speed_set = self.truncated_normal_model(self.conf.VUE_num)
        # [1.7, 1.6, 1.7, 1.5, 1.4, 1.7, 1.6, 1.5, 1.6, 1.6, 1.6, 1.6, 1.5, 1.7, 1.5, 1.5, 1.6, 1.7, 1.6, 1.5, 1.7, 1.8, 1.7, 1.6, 1.6, \
        # 1.6, 1.9, 1.6, 1.6, 1.8, 1.5, 1.7, 1.8, 1.7, 1.6, 1.8, 1.7, 1.5, 1.9, 1.6, 1.5, 1.5, 1.7, 1.6, 1.6, 1.7, 1.5, 1.5, 1.9, 1.6]
        
        VUE_x1_coordinate_y_set = self.VUE_coordinate_y_set[0: self.VUE_x1_num]
        VUE_x2_coordinate_y_set = self.VUE_coordinate_y_set[self.VUE_x1_num: ]
        
        for VUE_x1_index in range(self.VUE_x1_num): # x正轴道路的车辆沿y轴正方向（从左往右）行驶
            VUE_x1_coordinate_y_set[VUE_x1_index] = VUE_x1_coordinate_y_set[VUE_x1_index] + VUE_speed_set[VUE_x1_index]  # 更新VUE的y坐标
            if VUE_x1_coordinate_y_set[VUE_x1_index] > self.conf.coordinate_y_end: # 如果超出y轴右边界范围，则从左边重新进入道路
                VUE_x1_coordinate_y_set[VUE_x1_index] = self.conf.coordinate_y_begin + (VUE_x1_coordinate_y_set[VUE_x1_index] - self.conf.coordinate_y_end)
        VUE_x1_coordinate_y_set.sort() # 由小到大排序
        
        for VUE_x2_index in range(self.VUE_x2_num): # x负轴道路的车辆沿y轴负方向（从右往左）行驶
            VUE_x2_coordinate_y_set[VUE_x2_index] = VUE_x2_coordinate_y_set[VUE_x2_index] - VUE_speed_set[self.VUE_x1_num + VUE_x2_index]  # 更新VUE的y坐标
            # 注意VUE_speed_set的索引
            if VUE_x2_coordinate_y_set[VUE_x2_index] < self.conf.coordinate_y_begin: # 如果超出仿真范围，则从右边重新进入道路
                VUE_x2_coordinate_y_set[VUE_x2_index] = self.conf.coordinate_y_end + (VUE_x2_coordinate_y_set[VUE_x2_index] - self.conf.coordinate_y_begin)
        VUE_x2_coordinate_y_set.sort() # 由小到大排序
        
        self.VUE_coordinate_y_set = VUE_x1_coordinate_y_set + VUE_x2_coordinate_y_set # 合并两条路的车辆坐标
        
        self.VUE_RSU_index_mapping = [-1]*self.conf.VUE_num # 重新初始化VUE_RSU_index_mapping
        self.VUE_MBS0_index_mapping = [0]*self.conf.VUE_num # 车辆与MBS0的编号映射，比如第i个车辆在第j个RSU中，则self.VUE_RSU_index_mapping[i] = j。
        for VUE_index in self.conf.VUE_index_set:
            for RSU_index in self.conf.RSU_index_set:
                if self.VUE_coordinate_y_set[VUE_index] in self.conf.RSU_y_range_set[RSU_index]:  # 如果VUE y坐标在此RSU范围内
                    self.VUE_RSU_index_mapping[VUE_index] = RSU_index # VUE与RSU的连接映射
            
            if self.VUE_coordinate_y_set[VUE_index] in self.conf.MBS0_y_range:  # 如果VUE y坐标在此MBS范围内
                self.VUE_MBS0_index_mapping[VUE_index] = 1 # VUE与MBS0的连接映射
        
        ##### ------------------- 车辆与MBS0，HIBS的信道增益初始化 -------------------
        VUE_num_in_MBS0 = sum(self.VUE_MBS0_index_mapping)
        VM0_channel_gain_set_temp = self.Rician_value(VUE_num_in_MBS0, self.conf.k_factor_VM)[0] # 先生成VUE_num_in_MBS0个增益值，此时还没有与VUE编号对应起来
        # 生成的是二维的列表，需要取0降成一维
        self.VM0_channel_gain_set = [0]*self.conf.VUE_num # 初始化
        for VUE_index in self.conf.VUE_index_set:
            if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 将增益值与在VM0范围内的VUE编号对应起来
                self.VM0_channel_gain_set[VUE_index] = VM0_channel_gain_set_temp[0] # 在MBS0中的VUE就有增益值，否则为0
                del VM0_channel_gain_set_temp[0]
        
        self.VH_channel_gain_set = [0]*(self.conf.VUE_num + 1) # 初始化
        self.VH_channel_gain_set = self.Rician_value(self.conf.VUE_num + 1, self.conf.k_factor_VH)[0] # 每个用户都在HIBS覆盖下
        
        
        generated_task_num = 0 # 初始化
        while generated_task_num not in Interval(self.conf.VUE_with_task_num_min, self.conf.VUE_num):
            generated_task_num = int(np.random.poisson(self.conf.task_generation_lambda, [1])[0])
            # 生成size=1的一维数组，取出元素再加int即一个随机整数
        """"""
        generated_task_num = self.conf.VUE_num
        self.VUE_with_task_num = 0 #初始化
        self.VUE_with_task_num = generated_task_num
        self.VUE_with_task_index_set = []
        self.VUE_with_task_index_set = random.sample(self.conf.VUE_index_set, generated_task_num)
        self.VUE_with_task_index_set.sort()
        
        self.VUE_task_bit_size_set = [0]*self.conf.VUE_num
        self.VUE_task_computation_resource_requirement_set = [0]*self.conf.VUE_num
        self.local_latency_if_set = [0]*self.conf.VUE_num
        self.obs = [0]*self.conf.VUE_num
        
        self.VUE_task_type_index_set = [0]*self.conf.VUE_num # 初始化
        self.VUE_task_type_index_set = np.random.choice(list(range(0, self.conf.task_type_num)), self.conf.VUE_num, p = self.conf.task_type_prob.ravel()).tolist()
        # 生成self.VUE_num个任务编号，下面只取有任务生成的车辆编号进行任务数据和计算需求赋值
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index in self.VUE_with_task_index_set:
                self.VUE_task_bit_size_set[VUE_index] = self.conf.task_bit_size_set[self.VUE_task_type_index_set[VUE_index]]
                self.VUE_task_computation_resource_requirement_set[VUE_index] = self.conf.task_computation_resource_requirement_set[self.VUE_task_type_index_set[VUE_index]]
                
                this_VUE_local_computing_latency_if = (self.VUE_task_computation_resource_requirement_set[VUE_index] / self.conf.VUE_computing_resource) * 1e3
                # 本地计算时延(ms)。如果任务为CA，则(1e6*150/1e9) * 1000 = 150 ms； LPA: (2e6*50/1e9) * 1000 = 100 ms
                self.local_latency_if_set[VUE_index] = round(this_VUE_local_computing_latency_if, 3)
            
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + \
                                               [self.VUE_task_bit_size_set[VUE_index] / self.conf.task_bit_size_max] + \
                                               [self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max] + \
                                               [self.VUE_task_computation_resource_requirement_set[VUE_index] / \
                                                      self.conf.task_computation_resource_requirement_max] + \
                                                [last_gain_states[VUE_index]] + self.last_action[VUE_index].tolist(), dtype=np.float32)
                # [round(self.local_latency_if_set[VUE_index] / self.conf.local_computing_latency_max, 4)]
            else:
                self.obs[VUE_index] = np.array([self.VUE_coordinate_y_set[VUE_index] / self.conf.coordinate_y_end] + [0]*(self.conf.obs_shape - 1), dtype=np.float32)
        """
        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
        VX_distance_set = [[0 for i in range(self.conf.RSU_num + 3)] for j in range(self.conf.VUE_num)]
        # 创建VUE_num*(RSU_num + 3)二维列表，前三列表示VUE到RSU的距离，第四列到MBS0，第五列到ABS，第六列到HAPS的距离
        for VUE_index in self.conf.VUE_index_set:
            if VUE_index <= self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            elif VUE_index > self.VUE_x1_num - 1:
                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
            
            if self.VUE_RSU_index_mapping[VUE_index] >= 0: # 如果此VUE在某个RSU中。  若不在RSU中，此值会为-1
                VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - \
                                                                                         np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])]))
            if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 如果在MBS0范围内
                VX_distance_set[VUE_index][3] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.MBS0_coordinate))
            VX_distance_set[VUE_index][4] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.ABS_coordinate))
            VX_distance_set[VUE_index][5] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.HIBS0_coordinate))
        """
        
        self.VUE_with_task_num_in_RSU_set = [0]*self.conf.RSU_num # 统计每个RSU中有任务的用户数
        VUE_index_set_in_each_RSU_mapping = [[], [], []] # 每个RSU中对应的VUE的编号集合
        VUE_task_computation_resource_requirement_set_in_each_RSU_mapping = [[], [], []] # 每个RSU里面的所有VUE的计算资源需求
        for VUE_index in self.VUE_with_task_index_set:
            RSU_index_for_this_VUE = int(self.VUE_RSU_index_mapping[VUE_index])
            self.VUE_with_task_num_in_RSU_set[RSU_index_for_this_VUE] += 1
            VUE_index_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(VUE_index)
            VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(self.VUE_task_computation_resource_requirement_set[VUE_index])
        
        self.ABS_available_energy = self.ABS_available_energy - 1
        self.MBS_computing_resource_set = [0]*self.conf.MBS_num # 初始化
        #self.MBS_computing_resource = random.randint(self.conf.MBS_computing_resource_down, self.conf.MBS_computing_resource_up) * 1e9
        for MBS_index in range(self.conf.MBS_num):
            if np.random.uniform() >= 0.1:
                self.MBS_computing_resource_set[MBS_index] = (self.conf.MBS_computing_resource_up - np.random.poisson(self.conf.Poisson_factor, size=1))[0] * 1e9
            else:
                self.MBS_computing_resource_set[MBS_index] = 0 # MBS资源有概率为0
        # CPU cycles/second MBS还要服务其余的用户等，因此设定随机可用计算资源
        
        self.state = np.empty(self.conf.state_shape, dtype=np.float32) # 初始化
        self.state = np.array([ele/self.conf.VUE_num for ele in self.VUE_with_task_num_in_RSU_set] + \
                              [self.ABS_available_energy / self.conf.ABS_energy_initial] + \
                              [ele / (self.conf.MBS_computing_resource_up*1e9) for ele in self.MBS_computing_resource_set], dtype=np.float32)
            # + \ self.last_action.flatten().tolist()
        
        self.avail_actions = [0]*self.conf.VUE_num
        
        for VUE_index in self.conf.VUE_index_set:
            this_avail_actions = [0]*self.conf.n_actions
            if VUE_index not in self.VUE_with_task_index_set:
                this_avail_actions[-1] = 1
            elif VUE_index in self.VUE_with_task_index_set:
                this_RSU_index = self.VUE_RSU_index_mapping[VUE_index]
                if this_RSU_index != -1: # 如果在某一RSU内
                    if len(VUE_index_set_in_each_RSU_mapping[this_RSU_index]) <= self.conf.beam_num_max: # 如果此RSU的用户数小于波束数
                        this_avail_actions[1 + this_RSU_index] = 1 # 则只能选择直连RSU
                        #continue # 这个用户只有一个可选动作，因此直接跳出此轮for循环
                    elif len(VUE_index_set_in_each_RSU_mapping[this_RSU_index]) > self.conf.beam_num_max:
                        VUE_task_computation_resource_requirement_set_in_each_RSU_mapping_sorted = sorted(VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index], reverse=True)
                        VUE_index_set_of_direct_RSU_mode = []
                        for index in range(len(VUE_index_set_in_each_RSU_mapping[this_RSU_index])):
                            # 取第一大的index
                            this_VUE_index_temp = VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index].index(VUE_task_computation_resource_requirement_set_in_each_RSU_mapping_sorted[index])
                            this_VUE_index = VUE_index_set_in_each_RSU_mapping[this_RSU_index][this_VUE_index_temp]
                            if len(VUE_index_set_of_direct_RSU_mode) < self.conf.beam_num_max:
                                VUE_index_set_of_direct_RSU_mode.append(this_VUE_index)
                            VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[this_RSU_index][this_VUE_index_temp] = 0
                        
                        if VUE_index in VUE_index_set_of_direct_RSU_mode:
                            this_avail_actions[1 + RSU_index] = 1
                            #continue
                        else:
                            this_avail_actions = [1]*self.conf.n_actions
                            this_avail_actions[-1] = 0
                            this_avail_actions[1 + RSU_index] = 0 # 不能直连所在RSU，但可以中继到其他RSU
                            for MBS_index in range(self.conf.MBS_num):
                                if self.MBS_computing_resource_set[MBS_index] == 0: # 如果此MBS资源为空，则不能卸载到此MBS
                                    this_avail_actions[1 + self.conf.RSU_num + MBS_index] = 0
                elif this_RSU_index == -1: # 如果不在任一RSU内，除非MBS资源为空，否则本地。RSU，MBS，云都可以卸载
                    this_avail_actions = [1]*self.conf.n_actions
                    this_avail_actions[-1] = 0
                    for MBS_index in range(self.conf.MBS_num):
                        if self.MBS_computing_resource_set[MBS_index] == 0: # 如果此MBS资源为空，则不能卸载到此MBS
                            this_avail_actions[1 + self.conf.RSU_num + MBS_index] = 0
                
            self.avail_actions[VUE_index] = this_avail_actions
            
        
        terminated = False
        return_part = [local_num, offloading_mode_gain_sum, offloading_mode_revised_gain_sum, VUE_num_served_by_MBS, relay_latency_max, latency_average, latency_set_sum, \
                       latency_max_interval, RSU_empty_flag, MBS_empty_flag, self.VUE_with_task_num_in_RSU_set, VUE_num_direct_served_by_RSU_set, \
                       VUE_num_relay_served_by_RSU_set, VUE_num_served_by_RSU_set, bad_offloading_flag_set, \
                       self.lowzero_gain_count_in_this_episode, self.lowzero_reward_temp_if_interval_count_in_this_episode]
        
        return (reward, terminated, return_part)
