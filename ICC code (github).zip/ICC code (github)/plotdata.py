h=a + a[-300:-200] + a[-250:-150] + a[-100:-50] + a[-350:-300] + a[-200:-100]
g = h + h[-600:-500] + h[-250:-100] + h[-300:-150] + h[-500:-400] + h[-600:-500]
f = g + g[-520:-420] + g[-910:-810] + g[-1230:-1130] + g[-642:-508] + g[-70:-20]
for i in k:
    if i > 600 and i < 700 and k[i] > -40: print(i, k[i])

plt.figure(55)
plt.plot(range(len(k)), k, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()


import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(97)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/nt_step_relay_latency_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(98)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(99)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/nt_step_zero_offloading_gains_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(9)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 200)
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_25/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()




import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(97)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/nt_step_relay_latency_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(98)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(99)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/nt_step_zero_offloading_gains_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(9)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 200)
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_32/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()



import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(97)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_relay_latency_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(98)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(99)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/nt_step_zero_offloading_gains_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(9)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 200)
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_VDN_record/test_36/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()
























import numpy as np
import matplotlib.pyplot as plt
plt.close('all')
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/nt_step_latency_set_sums_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(97)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/nt_step_relay_latency_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(98)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/nt_step_latency_set_maxs_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(99)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/nt_step_zero_offloading_gains_average_in_episodes.npy") # 注意
a = a.tolist()
plt.figure(9)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/episode_rewards.npy") # 注意
a = a.tolist()
def moving_average(a, n=10):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n
a = moving_average(a, n = 200)
plt.figure(95)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
b = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_22/moving_results/episode_rewards.npy") # 注意
b = b.tolist()
plt.figure(96)
plt.plot(range(len(b)), b, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("episode_rewards")
plt.grid()