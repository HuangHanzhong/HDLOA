import numpy as np
import matplotlib.pyplot as plt
def smooth(data, sm=1):
    smooth_data = []
    if sm > 1:
        for d in data:
            z = np.ones(len(d))
            y = np.ones(sm)*1.0
            d = np.convolve(y, d, "same")/np.convolve(y, z, "same")
            smooth_data.append(d)
    return smooth_data
a = np.load("D:/新建文件夹/3D_VEC_QMIX_VDN V3.1/3RSU_18VUE/policy_QMIX_record/test_24/moving_results/episode_rewards.npy").tolist()
a = smooth([a], 19)
plt.figure(999)
plt.plot(range(len(a)), a, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel("nt_step_rewards_average_in_episodes")
plt.grid()
"""
data2 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_1.npy").tolist()
data3 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_2.npy").tolist()
data4 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_3.npy").tolist()
data5 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_4.npy").tolist()
data6 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_5.npy").tolist()
data7 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_6.npy").tolist()
data8 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_7.npy").tolist()
data9 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_8.npy").tolist()
data10 = np.load("E:\Github Download code\TD3-master\learning_curves\Ant\TD3_Ant-v1_9.npy").tolist()
"""

"""
data.append(data2)
data.append(data3)
data.append(data4)
data.append(data5)
data.append(data6)
data.append(data7)
data.append(data8)
data.append(data9)
data.append(data10)
"""
y_data = smooth(data, 19)
x_data = np.arange(0, len(data1)+5000, 5000)
sns.set(style="darkgrid", font_scale=1.5)
sns.tsplot(time=x_data, data=y_data, color=color[2], linestyle=linestyle[0])
