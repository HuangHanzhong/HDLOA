# -*- coding: utf-8 -*-
"""
Created on Sat Jul 30 14:38:06 2022

@author: ff
"""

# 0  此函数的用户编号：VUE_index
# 1  此函数的任务类型编号：self.VUE_task_type_index_set[VUE_index]；
# 2  生成时隙编号：self.current_slot_index
# 3  时延阈值：self.conf.task_delay_threshold_set[self.VUE_task_type_index_set[VUE_index]]
# 4  比特数：self.conf.task_function_bit_size_set[VUE_task_function_index]
# 5  剩余待传输比特数：self.conf.task_function_bit_size_set[VUE_task_function_index]
# 6  存储需求数：self.conf.task_function_memory_requirement_set[VUE_task_function_index]
# 7  计算MI需求数：self.conf.task_function_computation_resource_requirement_set[VUE_task_function_index]
# 8  剩余MI需求数：self.conf.task_function_computation_resource_requirement_set[VUE_task_function_index]
# 9  目标计算节点编号：target_computation_node = -1    本地计算编号置为-1。如果取值-2，表示还未确定，即新函数还没分配目标节点
#    目标节点编号的取值：[0, 2]表示直连RSU；[3, 5] & 7表示通过ABS中继到各RSU和MBS0；6表示直连MBS0；[8, 9]表示中继MBS1、中继cloud
# 10 分配的计算资源等级：target_container_level = -1   本地容器资源和云端统一置为-1，边缘端取值[0, 4]。 如果未知，取值-2
# 11 中继标识：relay_flag = 0

# 12 LCQ队列时延：LCQ_queue_delay,   每多一个时隙，就增1，初始为0
# 13 本地计算时延：local_computation_delay
# 14 LTQ队列时延：LTQ_queue_delay
# 15 用户到ABS传输时延：VA_transmission_delay   如果没有经过ABS中继，比如直连RSU，此时延为VR传输时延
# 16 ATQ队列时延：ATQ_queue_delay
# 17 ABS到边缘节点时延：AE_transmission_delay
# 18 ECQ队列时延：ECQ_queue_delay
# 19 边缘计算时延：edge_computation_delay
# 20 云计算时延：cloud_computation_delay
# 21 冷启动标识：cold_start_flag
# 22 冷启动等待时延： cold_start_delay



"""
VUE_speed_set_tensor = tf.random.truncated_normal( # 通过tf.random.truncated_normal生成长度为VUE_num的一维截断高斯数组
                                              [self.conf.VUE_num],
                                              mean = self.conf.truncated_normal_mean,
                                              stddev = self.conf.truncated_normal_stddev,
                                              dtype = tf.dtypes.float32,
                                              seed = None,
                                              name = None)
with tf.Session() as sess: # 假如长度为5，上述输出的VUE_speed_set_tensor为<tf.Tensor 'truncated_normal:0' shape=(5,) dtype=float32>
# 需要tf.Session()和sess.run()，才能输出一维数组array([53.789173, 62.596733, 61.138756, 68.24399 , 60.86609 ], dtype=float32)
VUE_speed_set = list(sess.run(VUE_speed_set_tensor)) # 然后再转换为list
VUE_speed_set = [ele*self.conf.VUE_speed_unit_factor for ele in VUE_speed_set] # 速度单位是m/100ms

VUE_left_time_in_belonging_RSU_set = [0]*self.conf.VUE_num # 每个车辆到驶出所在RSU的时间，驻留时间
for VUE_x1_index in range(self.VUE_x1_num): # x正轴道路的车辆沿y轴正方向（从左往右）行驶
this_VUE_revised_coordinate_y = self.VUE_coordinate_y_set[VUE_x1_index] + 3*self.conf.RSU_radius # 将VUE的坐标值变为绝对正值
VUE_left_time_in_belonging_RSU_set[VUE_x1_index] = (abs(2*self.conf.RSU_radius - (this_VUE_revised_coordinate_y % (2*self.conf.RSU_radius))) / VUE_speed_set[VUE_x1_index]) * 100
# 速度单位是每100ms，所以上述公式最后要乘以100，单位为ms
for VUE_x2_index in range(self.VUE_x2_num): # x负轴道路的车辆沿y轴负方向（从右往左）行驶
this_VUE_revised_coordinate_y = self.VUE_coordinate_y_set[self.VUE_x1_num + VUE_x2_index] + 3*self.conf.RSU_radius # 将VUE的坐标值变为绝对正值
VUE_left_time_in_belonging_RSU_set[self.VUE_x1_num + VUE_x2_index] = ((this_VUE_revised_coordinate_y % (2*self.conf.RSU_radius)) / VUE_speed_set[self.VUE_x1_num + VUE_x2_index]) * 100

VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
VR_distance_set = [[0 for i in range(self.conf.RSU_num)] for j in range(self.conf.VUE_num)]
# 创建VUE_num*(RSU_num)二维列表，表示VUE到RSU的距离
for VUE_index in self.conf.VUE_index_set:
if VUE_index <= self.VUE_x1_num - 1:
    VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
elif VUE_index > self.VUE_x1_num - 1:
    VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
RSU_index_for_this_VUE = int(self.VUE_RSU_index_mapping[VUE_index])
VR_distance_set[VUE_index][RSU_index_for_this_VUE] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.RSU_coordinate_set[RSU_index_for_this_VUE])) # 单位m

VUE_index_set_in_each_RSU_mapping = [[], [], []] # 每个RSU中对应的VUE的编号集合
VUE_task_computation_resource_requirement_set_in_each_RSU_mapping = [[], [], []] # 每个RSU里面的所有VUE的计算资源需求
for VUE_index in self.VUE_with_task_index_set:
RSU_index_for_this_VUE = int(self.VUE_RSU_index_mapping[VUE_index])
self.VUE_with_task_num_in_RSU_set[RSU_index_for_this_VUE] += 1
VUE_index_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(VUE_index)
VUE_task_computation_resource_requirement_set_in_each_RSU_mapping[RSU_index_for_this_VUE].append(self.VUE_task_computation_resource_requirement_set[VUE_index])
"""
#print("self.VUE_coordinate_y_set:", self.VUE_coordinate_y_set)
#print("self.VUE_with_task_num_in_RSU_set:", self.VUE_with_task_num_in_RSU_set)
#self.MBS_computing_resource = random.randint(self.conf.MBS_computing_resource_down, self.conf.MBS_computing_resource_up) * 1e9
"""
for MBS_index in self.conf.MBS_index_set:
if np.random.uniform() >= 0.1:
    self.MBS_vCPU_num_set[MBS_index] = self.conf.MBS_vCPU_num_up - np.random.poisson(self.conf.MBS_vCPU_occupied_Poisson_factor, size=1)
else:
    self.MBS_vCPU_num_set[MBS_index] = 0 # MBS资源有概率为0
# CPU cycles/second MBS还要服务其余的用户等，因此设定随机可用计算资源
self.HIBS_vCPU_num = self.conf.HIBS_vCPU_num_up - np.random.poisson(self.conf.HIBS_vCPU_occupied_Poisson_factor, size=1)
while self.HIBS_vCPU_num == 0:
self.HIBS_vCPU_num = self.conf.HIBS_vCPU_num_up - np.random.poisson(self.conf.HIBS_vCPU_occupied_Poisson_factor, size=1)
"""

#for task_function_index in range(self.conf.task_function_type_num): # 循环为每一个函数做决策



#self.real_VUE_index_set = [] # 真正需要考虑决策的用户集合，即不能直接卸载RSU的用户。直接卸载RSU的不用决策

#self.avail_actions = [0]*self.conf.VUE_num

#        #------距离计算------
#        VUE_coordinate_set = [[0 for i in range(3)] for j in range(self.conf.VUE_num)] # 创建VUE_num*3二维列表
#        for VUE_index in self.conf.VUE_index_set:
#            if VUE_index <= self.VUE_x1_num - 1:
#                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x1, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
#            elif VUE_index > self.VUE_x1_num - 1:
#                VUE_coordinate_set[VUE_index] = [self.conf.VUE_x2, self.VUE_coordinate_y_set[VUE_index], self.conf.VUE_height]
#        
#        VX_distance_set = [[0 for i in range(self.conf.RSU_num + 3)] for j in range(self.conf.VUE_num)]
#        # 创建VUE_num*(3+RSU_num)二维列表，前三列表示VUE到RSU的距离，第四列到MBS0，第五列到ABS，第六列到HAPS的距离
#        for VUE_index in self.conf.VUE_index_set:
#            if self.VUE_RSU_index_mapping[VUE_index] >= 0: # 如果此VUE在某个RSU中。  若不在RSU中，此值会为-1
#                VX_distance_set[VUE_index][int(self.VUE_RSU_index_mapping[VUE_index])] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - \
#                                                                                         np.array(self.conf.RSU_coordinate_set[int(self.VUE_RSU_index_mapping[VUE_index])]))
#            if self.VUE_MBS0_index_mapping[VUE_index] == 1: # 如果在MBS0范围内
#                VX_distance_set[VUE_index][3] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.MBS0_coordinate))
#            VX_distance_set[VUE_index][4] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.ABS_coordinate))
#            VX_distance_set[VUE_index][5] = np.linalg.norm(np.array(VUE_coordinate_set[VUE_index]) - np.array(self.conf.HIBS0_coordinate))
#        
#        self.dropped_functions_in_this_slot_initial = [] # 记录LTQ队列中被丢弃的函数个数
#        #self.completed_functions_in_this_slot_initial = []
#        
#        # 从所有用户传输队列中提取出当前slot需要经过ABS传输的所有函数，然后按总函数比特数（而不是剩余比特数）权重分配相应的ABS上行带宽，总比特数多的函数就多分点带宽
#        for VUE_index in self.conf.VUE_index_set:
#            if len(self.VUE_local_transmission_queue[VUE_index]) > 0: # 如果本地传输队列有数据
#                for queuing_function_index in range(len(self.VUE_local_transmission_queue[VUE_index])): # 对队列中每个函数任务遍历，将超时的任务丢弃
#                    if self.VUE_local_transmission_queue[VUE_index][queuing_function_index][2] + self.VUE_local_transmission_queue[VUE_index][queuing_function_index][3] < self.current_slot_index:
#                        # 如果此函数在当前时隙已经超过时延阈值，仍未处理完   [2]是生成时隙；[3]是时延阈值   
#                        # 比如，生成时隙为t=3；t=3时刻做决策，被放到LTQ中；从t=4时刻开始处理；时延阈值为2；应该在t=5时隙结束之前完成。  当前时隙为6，函数仍没传完，则处理失败，需被丢弃
#                        self.dropped_functions_in_this_slot_initial.append(self.VUE_local_transmission_queue[VUE_index][queuing_function_index]) # 记录被丢弃的函数信息
#                        del self.VUE_local_transmission_queue[VUE_index][queuing_function_index] # 此任务函数被丢弃
#                        #dropped_time_slot_index = self.current_slot_index # 被丢弃时隙置为当前时隙
#                        #dropped_function_num_in_LTQ += 1
#            if len(self.VUE_local_transmission_queue[VUE_index]) > 0: # 如果LTQ有数据
#                this_function = self.VUE_local_transmission_queue[VUE_index][0] # 提取出首部函数信息
#                if this_function[9] in Interval(3, 5) or this_function[9] == 7: # 通过ABS中继RSU或MBS0
#                    bit_sum_serverd_by_ABS += this_function[4]
#                elif this_function[9] == 6: # 直连MBS0
#                    bit_sum_direct_serverd_by_MBS0 += this_function[4]
#                elif this_function[9] == 8: # 直连HIBS
#                    bit_sum_direct_serverd_by_HIBS += this_function[4]
#            
#        
#        # ----------------------本地传输队列--------------------------- 
#        for VUE_index in self.conf.VUE_index_set:
#            if len(self.VUE_local_transmission_queue[VUE_index]) > 0: # 如果LTQ有数据
#                if len(self.VUE_local_transmission_queue[VUE_index]) > 1: # 如果本地传输队列有至少两个函数
#                    for queuing_function_index in range(len(self.VUE_local_transmission_queue[VUE_index]) - 1): # 除了队首函数，其他函数排队时延自增1
#                        self.VUE_local_transmission_queue[VUE_index][queuing_function_index][14] += 1 # 本地LTQ排队时延自增1
#                
#                
#                this_target_computation_node_index = self.VUE_local_transmission_queue[VUE_index][0][9] # 提取出此用户任务函数的目标计算节点编号
#                # 目标节点编号的取值：[0, 2]表示直连RSU；[3, 5] & 7表示通过ABS中继到各RSU和MBS0；6表示直连MBS0；[8, 10]表示直连HIBS、中继MBS1、中继cloud
#                
#                # ----------直连RSU----------
#                if this_target_computation_node_index in Interval(1, 3): # 直连RSU
#                    VUE_direct_served_RSU_index = this_target_computation_node_index - 1 # 此VUE直连的RSU编号
#                    this_VR_distance = VX_distance_set[VUE_index][VUE_direct_served_RSU_index]
#                    this_VR_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
#                                              10*math.log(this_VR_distance ** (-self.conf.VR_power_decay_exponent), 10)
#                    this_VR_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_mmW_antenna_gain + self.conf.RSU_rx_mmW_antenna_gain + this_VR_channel_gain_dB - \
#                                  10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * self.conf.mmW_bandwidth, 10)
#                    """
#                    if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
#                        print("faillink:", this_VR_SNR)
#                        reward = self.conf.fail_link_penalty
#                        terminated = True
#                        return (reward, terminated)
#                    """
#                    this_VR_transmission_rate = self.conf.mmW_bandwidth * math.log(1 + 10**(this_VR_SNR/10), 2)
#                    completed_transmission_bits_in_this_slot = this_VR_transmission_rate / 1000 * self.conf.time_slot # 此时隙传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][5] -= completed_transmission_bits_in_this_slot # 剩余未传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][15] += 1 # 本地传输时延自增1
#                    if self.VUE_local_transmission_queue[VUE_index][0][5] <= 0: # 此函数传输完成
#                        #transmission_completed_time_slot_index = self.current_slot_index # 任务函数传输完成的时隙
#                        #completed_function_latency_set.append(self.current_slot_index - self.VUE_local_transmission_queue[VUE_index][0][2]) # 记录此函数的传输时延
#                        self.edge_computation_queue[VUE_direct_served_RSU_index].append(self.VUE_local_transmission_queue[VUE_index][0]) # 传输完成后，此函数才能加入到边缘端的队列中
#                        del self.VUE_local_transmission_queue[VUE_index][0] # 弹出此任务
#                
#                # ----------VA传输----------
#                if this_target_computation_node_index in Interval(4, 6) or this_target_computation_node_index == 8: # VA段  # 包括中继RSU或MBS0的用户
#                    #VUE_relay_served_RSU_index = this_target_computation_node_index - self.conf.RSU_num # 此VUE中继的RSU编号
#                    this_VA_distance = VX_distance_set[VUE_index][4]
#                    this_VA_channel_gain_dB = self.conf.channel_power_gain_at_reference_distance_dB + \
#                                              10*math.log(this_VA_distance ** (-self.conf.VA_power_decay_exponent), 10)
#                    if bit_sum_serverd_by_ABS > 0:
#                        this_VUE_uplink_bandwidth_allocated_by_ABS = (self.VUE_local_transmission_queue[VUE_index][0][4] / bit_sum_serverd_by_ABS) * \
#                                                                     self.conf.sub6_bandwidth # 按初始任务量（而不是剩余任务量）权重分配ABS上行带宽
#                    else:
#                        print("VUE_task_bit_size_relay_served_by_ABS error")
#                    
#                    this_VA_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.ABS_rx_sub6_antenna_gain + this_VA_channel_gain_dB - \
#                                  10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_ABS, 10)
#                    """
#                    if this_VA_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
#                        print("faillink:", this_VA_SNR)
#                        reward = self.conf.fail_link_penalty
#                        terminated = True
#                        return (reward, terminated)
#                    """
#                    this_VA_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_ABS * math.log(1 + 10**(this_VA_SNR/10), 2)
#                    #this_VA_transmission_latency = (self.VUE_task_bit_size_set[VUE_index] / this_VA_transmission_rate) * 1e3
#                    # 如果任务为CA， (1e6/37e6)*1000 = 27 ms
#                    completed_transmission_bits_in_this_slot = this_VA_transmission_rate / 1000 * self.conf.time_slot # 此时隙传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][5] -= completed_transmission_bits_in_this_slot # 剩余未传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][15] += 1 # VA传输时延自增1
#                    if self.VUE_local_transmission_queue[VUE_index][0][5] <= 0: # 此函数传输完成
#                        if this_target_computation_node_index in Interval(4, 6): # 一个函数传输完成后才会加到ABS待传输队列中，不考虑VA和AR段同时传输的情况
#                            self.ABS_transmission_queue[this_target_computation_node_index - self.conf.RSU_num].append(self.VUE_local_transmission_queue[VUE_index][0])
#                            # 将任务添加到ABS相应的队列中
#                            self.ABS_transmission_queue[this_target_computation_node_index - self.conf.RSU_num][-1][5] = self.VUE_local_transmission_queue[VUE_index][0][4]
#                            # 剩余未传输比特数初始化，准备进行第二段的传输
#                        elif this_target_computation_node_index == 8: # 一个函数传输完成后才会加到ABS待传输队列中，不考虑VA和AR段同时传输的情况
#                            self.ABS_transmission_queue[-1].append(self.VUE_local_transmission_queue[VUE_index][0])
#                            # 将任务添加到ABS相应的队列中
#                            self.ABS_transmission_queue[-1][-1][5] = self.VUE_local_transmission_queue[VUE_index][0][4]
#                            # 剩余未传输比特数初始化，准备进行第二段的传输
#                        del self.VUE_local_transmission_queue[VUE_index][0] # 弹出此任务
#        
#                # ----------VM0传输----------
#                if this_target_computation_node_index == 7: # 直连MBS0
#                    this_VM0_distance = VX_distance_set[VUE_index][3]
#                    #this_VM0_channel_gain_dB = self.Rician_value(1, self.conf.k_factor_VM)
#                    this_VM0_channel_gain_dB = self.VM0_channel_gain_set[VUE_index]
#                    if bit_sum_direct_serverd_by_MBS0 > 0:
#                        this_VUE_uplink_bandwidth_allocated_by_MBS0 = (self.VUE_local_transmission_queue[VUE_index][0][4] / bit_sum_direct_serverd_by_MBS0) * \
#                                                                       self.conf.sub6_bandwidth
#                    else:
#                        print("VUE_task_bit_size_relay_served_by_MBS0 error")
#                    # 按任务量权重分配ABS上行带宽
#                    this_VM0_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.MBS_rx_sub6_antenna_gain + this_VM0_channel_gain_dB - \
#                                  10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_MBS0, 10)
#                    """
#                    if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
#                        print("faillink:", this_VR_SNR)
#                        reward = self.conf.fail_link_penalty
#                        terminated = True
#                        return (reward, terminated)
#                    """
#                    this_VM0_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_MBS0 * math.log(1 + 10**(this_VM0_SNR/10), 2)
#                    completed_transmission_bits_in_this_slot = this_VM0_transmission_rate / 1000 * self.conf.time_slot # 此时隙传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][5] -= completed_transmission_bits_in_this_slot # 剩余未传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][15] += 1 # VA传输时延自增1
#                    if self.VUE_local_transmission_queue[VUE_index][0][5] <= 0: # 此函数传输完成
#                        #transmission_completed_time_slot_index = self.current_slot_index # 任务函数传输完成的时隙
#                        #VUE_task_function_latency_set[VUE_index][3] = transmission_completed_time_slot_index - self.VUE_local_transmission_queue[VUE_index][0][2] # 记录此函数的传输时延
#                        self.edge_computation_queue[3].append(self.VUE_local_transmission_queue[VUE_index][0]) # 传输完成后，此函数才能加入到边缘端的队列中
#                        del self.VUE_local_transmission_queue[VUE_index][0] # 弹出此任务
#                
#                # ----------VH传输----------
#                if this_target_computation_node_index in Interval(9, 11): # VH段 # 包括中继MBS1的用户、直连HIBS的用户、中继cloud的用户
#                    this_VH_distance = VX_distance_set[VUE_index][5]
#                    #this_VH_channel_gain_dB = self.Rician_value(1, self.conf.k_factor_VH)
#                    this_VH_channel_gain_dB = self.VH_channel_gain_set[VUE_index]
#                    if bit_sum_direct_serverd_by_HIBS > 0:
#                        this_VUE_uplink_bandwidth_allocated_by_HIBS = (self.VUE_local_transmission_queue[VUE_index][0][4] / bit_sum_direct_serverd_by_HIBS) * \
#                                                                       self.conf.sub6_bandwidth
#                    else:
#                        print("VUE_task_bit_size_relay_served_by_MBS0 error")
#                    # 按任务量权重分配ABS上行带宽
#                    this_VH_SNR = self.conf.VUE_tx_power_dBm + self.conf.VUE_tx_sub6_antenna_gain + self.conf.HIBS_rx_sub6_antenna_gain + this_VH_channel_gain_dB - \
#                                  10*math.log(10**(self.conf.Gaussian_noise_psd_dBm_per_Hz/10) * this_VUE_uplink_bandwidth_allocated_by_HIBS, 10)
#                    """
#                    if this_VR_SNR < self.conf.SNR_threshold: # 如果SNR低于阈值
#                        print("faillink:", this_VR_SNR)
#                        reward = self.conf.fail_link_penalty
#                        terminated = True
#                        return (reward, terminated)
#                    """
#                    this_VH_transmission_rate = this_VUE_uplink_bandwidth_allocated_by_HIBS * math.log(1 + 10**(this_VH_SNR/10), 2)
#                    completed_transmission_bits_in_this_slot = this_VH_transmission_rate / 1000 * self.conf.time_slot # 此时隙传输的函数比特数
#                    
#                    """
#                    if self.HIBS_MBS1_waited_transmission_data_sum > 0: # 如果有数据待传
#                        HM_transmission_latency = self.HIBS_MBS1_waited_transmission_data_sum / self.HM_FSO_rate
#                    elif self.HIBS_cloud_waited_transmission_data_sum > 0: # 如果有数据待传
#                        HH_transmission_latency = self.HIBS_cloud_waited_transmission_data_sum / self.HH_FSO_rate
#                        HC_transmission_latency = self.HIBS_cloud_waited_transmission_data_sum / self.HC_FSO_rate
#                    
#                    self.HIBS_MBS1_waited_transmission_data_sum = 0 # 重新初始化，用来存储这一时刻的新的中继数据
#                    self.HIBS_MBS1_waited_transmission_data_sum = 0
#                    
#                    if this_target_computation_node_index == 8: # 如果是中继给MBS1的数据，则加到HIBS-MBS1待传缓冲区中，下一时隙，通过FSO高速率回程链路，多个用户的数据可以在一个时隙内传完
#                        self.HIBS_MBS1_waited_transmission_data_sum = completed_transmission_bits_in_this_slot
#                    elif this_target_computation_node_index == 10: # 如果是中继给cloud的数据，则加到HIBS-cloud待传缓冲区中
#                        self.HIBS_cloud_waited_transmission_data_sum = completed_transmission_bits_in_this_slot
#                    self.HIBS_relay_transmission_queue.append(completed_transmission_bits_in_this_slot) # 传给HIBS的数据加到HIBS的中继传输队列中
#                    """
#                    
#                    self.VUE_local_transmission_queue[VUE_index][0][5] -= completed_transmission_bits_in_this_slot # 剩余未传输的函数比特数
#                    self.VUE_local_transmission_queue[VUE_index][0][15] += 1 # VH传输时延自增1
#                    if self.VUE_local_transmission_queue[VUE_index][0][5] <= 0: # 此函数传输完成
#                        if this_target_computation_node_index == 9: # 如果是直连HIBS的函数
#                            self.edge_computation_queue[5].append(self.VUE_local_transmission_queue[VUE_index][0])
#                        if this_target_computation_node_index == 10: # 一个函数传输完成后才会加到HIBS待传输队列中，不考虑VH和HM1段同时传输的情况
#                            self.HIBS_transmission_queue[0].append(self.VUE_local_transmission_queue[VUE_index][0])
#                            # 将任务添加到HIBS-MBS1的队列中
#                            self.HIBS_transmission_queue[0][-1][5] = self.VUE_local_transmission_queue[VUE_index][0][4]
#                            # 剩余未传输比特数初始化，准备进行第二段的传输
#                        elif this_target_computation_node_index == 11:
#                            self.HIBS_transmission_queue[1].append(self.VUE_local_transmission_queue[VUE_index][0])
#                            # 将任务添加到ABS相应的队列中
#                            self.HIBS_transmission_queue[1][-1][5] = self.VUE_local_transmission_queue[VUE_index][0][4]
#                            # 剩余未传输比特数初始化，准备进行第二段的传输
#                        del self.VUE_local_transmission_queue[VUE_index][0] # 弹出此任务
        
        
        
"""
self.VUE_vCPU_avail_computation_resource_set = [0] * self.conf.VUE_num
self.RSU_vCPU_avail_computation_resource_set = [ [0 for i in range(self.conf.RSU_vCPU_num)] for j in range(self.conf.RSU_num)]
self.MBS_vCPU_avail_computation_resource_set = [ [0 for i in range(self.conf.MBS_vCPU_num_up)] for j in range(self.conf.MBS_num)]
self.HIBS_vCPU_avail_computation_resource_set = [0] * self.conf.HIBS_vCPU_num_up
# 记录每个节点中的CPU剩余计算资源
"""
"""
# 某个RSU的直连用户超过4个的情况只能设置惩罚值来避免，无法通过动作空间设置来解决
if self.conf.computing_mode == 0:
    for VUE_index in self.conf.VUE_index_set:
        if VUE_index in self.VUE_with_task_index_set:
            avail_actions = [1]*self.conf.n_actions
            for function_type_index in range(self.conf.task_function_type_num):
                if 0 not in self.VUE_task_function_index_set[VUE_index]: # 如果此VUE任务没有第function_type_index类函数
                    for action_index in range(self.conf.single_function_n_actions):
                        avail_actions[function_type_index*self.conf.single_function_n_actions + action_index] = 0
"""            
    

"""
print(VUE_index_set_dd)
print(self.avail_actions)
#a= [len(ele) for ele in self.avail_actions]
if 0 in self.avail_actions:
    print(self.avail_actions)
    print("yes")
"""



"""
##### ----------边缘端，将ECQ队列中的函数加到空闲的vCPU核中----------
for edge_node_index in range(self.conf.RSU_num + self.conf.MBS_num + 1): # 遍历每个边缘节点，看是否有剩余vCPU资源用来计算等待队列中的任务
    #print(edge_node_index, len(self.edge_computation_queue))
    if len(self.edge_computation_queue[edge_node_index]) > 0: # 如果此边缘节点的计算队列有数据
        need_del_function_index_set_in_edge_computation_queue = [] # 在如下for循环中会从edge_computation_queue中挑选出被丢弃的函数的编号，在for循环结束后再一起弹出队列
        for queuing_function_index in range(len(self.edge_computation_queue[edge_node_index])): # 对等待队列中每个函数任务遍历，将超时的任务丢弃
            if self.edge_computation_queue[edge_node_index][queuing_function_index][2] + self.edge_computation_queue[edge_node_index][queuing_function_index][3] < self.current_slot_index:
                # 如果此函数在当前时隙已经超过时延阈值
                dropped_functions_in_this_slot.append(self.edge_computation_queue[edge_node_index][queuing_function_index]) # 记录被丢弃的函数信息
                need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                #dropped_time_slot_index = self.current_slot_index # 被丢弃时隙置为当前时隙
                dropped_function_num_in_ECQ += 1
        if len(need_del_function_index_set_in_edge_computation_queue) > 0: # 如果有待弹出的函数
            for need_del_function_index in reversed(need_del_function_index_set_in_edge_computation_queue):
                del self.edge_computation_queue[need_del_function_index]
            # 上述for循环从一个列表中按另一个列表元素做索引删除多个元素 https://blog.csdn.net/weixin_35286137/article/details/113971197 
        #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被丢弃
    if len(self.edge_computation_queue[edge_node_index]) > 0: # 如果此边缘节点的计算队列有数据
        need_del_function_index_set_in_edge_computation_queue = [] # 在如下for循环中会从edge_computation_queue中挑选出被丢弃的函数的编号，在for循环结束后再一起弹出队列
        for queuing_function_index in range(len(self.edge_computation_queue[edge_node_index])): # 遍历每个任务，寻找合适的vCPU核
            this_function_type = self.edge_computation_queue[edge_node_index][queuing_function_index][1] # 提取此函数的类别，为了寻找对应的空闲容器
            this_container_level = self.edge_computation_queue[edge_node_index][queuing_function_index][10] # 提取计算资源等级
            warm_container_mapping_flag = 0 # 此函数是否找到对应的空闲容器的标识， 初始化
            if edge_node_index in Interval(0, 2): # 如果是RSU
                for edge_vCPU_index in range(self.conf.RSU_vCPU_num):
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix = []
                        # 在如下for循环中会从vCPU_empty_container_mapping_matrix中挑选出被释放的空闲容器的编号，在for循环结束后再一起弹出队列
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index])):    
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index][empty_container_index][1] >= \
                               self.conf.empty_container_delay_threshold:
                                need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix.append(empty_container_index) # 编号为empty_container_index的空闲容器需要从队列中弹出
                                #del self.vCPU_empty_container_mapping_matrix[edge_vCPU_index][empty_container_index] # 此空闲容器被释放
                        if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index]) > 0:  # 如果有待弹出的函数
                            for need_del_empty_container_index in reversed(need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix):
                                del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index][need_del_empty_container_index]
                                # 上述for循环从一个列表中按另一个列表元素做索引删除多个元素 https://blog.csdn.net/weixin_35286137/article/details/113971197 
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index])): # 遍历每个空闲容器，为此函数寻找对应的空闲容器
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index][empty_container_index][0] == this_function_type:
                                # 如果待计算函数类型和空闲容器函数类型匹配
                                if self.avail_vCPU_computing_resource[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index] >= this_container_level: # 如果此核的剩余资源满足此任务的需求
                                    this_function_info = self.edge_computation_queue[edge_node_index][queuing_function_index] # 从等待队列中提取
                                    self.vCPU_computing_queue[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index].append(this_function_info) # 将此函数加载到此核上
                                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
                                    del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index][empty_container_index] # 此空闲容器被占用，不再空闲
                                    self.avail_vCPU_computing_resource[edge_node_index * self.conf.RSU_vCPU_num + edge_vCPU_index] -= this_container_level # 更新此核可用资源
                                    warm_container_mapping_flag = 1 # 此函数已被服务
                                    break # 如果this_function_info成功被服务，则跳出便利空闲容器的for循环
                                else: # 如果没有合适的vCPU核计算此函数
                                    self.vCPU_empty_container_mapping_matrix[edge_vCPU_index][empty_container_index][1] += 1 # 空闲容器存在时延自增1
                if warm_container_mapping_flag == 0: # 如果遍历了此边缘节点的各vCPU的所有空闲容器，此函数都没被服务，即没有热启动，则需要进入冷启动等待状态
                    self.edge_computation_queue[edge_node_index][queuing_function_index][18] += 1 # 边缘计算时延自增1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][21] = 1 # 冷启动标识置1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][22] = 0 # 冷启动时延初始化
                    self.edge_cold_start_queue[edge_node_index].append(self.edge_computation_queue[edge_node_index][queuing_function_index]) # 加入冷启动队列中，等待容器启动完成再计算
                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                    
            elif edge_node_index in Interval(3, 4): # 如果是MBS
                for edge_vCPU_index in range(self.conf.MBS_vCPU_num):
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix = []
                        # 在如下for循环中会从vCPU_empty_container_mapping_matrix中挑选出被释放的空闲容器的编号，在for循环结束后再一起弹出队列
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index])):
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index][empty_container_index][1] >= \
                               self.conf.empty_container_delay_threshold:
                                #del self.vCPU_empty_container_mapping_matrix[edge_vCPU_index][empty_container_index] # 此空闲容器被释放
                                need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix.append(empty_container_index) # 编号为empty_container_index的空闲容器需要从队列中弹出
                        for need_del_empty_container_index in reversed(need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix):
                            del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index][need_del_empty_container_index]
                    
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index])): # 遍历每个空闲容器，为此函数寻找对应的空闲容器
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index][empty_container_index][0] == this_function_type: # 如果待计算函数类型和空闲容器函数类型匹配
                                if self.avail_vCPU_computing_resource[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index] >= this_container_level: # 如果此核的剩余资源满足此任务的需求
                                    this_function_info = self.edge_computation_queue[edge_node_index][queuing_function_index] # 从等待队列中提取
                                    self.vCPU_computing_queue[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index].append(this_function_info) # 将此函数加载到此核上
                                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
                                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                                    del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index][empty_container_index] # 此空闲容器被占用，不再空闲
                                    self.avail_vCPU_computing_resource[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index] -= this_container_level # 更新此核可用资源
                                    warm_container_mapping_flag = 1 # 此函数已被服务
                                    break # 如果this_function_info成功被服务，则跳出便利空闲容器的for循环
                                else: # 如果没有合适的vCPU核计算此函数
                                    self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.MBS_vCPU_num + edge_vCPU_index][empty_container_index][1] += 1 # 空闲容器存在时延自增1
                if warm_container_mapping_flag == 0: # 如果遍历了此边缘节点的各vCPU的所有空闲容器，此函数都没被服务，即没有热启动，则需要进入冷启动等待状态
                    self.edge_computation_queue[edge_node_index][queuing_function_index][18] += 1 # 边缘计算时延自增1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][21] = 1 # 冷启动标识置1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][22] = 0 # 冷启动时延初始化
                    self.edge_cold_start_queue[edge_node_index].append(self.edge_computation_queue[edge_node_index][queuing_function_index]) # 加入冷启动队列中，等待容器启动完成再计算
                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
            
            elif edge_node_index == 5: # 如果是HIBS
                for edge_vCPU_index in range(self.conf.HIBS_vCPU_num):
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix = []
                        # 在如下for循环中会从vCPU_empty_container_mapping_matrix中挑选出被释放的空闲容器的编号，在for循环结束后再一起弹出队列
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index])):
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index][empty_container_index][1] >= self.conf.empty_container_delay_threshold:
                                #del self.vCPU_empty_container_mapping_matrix[edge_vCPU_index][empty_container_index] # 此空闲容器被释放
                                need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix.append(empty_container_index) # 编号为empty_container_index的空闲容器需要从队列中弹出
                        for need_del_empty_container_index in reversed(need_del_empty_container_index_set_in_vCPU_empty_container_mapping_matrix):
                            del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index][need_del_empty_container_index]
                    if len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index]) > 0: # 如果此核中有空闲容器
                        for empty_container_index in range(len(self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index])): # 遍历每个空闲容器，为此函数寻找对应的空闲容器
                            if self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index][empty_container_index][0] == this_function_type: # 如果待计算函数类型和空闲容器函数类型匹配
                                if self.avail_vCPU_computing_resource[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index] >= this_container_level: # 如果此核的剩余资源满足此任务的需求
                                    this_function_info = self.edge_computation_queue[edge_node_index][queuing_function_index] # 从等待队列中提取
                                    self.vCPU_computing_queue[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index].append(this_function_info) # 将此函数加载到此核上
                                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
                                    del self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index][empty_container_index] # 此空闲容器被占用，不再空闲
                                    self.avail_vCPU_computing_resource[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index] -= this_container_level # 更新此核可用资源
                                    warm_container_mapping_flag = 1 # 此函数已被服务
                                    break # 如果this_function_info成功被服务，则跳出便利空闲容器的for循环
                                else: # 如果没有合适的vCPU核计算此函数
                                    self.vCPU_empty_container_mapping_matrix[edge_node_index * self.conf.HIBS_vCPU_num + edge_vCPU_index][empty_container_index][1] += 1 # 空闲容器存在时延自增1
                if warm_container_mapping_flag == 0: # 如果遍历了此边缘节点的各vCPU的所有空闲容器，此函数都没被服务，即没有热启动，则需要进入冷启动等待状态
                    self.edge_computation_queue[edge_node_index][queuing_function_index][18] += 1 # 边缘计算时延自增1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][21] = 1 # 冷启动标识置1
                    self.edge_computation_queue[edge_node_index][queuing_function_index][22] = 0 # 冷启动时延初始化
                    self.edge_cold_start_queue[edge_node_index].append(self.edge_computation_queue[edge_node_index][queuing_function_index]) # 加入冷启动队列中，等待容器启动完成再计算
                    need_del_function_index_set_in_edge_computation_queue.append(queuing_function_index) # 编号为queuing_function_index的函数需要从队列中弹出
                    #del self.edge_computation_queue[edge_node_index][queuing_function_index] # 此任务函数被边缘等待队列弹出
"""
import numpy as np
import math
def Rician_value(VUE_number, k_factor):
    Omega = 1
    x = np.random.randn(1, VUE_number) # randn 生成正态分布随机数
    y = np.random.randn(1, VUE_number)
    
    ss = math.sqrt(Omega / (2 * (1 + k_factor)))
    vv = math.sqrt(Omega * k_factor / (1 + k_factor))
    xx = ss*x+vv
    yy = ss*y
    xx_row = xx.shape[0]
    xx_col = xx.shape[1]
    xx = [ [math.pow(ele1, 2) for ele1 in ele0] for ele0 in xx.tolist() ] # 二维列表每个元素平方
    yy = [ [math.pow(ele1, 2) for ele1 in ele0] for ele0 in yy.tolist() ]
    
    channel_gain = [[0 for i in range(xx_col)] for j in range(xx_row)]
    for i in range(len(xx)):
       # 迭代输出列
       for j in range(len(xx[0])):
           channel_gain[i][j] = xx[i][j] + yy[i][j]
    print(channel_gain)
    channel_gain_dB = [int(10*math.log(ele, 10)) for ele in channel_gain[0]]
    return channel_gain_dB
print(Rician_value(10, 10))

