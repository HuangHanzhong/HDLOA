import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
plt.close('all')
run_index = 1
smooth_weight = 0.19
show_move_average_flag = 1

def smooth(data, weight=smooth_weight):
    last = data[0]
    smoothed_data = []
    for point in data:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed_data.append(smoothed_val)
        last = smoothed_val
    return smoothed_data

data_load_source_path = './results' + '/MyEnv' + '/mappo' + '/run' + str(run_index) + '/moving_results/' + 'episode_data_records.npy'
a = np.load(data_load_source_path, allow_pickle=True)
a = a.tolist()
a1 = []
for ele in range(len(a)):
    a1.append(a[ele][1][7])
a1 = smooth(a1)
# 0: latency_interval_set_average_record, 1: LCQ_LTQ_bad_length_interval_flag,         2: LCQ_total_len_record,             3: LTQ_total_len_record, 
# 4: len(completed_functions_in_LCQ),     5: len(completed_functions_in_VCQ),          6: len(completed_functions_in_CCQ),  7: completed_num,
# 8: dropped_num,                         9: len(dropped_functions_in_LCQ),           10: len(dropped_functions_in_LTQ),   11: len(dropped_functions_in_ATQ), 
# 12: len(dropped_functions_in_HTQ),     13: len(dropped_functions_in_ECQ),           14: len(dropped_functions_in_ECSQ),  15: len(dropped_functions_in_VCQ), 
# 16: len(dropped_functions_in_CCQ),     17: len(self.dropped_new_arrival_functions), 18: bad_offloading_num,              19: left_functions_in_queues]
#print(a)
print(len(a1), [int(ele) for ele in a1])
plt.figure(1)
plt.plot(range(len(a1)), a1, marker = 'd', markersize = 4, color='blue')
plt.xlabel("epoch")
plt.ylabel(" ")
plt.grid()