"""
# @Time    : 2021/7/1 7:15 下午
# @Author  : hezhiqiang01
# @Email   : hezhiqiang01@baidu.com
# @File    : env_runner.py
"""

"""
# @Time    : 2021/7/1 7:04 下午
# @Author  : hezhiqiang01
# @Email   : hezhiqiang01@baidu.com
# @File    : huaru_runner.py
"""

import time
import numpy as np
import torch
from runner.shared.base_runner import Runner
import imageio
import matplotlib.pyplot as plt
import os
import shutil
np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning)
# 上一句是解决这个bug:  https://blog.csdn.net/qq_31347869/article/details/125859502


def _t2n(x):
    return x.detach().cpu().numpy()


class EnvRunner(Runner):
    """Runner class to perform training, evaluation. and data collection for the MPEs. See parent class for details."""

    def __init__(self, config):
        super(EnvRunner, self).__init__(config)
        self.noise_vector = None #*************
        self.reset_noise() #*************
    
    def reset_noise(self): #*************
        # init noise
        if self.noise_vector is None:
            self.noise_vector = []
            for i in range(self.all_args.num_agents):
                self.noise_vector.append(np.random.randn(self.all_args.noise_dim) * self.all_args.sigma)
            self.noise_vector = np.array(self.noise_vector)
        else:
            # shuffle noise
            np.random.shuffle(self.noise_vector)
    
    
    def run(self):
        self.warmup() # 此处也会调用环境函数的reset()，获得初始化obs等
        
        moving_save_path = self.run_dir / 'moving_results' # 文件夹存储路径。这个文件夹用来存储什么内容？？？这个变量只在此处出现过
        if os.path.exists(moving_save_path):
            shutil.rmtree(moving_save_path) 
        if not os.path.exists(moving_save_path):
            os.makedirs(moving_save_path) # 如果没有此文件夹就创建新文件夹
        
        start = time.time()
        episodes = int(self.num_env_steps) // self.episode_length // self.n_rollout_threads
        # 总的num_env_steps可以由多个n_rollout_threads来平分的，即每个n_rollout_thread跑一部分steps，因此回合数与n_rollout_threads有关
        
        episode_data_records = []
        
        #action_masks = torch.zeros( self.episode_length, self.envs.action_space[0].nvec.sum() ).device("cpu")
        average_rewards = []
        for episode in range(episodes):
            if self.use_linear_lr_decay:
                self.trainer.policy.lr_decay(episode, episodes)
            
            if self.all_args.use_value_noise and self.all_args.reset_interval != -1: #*************
                if episode % self.all_args.reset_interval == 0:
                    #print('shuffle noise vector...')
                    self.reset_noise()
            
            for step in range(self.episode_length):
                #action_masks[step] = torch.Tensor(self.envs.avail_actions)
                # Sample actions
                values, actions, action_log_probs, rnn_states, rnn_states_critic, actions_env = self.collect(step, self.noise_vector)
                # actions_env是mpe相比于smac独有的，应该是因为多维离散动作的原因
                # 先运行collect()再运行step()，为什么？？？
                # 因为collect()是进行action决策的，有了actions，才能在envs中进行step()
                # 如果环境不是图像相关的，是否就不需要rnn?  或者说此代码中的rnn是用来解决历史观测信息的？？？
                
                #bb = (episode + 1) * self.episode_length * self.n_rollout_threads
                
                #print(actions)
                # Obser reward and next obs
                obs, share_obs, rewards, dones, infos, available_actions, episode_data_record = self.envs.step(actions_env) # 与环境交互更新obs等
                # rewards和share_obs都是为了数据对齐，所以给每个agent复制的相同信息
                episode_data_record = sum(episode_data_record.tolist(), [])
                
                #print(episode_data_record.tolist())
                data = obs, share_obs, rewards, dones, infos, available_actions, values, actions, action_log_probs, rnn_states, rnn_states_critic
                # 为什么将collect()和step()的数据结合在一起形成data？？？
                
                # insert data into buffer
                self.insert(data)

            # compute return and update network
            self.compute(self.noise_vector) #*************  # 一回合结束了才compute()，这个是base_runner.py里面的函数
            train_infos = self.train(self.noise_vector) #*************  # r_mappo.py中的train() # 这个是base_runner.py里面的函数

            # post process
            total_num_steps = (episode + 1) * self.episode_length * self.n_rollout_threads

            # save model
            if (episode % self.save_interval == 0 or episode == episodes - 1):
                self.save()

            # log information
            if episode % self.log_interval == 0: # self.log_interval=5，每5回合print一次奖励信息
                end = time.time() # 返回当前时间的时间戳
                # print("\nAlgo {} Exp {} updates {}/{} episodes, total num timesteps {}/{}."
                #       .format(self.algorithm_name,
                #               self.experiment_name,
                #               episode,
                #               episodes,
                #               total_num_steps,
                #               self.num_env_steps))

                # if self.env_name == "MPE":
                #     env_infos = {}
                #     for agent_id in range(self.num_agents):
                #         idv_rews = []
                #         for info in infos:
                #             if 'individual_reward' in info[agent_id].keys():
                #                 idv_rews.append(info[agent_id]['individual_reward'])
                #         agent_k = 'agent%i/individual_rewards' % agent_id
                #         env_infos[agent_k] = idv_rews

                train_infos["average_episode_rewards"] = int(np.mean(self.buffer.rewards) * self.episode_length)
                episode_data_record.insert(0, train_infos["average_episode_rewards"])
                episode_data_records.append(episode_data_record)
                average_rewards.append(train_infos["average_episode_rewards"])
                print("reward  {}    episode {}/{} time is {}".format(train_infos["average_episode_rewards"], episode, total_num_steps, time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))))
                self.log_train(train_infos, total_num_steps)
                # self.log_env(env_infos, total_num_steps)

            # eval
            if episode % self.eval_interval == 0 and self.use_eval:
                self.eval(total_num_steps)
            
            moving_interval = 2
            if episode > moving_interval and (episode + 1) % moving_interval == 0 and os.path.exists(moving_save_path):  # 如果文件存在
                shutil.rmtree(moving_save_path)  # 删除文件，可使用以下两种方法。
                #os.unlink(path)
                os.makedirs(moving_save_path)
            
            if episode > 0 and (episode + 1) % moving_interval == 0:
                np.save(moving_save_path / 'episode_data_records', episode_data_records)
            
        
        plt.figure(2)
        plt.plot(range(len(average_rewards)), average_rewards, marker = 'd', markersize = 4, color='blue')
        plt.xlabel("episode")
        plt.ylabel("average_rewards")
        plt.grid()
        
        
    def warmup(self):
        # reset env
        obs, share_obs, available_actions = self.envs.reset()  # shape = (5, 2, 14)

        # replay buffer
        """
        if self.use_centralized_V: # 参考SMAC，设为False
            share_obs = obs.reshape(self.n_rollout_threads, -1)  # shape = (5, 28)
            share_obs = np.expand_dims(share_obs, 1).repeat(self.num_agents, axis=1)  # shape = (5, 2, 28)
        else:
            share_obs = obs
        """
        # 上面的if是mpe和light的格式，下面的if是smac的格式i，我的环境更符合smac
        if not self.use_centralized_V:  # 如果是DTDE，则share_obs，即全局状态就是obs，或者说，其实是没有全局状态的；如果是CTDE，则share_obs和obs是不一样的
            share_obs = obs
        
        self.buffer.share_obs[0] = share_obs.copy()
        self.buffer.obs[0] = obs.copy()
        self.buffer.available_actions[0] = available_actions.copy()

    @torch.no_grad()
    def collect(self, step, noise_vector=None): #*************
        self.trainer.prep_rollout()
        value, action, action_log_prob, rnn_states, rnn_states_critic \
            = self.trainer.policy.get_actions(np.concatenate(self.buffer.share_obs[step]),
                                              np.concatenate(self.buffer.obs[step]),
                                              np.concatenate(self.buffer.rnn_states[step]),
                                              np.concatenate(self.buffer.rnn_states_critic[step]),
                                              np.concatenate(self.buffer.masks[step]),
                                              np.concatenate(self.buffer.available_actions[step]),
                                              noise_vector)  #*************  # 此处新添加了np.concatenate(self.buffer.available_actions[step])
        # [self.envs, agents, dim]
        values = np.array(np.split(_t2n(value), self.n_rollout_threads))
        # value为tensor([[-0.3543], [-0.3543], [ 3.1092], [ 3.1092], [ 0.5589], [ 0.5589]])
        # values为array([[[-0.35425165], [-0.35425165]],     [[ 3.1092277 ], [ 3.1092277 ]],     [[ 0.558879  ], [ 0.558879  ]]], dtype=float32)
        # 就是将每两个分成一组，就是按照self.n_rollout_threads来分的，分为self.n_rollout_threads组
        actions = np.array(np.split(_t2n(action), self.n_rollout_threads))
        action_log_probs = np.array(np.split(_t2n(action_log_prob), self.n_rollout_threads))
        rnn_states = np.array(np.split(_t2n(rnn_states), self.n_rollout_threads))
        rnn_states_critic = np.array(np.split(_t2n(rnn_states_critic), self.n_rollout_threads))
        
        # rearrange action # smac中没有，mpe和light中有，就是将十进制的acton转为one-hot变量
        if self.envs.action_space[0].__class__.__name__ == 'MultiDiscrete': # 将[0, 51]转为one-hot[1, 0, ..., 0,    0, ..., 1, ..., 0]
            for i in range(self.envs.action_space[0].shape):
                uc_actions_env = np.eye(self.envs.action_space[0].high[i] + 1)[actions[:, :, i]]
                if i == 0:
                    actions_env = uc_actions_env
                else:
                    actions_env = np.concatenate((actions_env, uc_actions_env), axis=2)
        elif self.envs.action_space[0].__class__.__name__ == 'Discrete':
            # actions  --> actions_env : shape:[10, 1] --> [5, 2, 5]
            actions_env = np.squeeze(np.eye(self.envs.action_space[0].n)[actions], 2)
        else:
            # TODO 这里改造成自己环境需要的形式即可
            actions_env = actions
            # raise NotImplementedError

        return values, actions, action_log_probs, rnn_states, rnn_states_critic, actions_env

    def insert(self, data): # 这个函数的内容，smac和mpe差别很大
        # 在此类中循环step时，调用的是这个insert()。 这个insert()和shared_buffer.py中的insert()啥关系？？？
        # 然后在这个函数末尾调用的shared_buffer.py中的insert()，相当于这里的insert()是buffer.py中insert()的封装
        obs, share_obs, rewards, dones, infos, available_actions, values, actions, action_log_probs, rnn_states, rnn_states_critic = data
        
        # obs, share_obs, rewards, dones, infos, available_actions, values, actions, action_log_probs, rnn_states, rnn_states_critic
        
        #dones_env = np.all(dones, axis=1) # 此句来自smac_runner，不确定是否准确
        #rnn_states[dones_env == True] = np.zeros(((dones_env == True).sum(), self.num_agents, self.recurrent_N, self.hidden_size), # self.num_agents来自smac_runner
        #                                     dtype=np.float32)
        #rnn_states_critic[dones_env == True] = np.zeros(((dones_env == True).sum(), self.num_agents, *self.buffer.rnn_states_critic.shape[3:]),
        #                                            dtype=np.float32)
        masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32) # self.num_agents来自smac_runner
        #masks[dones_env == True] = np.zeros(((dones_env == True).sum(), self.num_agents, 1), dtype=np.float32)  # self.num_agents来自smac_runner
        
        #这两个mask是从smac来的，不确定是否需要，如果需要的话，最后一句insert的元素要添加这两个
        active_masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
        #active_masks[dones == True] = np.zeros(((dones == True).sum(), 1), dtype=np.float32)
        #active_masks[dones_env == True] = np.ones(((dones_env == True).sum(), self.num_agents, 1), dtype=np.float32)

        bad_masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
        """"""
        
        """
        if self.use_centralized_V: # 参考SMAC，设为False
            share_obs = obs.reshape(self.n_rollout_threads, -1)  # shape = (5, 28)
            share_obs = np.expand_dims(share_obs, 1).repeat(self.num_agents, axis=1)  # shape = (5, 2, 28)
        else:
            share_obs = obs
        """
        # 上面的if是mpe的格式，下面的if是smac的格式
        if not self.use_centralized_V:
            share_obs = obs
        
        self.buffer.insert(share_obs, obs, rnn_states, rnn_states_critic, actions, action_log_probs, values, rewards,
                           masks, bad_masks, active_masks, available_actions) # 将数据保存到buffer
    
    def log_train(self, train_infos, total_num_steps): # 此函数来自smac_runner
        train_infos["average_step_rewards"] = np.mean(self.buffer.rewards)
        for k, v in train_infos.items():
            #if self.use_wandb:
               # wandb.log({k: v}, step=total_num_steps)
            #else:
            self.writter.add_scalars(k, {k: v}, total_num_steps)
    
    @torch.no_grad()
    def eval(self, total_num_steps): # eval暂时还没根据smac_runner进行更改
        eval_episode_rewards = []
        eval_obs = self.eval_envs.reset()

        eval_rnn_states = np.zeros((self.n_eval_rollout_threads, *self.buffer.rnn_states.shape[2:]), dtype=np.float32)
        eval_masks = np.ones((self.n_eval_rollout_threads, self.num_agents, 1), dtype=np.float32)

        for eval_step in range(self.episode_length):
            self.trainer.prep_rollout()
            eval_action, eval_rnn_states = self.trainer.policy.act(np.concatenate(eval_obs),
                                                                   np.concatenate(eval_rnn_states),
                                                                   np.concatenate(eval_masks),
                                                                   deterministic=True)
            eval_actions = np.array(np.split(_t2n(eval_action), self.n_eval_rollout_threads))
            eval_rnn_states = np.array(np.split(_t2n(eval_rnn_states), self.n_eval_rollout_threads))

            if self.eval_envs.action_space[0].__class__.__name__ == 'MultiDiscrete':
                for i in range(self.eval_envs.action_space[0].shape):
                    eval_uc_actions_env = np.eye(self.eval_envs.action_space[0].high[i] + 1)[eval_actions[:, :, i]]
                    if i == 0:
                        eval_actions_env = eval_uc_actions_env
                    else:
                        eval_actions_env = np.concatenate((eval_actions_env, eval_uc_actions_env), axis=2)
            elif self.eval_envs.action_space[0].__class__.__name__ == 'Discrete':
                eval_actions_env = np.squeeze(np.eye(self.eval_envs.action_space[0].n)[eval_actions], 2)
            else:
                raise NotImplementedError

            # Obser reward and next obs
            eval_obs, eval_rewards, eval_dones, eval_infos = self.eval_envs.step(eval_actions_env)
            eval_episode_rewards.append(eval_rewards)

            eval_rnn_states[eval_dones == True] = np.zeros(
                ((eval_dones == True).sum(), self.recurrent_N, self.hidden_size), dtype=np.float32)
            eval_masks = np.ones((self.n_eval_rollout_threads, self.num_agents, 1), dtype=np.float32)
            eval_masks[eval_dones == True] = np.zeros(((eval_dones == True).sum(), 1), dtype=np.float32)

        eval_episode_rewards = np.array(eval_episode_rewards)
        eval_env_infos = {}
        eval_env_infos['eval_average_episode_rewards'] = np.sum(np.array(eval_episode_rewards), axis=0)
        eval_average_episode_rewards = np.mean(eval_env_infos['eval_average_episode_rewards'])
        print("eval average episode rewards of agent: " + str(eval_average_episode_rewards))
        self.log_env(eval_env_infos, total_num_steps)

    @torch.no_grad()
    def render(self):
        """Visualize the env."""
        envs = self.envs

        all_frames = []
        for episode in range(self.all_args.render_episodes):
            obs = envs.reset()
            if self.all_args.save_gifs:
                image = envs.render('rgb_array')[0][0]
                all_frames.append(image)
            else:
                envs.render('human')

            rnn_states = np.zeros((self.n_rollout_threads, self.num_agents, self.recurrent_N, self.hidden_size),
                                  dtype=np.float32)
            masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)

            episode_rewards = []

            for step in range(self.episode_length):
                calc_start = time.time()

                self.trainer.prep_rollout()
                action, rnn_states = self.trainer.policy.act(np.concatenate(obs),
                                                             np.concatenate(rnn_states),
                                                             np.concatenate(masks),
                                                             deterministic=True)
                actions = np.array(np.split(_t2n(action), self.n_rollout_threads))
                rnn_states = np.array(np.split(_t2n(rnn_states), self.n_rollout_threads))

                if envs.action_space[0].__class__.__name__ == 'MultiDiscrete':
                    for i in range(envs.action_space[0].shape):
                        uc_actions_env = np.eye(envs.action_space[0].high[i] + 1)[actions[:, :, i]]
                        if i == 0:
                            actions_env = uc_actions_env
                        else:
                            actions_env = np.concatenate((actions_env, uc_actions_env), axis=2)
                elif envs.action_space[0].__class__.__name__ == 'Discrete':
                    actions_env = np.squeeze(np.eye(envs.action_space[0].n)[actions], 2)
                else:
                    raise NotImplementedError

                # Obser reward and next obs
                obs, rewards, dones, infos = envs.step(actions_env)
                episode_rewards.append(rewards)

                rnn_states[dones == True] = np.zeros(((dones == True).sum(), self.recurrent_N, self.hidden_size),
                                                     dtype=np.float32)
                masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
                masks[dones == True] = np.zeros(((dones == True).sum(), 1), dtype=np.float32)

                if self.all_args.save_gifs:
                    image = envs.render('rgb_array')[0][0]
                    all_frames.append(image)
                    calc_end = time.time()
                    elapsed = calc_end - calc_start
                    if elapsed < self.all_args.ifi:
                        time.sleep(self.all_args.ifi - elapsed)
                else:
                    envs.render('human')

            print("average episode rewards is: " + str(np.mean(np.sum(np.array(episode_rewards), axis=0))))

        if self.all_args.save_gifs:
            imageio.mimsave(str(self.gif_dir) + '/render.gif', all_frames, duration=self.all_args.ifi)
