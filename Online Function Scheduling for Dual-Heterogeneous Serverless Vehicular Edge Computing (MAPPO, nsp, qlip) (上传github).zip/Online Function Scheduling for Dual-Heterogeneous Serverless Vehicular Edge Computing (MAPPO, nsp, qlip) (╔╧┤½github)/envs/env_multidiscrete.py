"""
# @Time    : 2021/7/2 5:22 下午
# @Author  : hezhiqiang
# @Email   : tinyzqh@163.com
# @File    : env_discrete.py
"""

import gym
from gym import spaces
import numpy as np
import sys
import os
sys.path.append(os.pardir) #这个是返回当前文件的父目录 
from configg import Configg  # 从参数文件中导入参数类
conf = Configg()  # conf是类Config的实例化对象
from envs.AP_VEC_environment import VEC_env


class MultiDiscreteActionEnv(object):
    """对于多维离散动作环境的封装"""
    def __init__(self, all_args, run_dir):
        self.env = VEC_env(conf, all_args, run_dir)
        #self.num_agent = conf.n_agents
        self.num_agent = conf.n_agents

        self.signal_obs_dim = conf.obs_shape
        self.signal_action_dim = conf.action_dim

        # if true, action is a number 0...N, otherwise action is a one-hot N-dimensional vector
        #self.discrete_action_input = False

        #self.movable = True

        # configure spaces
        self.action_space = []
        self.observation_space = []
        self.share_observation_space = []

        #share_obs_dim = 0
        for agent in range(self.num_agent):
            #total_action_space = []

            # physical action space
            #u_action_space = spaces.Discrete(self.signal_action_dim)  # 5个离散的动作
            #u_action_space = spaces.MultiDiscrete([ [0, self.signal_action_dim[0]], [0, self.signal_action_dim[1]] ])
            #total_action_space.append(spaces.MultiDiscrete([ self.signal_action_dim[0], self.signal_action_dim[1] ])
            """
            if self.movable:
                total_action_space.append(u_action_space)
            
            
            action_space_temp = [spaces.Discrete(self.signal_action_dim[0]), spaces.Discrete(self.signal_action_dim[1])]
            if all([isinstance(act_space, spaces.Discrete) for act_space in action_space_temp]):
                act_space = MultiDiscrete([[0, act_space.n - 1] for act_space in action_space_temp])
            """
            act_space = spaces.Discrete(self.signal_action_dim)
            self.action_space.append(act_space)
            
            
            """
            if len(total_action_space) > 1:
                # all action spaces are discrete, so simplify to MultiDiscrete action space
                if all([isinstance(act_space, spaces.Discrete) for act_space in total_action_space]):
                    act_space = MultiDiscrete([[0, act_space.n - 1] for act_space in total_action_space])
                else:
                    act_space = spaces.Tuple(total_action_space)
                self.action_space.append(act_space)
            else:
                self.action_space.append(total_action_space[0])
            """
            #self.action_space.append( MultiDiscrete([ [0, self.signal_action_dim[0]], [0, self.signal_action_dim[1]] ]) )
            # observation space
            
            #share_obs_dim += self.signal_obs_dim
            # https://zhuanlan.zhihu.com/p/386559032
            # 如果采用centralized_V值函数的训练方式，则需要初始化的时候构造出多个智能体的share_obs
            # 每个局部智能体接收一个局部的观察self.observation_space(single_obs_dim)，输出一个动作概率，所有的actor智能体都采用一个actor网络。
            # critic网络接收所有智能体的观测self.share_observation_space(self.num_agent*single_obs_dim)，输出为一个值，这个值用于actor的更新
            
            self.observation_space.append([conf.obs_shape, [1, conf.obs_shape]])
            if all_args.use_obs_instead_of_state:
                self.share_observation_space.append([conf.obs_shape*self.num_agent, [1, conf.obs_shape*self.num_agent]])
            else:
                self.share_observation_space.append([conf.state_shape, [1, conf.state_shape]])
                                           
            """
            self.observation_space.append([200, [1, conf.queue_max + 1], [1, conf.queue_max + 1], [1, conf.coordinate_segment_num], [1, conf.coordinate_segment_index_num], [1, conf.task_type_num + 1], 
                                           [1, conf.task_function_type_num + 1], [1, conf.task_function_type_num + 1], [1, conf.task_function_type_num + 1], 
                                           [1, conf.task_function_type_num + 1], [1, conf.task_function_type_num + 1], [1, conf.task_function_type_num + 1]])  # 模仿StarCraft2_Env.py写的
            """
            #(spaces.Box(low=-np.inf, high=+np.inf, shape=(self.signal_obs_dim,),dtype=np.float32))  # [-inf,inf]

            #self.share_observation_space.append([187, [1, conf.queue_max + 1], [1, conf.queue_max + 1], [1, conf.queue_max + 1], [1, conf.queue_max + 1], 
            #                                     [1, conf.VUE_num + 1], [1, conf.VUE_num + 1], [1, conf.VUE_num + 1]])  # 模仿StarCraft2_Env.py写的
        #[spaces.Box(low=-np.inf, high=+np.inf, shape=(share_obs_dim,), dtype=np.float32) for _ in range(self.num_agent)]

    def step(self, actions):
        """
        输入actions纬度假设：
        # actions shape = (5, 2, 5)
        # 5个线程的环境，里面有2个智能体，每个智能体的动作是一个one_hot的5维编码
        """

        results = self.env.step(actions)
        obs, share_obs, rews, dones, infos, available_actions, episode_data_record = results
        #obs, rews, dones = results
        #print(share_obs, len(share_obs))
        return np.stack(obs), np.stack(share_obs), np.stack(rews), np.stack(dones), infos, np.stack(available_actions), np.stack(episode_data_record)

    def reset(self):
        obs, share_obs, available_actions = self.env.reset()
        return np.stack(obs), np.stack(share_obs), np.stack(available_actions)

    def close(self):
        pass

    def render(self, mode="rgb_array"):
        pass

    def seed(self, seed):
        pass

class MultiDiscrete(gym.Space):
    """
    - The multi-discrete action space consists of a series of discrete action spaces with different parameters
    - It can be adapted to both a Discrete action space or a continuous (Box) action space
    - It is useful to represent game controllers or keyboards where each key can be represented as a discrete action space
    - It is parametrized by passing an array of arrays containing [min, max] for each discrete action space
       where the discrete action space can take any integers from `min` to `max` (both inclusive)
    Note: A value of 0 always need to represent the NOOP action.
    e.g. Nintendo Game Controller
    - Can be conceptualized as 3 discrete action spaces:
        1) Arrow Keys: Discrete 5  - NOOP[0], UP[1], RIGHT[2], DOWN[3], LEFT[4]  - params: min: 0, max: 4
        2) Button A:   Discrete 2  - NOOP[0], Pressed[1] - params: min: 0, max: 1
        3) Button B:   Discrete 2  - NOOP[0], Pressed[1] - params: min: 0, max: 1
    - Can be initialized as
        MultiDiscrete([ [0,4], [0,1], [0,1] ])
    """

    def __init__(self, array_of_param_array):
        #super().__init__() # 这一句源代码中有，但只有注释了才能运行
        self.low = np.array([x[0] for x in array_of_param_array])
        self.high = np.array([x[1] for x in array_of_param_array])
        self.num_discrete_space = self.low.shape[0]
        self.n = np.sum(self.high) + 2

    def sample(self):
        """ Returns a array with one sample from each discrete action space """
        # For each row: round(random .* (max - min) + min, 0)
        random_array = np.random.rand(self.num_discrete_space)
        return [int(x) for x in np.floor(np.multiply((self.high - self.low + 1.), random_array) + self.low)]

    def contains(self, x):
        return len(x) == self.num_discrete_space and (np.array(x) >= self.low).all() and (
                    np.array(x) <= self.high).all()

    @property
    def shape(self):
        return self.num_discrete_space

    def __repr__(self):
        return "MultiDiscrete" + str(self.num_discrete_space)

    def __eq__(self, other):
        return np.array_equal(self.low, other.low) and np.array_equal(self.high, other.high)


#if __name__ == "__main__":
#    DiscreteActionEnv().step(actions=None)