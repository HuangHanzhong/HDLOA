import torch
import numpy as np
from interval import Interval
import math
class Configg:
    def __init__(self):
        self.episode_limit = 250
        
        self.VUE_num = 30 # 大概每个RSU有6个ICV
        self.RSU_num = 3
        self.MBS_num = 2 
        #self.ABS_num = 1
        self.HIBS_num = 2
        self.container_computing_resource_level = 5 # RSU和MBS中的容器的计算资源有5个调节等级。VUE和云的容器计算资源固定，不用调节
        self.task_function_type_num = 3
        self.total_VUE_task_function_num = self.VUE_num * self.task_function_type_num
        self.total_VUE_task_function_index_set = list(range(0, self.total_VUE_task_function_num))
        
        #self.action_space0 = list(range(0, self.task_function_type_num)) # 为每类任务函数做决策
        #self.action_space0 = list(range(0, 2 ** self.task_function_type_num)) # 为新到达的任务函数决策放在本地计算队列还是本地传输队列
        # 每个函数有两个动作可选，一个任务最多分成3个函数，因此一个任务总的动作个数为2**3=8
        # 0表示本地计算LCQ；1表示LTQ
        # 000 = 0;       001 = 1;
        # 010 = 2;       011 = 3;
        # 100 = 4;       101 = 5;
        # 110 = 6;       111 = 7;
        # 如果有函数0和函数1，action取值000；010；100；110，即[0,2,4,6]
        # 如果有函数0和函数2，action取值000；001；100；101，即[0,1,4,5]
        # 如果有函数1和函数2，action取值000；001；010；011；即[0,1,2,3]
        #self.action_space1 = list(range(0, self.RSU_num + self.MBS_num + 2))
        # 如果本地传输队列有任务开始传输，为此任务决策卸载到哪个边缘节点 # 最后两个动作分别表示HIBS计算和云计算
        #self.action_space2 = list(range(0, self.container_computing_resource_level))  # 如果本地传输队列有任务开始传输，为此任务决策容器计算资源级别
        
        
        # 0~14：RSU；  15~24：MBS;   25:cloud
        #self.action_space = list(range(0, len(self.action_space0) * len(self.action_space3) + len(self.action_space0) + len(self.action_space3) + 1)) # 总个数558
        
        # [0+0*61, 60+0*61]      [0+1*61, 60+1*61]      [0+2*61, 60+2*61]       [0+a1*61, 60+a1*61]            a1=[0, 7]
        # [0, 60]                [61, 121]              [122, 182]              
        # 如果只有函数0，则000， 001，    a1 = 0,1
        # 如果有函数0， 2， 则a1 = 0, 1, 4, 5
        # [0, 61*8-1] 表示两个决策都有的情况 [0, 487]
        # [61*8, 61*8+8-1]表示只有新任务的情况 [488, 495]
        # [61*8+8, 61*8+8+61-1]表示只有待传输的情况 [496, 556]
        # 如果都没有，[557]
        
        """
        # 同时为新到达任务和待传输任务做决策，将两个子决策空间加起来。
        # 1. 如果没有新到达任务，也没有待传输任务；则可选动作个数为0；
        # 2. 如果没有新到达任务，有待传输任务：可选动作个数为len(self.action_space3)=61
        # 3. 如果有新到达任务，没有待传输任务：可选动作个数为len(self.action_space0)=8
        # 4. 如果两个都有：可选动作个数为63
        #self.expanded_n_actions = 2 ** self.task_function_type_num + 2 * self.RSU_num * self.container_computing_resource_level + 2 * 1 * self.container_computing_resource_level + \
        #                          1 * self.container_computing_resource_level + 1 * self.container_computing_resource_level + 1
        # 2**3+30+30+20+10+10+1 = 109  8~37：直连RSU;   38~67：中继RSU；  68~77：直连MBS0;   78~87：中继MBS0；  88~97：直连HAPS；  98~107：中继MBS1；  108：中继云
        """
        self.local_actions = 2 # 考虑到本地决策只有一个，我们用10个action映射本地决策，从而平衡边缘决策和本地决策
        self.action_space = list(range(0, (self.RSU_num + self.MBS_num) * self.container_computing_resource_level + 1 + self.local_actions + 1))
        # 待传输任务的总决策空间：(3+2)*5 + 1 + self.local_actions + 1 = 29 # 倒数第三个1是云，倒数第二个2是本地，最后的1是没有待决策函数
        
        self.queue_max = 10 # 队列最大长度
        self.n_agents = self.VUE_num
        self.n_actions = len(self.action_space) # 34
        #self.obs_shape = self.queue_max*4 + 11 + self.n_actions # 116  # 单个智能体的obs长度 【车辆坐标； 任务大小； 计算需求值】 如果没有生成任务，后面两个都为0
        self.obs_shape = self.queue_max*8 + 6 + self.n_actions # 47
        self.state_shape = self.n_agents*23 + 24 + 19*3 # 815
        #self.state_shape = 19*self.queue_max*1 + 5*self.queue_max*2 + self.n_agents*7 + 35 + 19 + 19 + 19*3 # 5*self.queue_max*2 + 2*19*self.queue_max +   5*3 # / # 202 # + self.n_agents*self.n_actions
        self.action_dim = len(self.action_space)
        
        
        self.time_slot = 10 # ms # Deep Reinforcement Learning for Task Offloading in Mobile Edge Computing Systems (TMC 2020, tang ming)
        
        self.VUE_index_set = list(range(0, self.VUE_num))  # 生成[0, 1, ..., 24]
        self.RSU_index_set = list(range(0, self.RSU_num))  # 生成[0, 1, 2, 3]
        self.MBS_index_set = list(range(0, self.MBS_num))
        #self.ABS_index_set = list(range(0, self.ABS_num))
        self.HIBS_index_set = list(range(0, self.HIBS_num))
        self.VUE_height = 1 # m
        self.VUE_x1 = 3 # m 向右行驶的车道的车辆x轴坐标值
        self.VUE_x2 = -self.VUE_x1 # m 向左行驶的车辆x轴坐标值
        self.RSU_height = 6 # m
        self.RSU_radius = 200 # m
        self.ABS_height = 200 # m
        self.MBS_height = 25 # m
        self.HIBS_height = 20000
        self.MBS0_x = -100
        self.MBS1_x = -4*self.RSU_radius-100
        self.beam_num_max = 4 # RSU最大波束
        
        self.coordinate_segment_num = 70 # 一共1400m，分为70个路段，每段20m
        self.coordinate_segment_index_num = 40 # 每段20m，按0.5划分，有40个坐标点
        self.coordinate_y_begin = -700 # m 坐标轴y轴左侧边界
        self.coordinate_y_end = -self.coordinate_y_begin # m 坐标轴y轴右侧边界
        self.coordinate_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_end) # y轴闭区间范围，[coordinate_y_begin, coordinate_y_end]
        self.RSU0_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_begin + 2*self.RSU_radius)
        # RSU0 y轴闭区间范围，[a, b] [-700, -300]
        self.RSU1_y_range = Interval(self.coordinate_y_begin + 2*self.RSU_radius + 100, self.coordinate_y_begin + 100 + 4*self.RSU_radius)
        # RSU1 y轴闭区间范围，[a, b] [-200, 200]
        self.RSU2_y_range = Interval(self.coordinate_y_end - 2*self.RSU_radius, self.coordinate_y_end)
        # RSU2 y轴闭区间范围，[a, b] [300, 700]
        self.RSU_y_range_set = [self.RSU0_y_range, self.RSU1_y_range, self.RSU2_y_range]
        
        self.RSU0_coordinate = [0, self.coordinate_y_begin + self.RSU_radius, self.RSU_height]
        self.RSU1_coordinate = [0, self.coordinate_y_begin + 3*self.RSU_radius + 100, self.RSU_height]
        self.RSU2_coordinate = [0, self.coordinate_y_end - self.RSU_radius, self.RSU_height]
        self.RSU_coordinate_set = [self.RSU0_coordinate, self.RSU1_coordinate, self.RSU2_coordinate]
        
        self.MBS0_y_range = Interval(self.coordinate_y_begin, 100) # 与前两个RSU部分重叠
        #self.MBS1_y_range = Interval(self.coordinate_y_end - 200 - 4*self.RSU_radius - 100, self.coordinate_y_end - 100)
        
        self.MBS0_coordinate = [self.MBS0_x, -300, self.MBS_height] 
        self.MBS1_coordinate = [self.MBS1_x, 300, self.MBS_height]
        self.MBS_coordinate_set = [self.MBS0_coordinate, self.MBS1_coordinate]
        
        self.ABS_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_end)
        #self.ABS1_y_range = Interval(self.coordinate_y_end - 200 - 4*self.RSU_radius - 200, self.coordinate_y_end)
        
        self.ABS_coordinate = [0, 0, self.ABS_height]
        #self.ABS1_coordinate = [0, self.coordinate_y_end - 200 - 2*self.RSU_radius, self.ABS_height]
        #self.ABS_coordinate_set = [self.ABS0_coordinate, self.ABS1_coordinate]
        
        self.HIBS0_y_range = Interval(self.coordinate_y_begin, self.coordinate_y_end)
        self.HIBS0_coordinate = [0, 0, self.HIBS_height]
        self.HIBS_HIBS_interval = 600000 # 两个HIBS之间的距离
        self.HIBS1_coordinate = [0, self.HIBS_HIBS_interval, self.HIBS_height]
        self.HIBS1_cloud_interval = 300000 # 中继HIBS到云的距离
        #self.VUE_x1_num = 6 # 前面向右行驶的车辆数（x轴正轴）
        #self.VUE_x2_num = self.VUE_num - self.VUE_x1_num # 后面向左行驶的车辆数（x轴负轴）
        
        self.AX_distance_set = [0]*(1 + self.RSU_num)
        for RSU_index in self.RSU_index_set:
            self.AX_distance_set[RSU_index] = np.linalg.norm(np.array(self.ABS_coordinate) - np.array(self.RSU_coordinate_set[RSU_index]))
        self.AX_distance_set[-1] = np.linalg.norm(np.array(self.ABS_coordinate) - np.array(self.MBS0_coordinate))
        
        self.HIBS0_MBS1_distance = np.linalg.norm(np.array(self.HIBS0_coordinate) - np.array(self.MBS1_coordinate))
        
        self.VUE1_x1_coordinate_y_initial = self.coordinate_y_begin + 1 # x轴正方向侧的第一个车辆的初始坐标
        self.VUE1_x2_coordinate_y_initial = self.coordinate_y_end - 1 # x轴负方向侧的第一个车辆的初始坐标
        self.VUE_min_interval = 50 # 车辆安全距离
        self.coordinate_candidates_num = int(2*self.coordinate_y_end / self.VUE_min_interval) - 1 # 初始化车辆坐标时可选的候选坐标点个数
        
        self.x1_coordinate_candidates = [] # x正轴初始化坐标点候选集
        for coordinate_candidates_index in range(self.coordinate_candidates_num):
            self.x1_coordinate_candidates.append(self.VUE1_x1_coordinate_y_initial + coordinate_candidates_index*self.VUE_min_interval)
        
        self.x2_coordinate_candidates = [] # x负轴初始化坐标点候选集
        for coordinate_candidates_index in range(self.coordinate_candidates_num):
            self.x2_coordinate_candidates.append(self.VUE1_x2_coordinate_y_initial - coordinate_candidates_index*self.VUE_min_interval)
        
        self.VUE_vCPU_num = 1 # (L5) Deadline-aware Dynamic Resource Management in Serverless Computing Environments (CCGird 2021)
        self.RSU_vCPU_num = 3
        self.MBS_vCPU_num = 5
        #self.HIBS_vCPU_num = 20
        #self.MBS_vCPU_occupied_Poisson_factor = 3
        #self.HIBS_vCPU_occupied_Poisson_factor = 5
        self.cloud_vCPU_num = 1
        
        self.total_edge_vCPU_num = self.RSU_num * self.RSU_vCPU_num + self.MBS_num * self.MBS_vCPU_num # 总的边缘节点的vCPU核数 19
        
        self.VUE_vCPU_computing_resource = 1.5*10**4  # MIPS
        # MIPS单位和取值参考如下两篇
        # Metaheuristics for scheduling of heterogeneous tasks in cloud computing environments: Analysis, performance evaluation, and future directions
        # (L5) Deadline-aware Dynamic Resource Management in Serverless Computing Environments (CCGird 2021)
        self.RSU_vCPU_computing_resource = 1*10**5  # MIPS # 每个vCPU核的资源有10个等级，可以生成10类container, [6, 7, ..., 15] k MI
        # 用户的函数可以选择一类容器进行计算
        self.MBS_vCPU_computing_resource = 1*10**5  # MIPS
        #self.HIBS_vCPU_computing_resource = 7*10**4  # MIPS
        self.cloud_vCPU_computing_resource = 5*10**4  # MIPS 云的资源参考 # Federated edge computing for disaster management in remote smart oil fields
        # 云对每个到达的任务函数，都分配这么多的计算资源，多个函数之间不用竞争
        
        #self.container_set = [0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5]
        #self.container_set = [3, 3.5, 4, 4.5, 5]
        #self.container_set = [1, 2, 3, 4, 5]
        self.container_set = [2, 2.5, 3, 3.5, 4]
        self.cold_start_delay_threshold = 100 / self.time_slot # 原文是800ms  # A Joint Resource Allocation and Request Dispatch Scheme for Performing Serverless Computing over Edge and Cloud (CC 2021)
        self.empty_container_delay_threshold = 5 # 空闲容器时延阈值
        self.empty_function_instance_num_in_one_VM = 12 # 每种function的实例，即对应函数类型的热容器的个数，我们假定最大15个（实际上没有个数限制，但因为state需要归一化，因此设这么一个值，应该不会超过这个值
        # 具体设多少，应该需要更精确的测试
        
        # (L5, 函数计算) Distributed Task Scheduling in Serverless Edge Computing Networks for the Internet of Things_A Learning Approach (IoT 2022)
        self.container_computing_resource_down = self.container_set[0]
        self.container_computing_resource_set = []
        for ele in range(self.container_computing_resource_level):
            self.container_computing_resource_set.append( int((self.container_computing_resource_down + ele*0.5) *10**4) )
        
        self.ICV_vCPU_memory_resource = 80*10**6
        self.RSU_vCPU_memory_resource = 300*10**6 # 300 Mb # (L5) Deadline-aware Dynamic Resource Management in Serverless Computing Environments (CCGird 2021)
        self.MBS_vCPU_memory_resource = 500*10**6
        #self.HIBS_VM_memory = 1000*10**6
        
        self.task_generation_lambda = 13
        self.task_type_num = 3
        
        self.CA_task_delay_threshold = int(400 / self.time_slot)  # ms
        self.HPA_task_delay_threshold = int(800 / self.time_slot)  # ms
        self.LPA_task_delay_threshold = int(1200 / self.time_slot)  # ms
        
        self.task_function0_bit_size = 0.5*10**6  # 1Mbit
        self.task_function0_memory_requirement = 50*10**6 # bit
        # (L5) Deadline-aware Dynamic Resource Management in Serverless Computing Environments (CCGird 2021)
        #self.task_function0_computation_density = 50  # CPU cycles/bit
        self.task_function0_computation_resource_requirement = 1000 # MI
        
        self.task_function1_bit_size = 1*10**6  # 2Mbit
        self.task_function1_memory_requirement = 80*10**6 # bit
        #self.task_function1_computation_density = 100  # CPU cycles/bit
        self.task_function1_computation_resource_requirement = 2000  # MI
        
        self.task_function2_bit_size = 1.5*10**6  # 3Mbit
        self.task_function2_memory_requirement = 110*10**6 # bit
        #self.task_function2_computation_density = 200  # CPU cycles/bit
        self.task_function2_computation_resource_requirement = 3000 # MI
        """
        self.task_function3_bit_size = 1*10**3  # bit
        self.task_function3_memory_requirement = 140*10**6 # bit
        #self.task_function3_computation_density = 100  # CPU cycles/bit
        #self.task_function3_computation_resource_requirement = self.task_function3_bit_size*self.task_function3_computation_density
        
        self.task_function4_bit_size = 4*10**3  # bit
        self.task_function4_memory_requirement = 170*10**6 # bit
        #self.task_function4_computation_density = 50  # CPU cycles/bit
        #self.task_function4_computation_resource_requirement = self.task_function4_bit_size*self.task_function4_computation_density
        """
        
        self.task_function_bit_size_set = [self.task_function0_bit_size, self.task_function1_bit_size, self.task_function2_bit_size]
        self.task_function_memory_requirement_set = [self.task_function0_memory_requirement, self.task_function1_memory_requirement, 
                                                     self.task_function2_memory_requirement]
        self.task_function_memory_requirement_set = [self.task_function0_memory_requirement, self.task_function1_memory_requirement, 
                                                     self.task_function2_memory_requirement]
        self.task_function_computation_resource_requirement_set = [self.task_function0_computation_resource_requirement, self.task_function1_computation_resource_requirement, 
                                                                   self.task_function2_computation_resource_requirement]
        #self.task_function_computation_density_set = [self.task_function0_computation_density, self.task_function1_computation_density, self.task_function2_computation_density,
        #                                              self.task_function3_computation_density, self.task_function4_computation_density]
        #self.task_function_computation_resource_requirement_set = [self.task_function0_computation_resource_requirement, self.task_function1_computation_resource_requirement,
        #                                                           self.task_function2_computation_resource_requirement, self.task_function3_computation_resource_requirement, 
        #                                                           self.task_function4_computation_resource_requirement]
        self.task_delay_threshold_set = [self.CA_task_delay_threshold, self.HPA_task_delay_threshold, self.LPA_task_delay_threshold]
        
        self.task_function_bit_size_max = max(self.task_function_bit_size_set) # 最大任务数据量，用于归一化
        self.task_function_memory_requirement_max = max(self.task_function_memory_requirement_set)
        self.task_function_computation_resource_requirement_max = max(self.task_function_computation_resource_requirement_set) # 最大计算资源需求，用于归一化
        self.task_delay_threshold_max = max(self.task_delay_threshold_set)
        
        self.task_type_prob = np.array([0.7, 0.2, 0.1]) # 产生三种任务类型的概率
        self.VUE_with_task_num_min = 9 # 有任务的用户数最小值
        
        self.task_generation_flag_num = 2 # 是否生成任务的标识个数，即0或者1
        self.task_generation_prob = 0.5 #0.64 # 每个车辆按0.5的概率生成任务
        self.task_generation_prob_set = np.array([self.task_generation_prob, 1 - self.task_generation_prob]) # 生成和不生成任务的概率
        
        self.task_function_type_num = 3 # 函数种类
        self.avail_task_function_num_set = list(range(2, self.task_function_type_num + 1)) # [2, 3, 4, 5]
        
        
        #self.sensing_task_bit_size = 1*10**3 # 车辆感知任务大小
        #self.sensing_task_computation_density = 50
        #self.sensing_task_delay_threshold = 1 # s
        
        
        #self.local_computing_latency_max = round((self.task_function_computation_resource_requirement_max / self.VUE_CPU_core_computing_resource) * 1e3, 3)
        # 本地计算最大时延
        #self.latency_threshold = 400 # ms  # 不同类型的任务时延阈值不同
        
        self.VUE_x1_move_direction_flag = 1 # 车辆行驶方向，取值1或2
        self.VUE_x2_move_direction_flag = 1
        self.VUE_speed_set = [0]*self.VUE_num
        self.truncated_normal_mean = 60
        self.truncated_normal_stddev = 21**0.5
        self.VUE_speed_unit_factor = round(1e3/36000, 4) # 将km/h换算成m/(100ms)， 考虑每100ms的决策
        
        self.sub6_frequency0 = 2*10**3  # 2*10^3 MHz； 2 GHz   HAPS对地频段
        self.sub6_frequency1 = 3.5*10**3  # 3.5*10^3 MHz； 3.5 GHz  # MBS和UAV与车辆的频段
        self.mmW_frequency = 28*10**3  # MHz; 28 GHz
        self.sub6_bandwidth = 20*10**6  # Hz;  20 MHz
        self.mmW_bandwidth = 200*10**6  # Hz;  100 MHz
        #self.Boltzmann_constant = 1.3806505*10**(-23)  # J/K
        #self.Kelvin_temperature = 300  # K
        #self.THz_molecular_absorption_coefficient = 1.6  # 1.6/km; 0.0016/m
        self.Gaussian_noise_psd_dBm_per_Hz = -174  # unit is dBm/Hz, noise power = Gaussian_noise_psd_dBm_per_Hz*Bandwidth
        self.channel_power_gain_at_reference_distance_dB = -65  # dB
        self.k_factor_VM = 0 # 瑞利衰落莱斯因子为0
        self.k_factor_VH = 10 # 莱斯衰落莱斯因子为10
        self.VM0_channel_gain_max = -100 # dB
        
        self.VR_power_decay_exponent = 2.5
        self.VM_power_decay_exponent = 3
        self.VA_power_decay_exponent = 2
        self.VH_power_decay_exponent = 2
        self.AV_power_decay_exponent = 2
        self.AR_power_decay_exponent = 2
        self.AM_power_decay_exponent = 2
        self.HV_power_decay_exponent = 2
        self.HR_power_decay_exponent = 2
        self.HM_power_decay_exponent = 2
        
        self.VUE_tx_sub6_antenna_gain = 17  # dBi
        self.ABS_tx_sub6_antenna_gain = 17  # dBi
        self.ABS_rx_sub6_antenna_gain = 0  # dBi
        self.VUE_tx_mmW_antenna_gain = 17  # dBi
        self.RSU_rx_mmW_antenna_gain = 17  # dBi
        self.RSU_rx_sub6_antenna_gain = 0  # dBi
        self.MBS_rx_sub6_antenna_gain = 0  # dBi
        self.HIBS_tx_sub6_antenna_gain = 17  # dBi
        self.HIBS_rx_sub6_antenna_gain = 0  # dBi
        
        #VUE_tx_power_W = 1  # 1 W
        #VUE_tx_power_dBm = 10 * math.log(1000*VUE_tx_power_W, 10) # 30 dBm
        #ABS_tx_power_W = 1  # 1 W
        #ABS_tx_power_dBm = 10 * math.log(1000*ABS_tx_power_W, 10) # 30 dBm
        self.VUE_tx_power_dBm = 20 # dBm
        self.ABS_tx_power_dBm = 20 # dBm
        self.HIBS_tx_power_dBm = 20 # dBm
        #self.RSU_tx_power_dBm = 20 # dBm
        
        #self.ABS_energy_threshold = 10
        self.SNR_threshold = 10 # SNR阈值
        
        
        self.FSO_transmitting_divergence_angle = 85 * 10 ** (-6) # rad   (L5, inter-HAPS) Channel Modelling for Free-Space Optical Inter-HAP Links Using Adaptive ARQ Transmission (CC 2014)
        self.FSO_receiver_telescope_diameter = 1 # m   (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
                                                 #     (L5, inter-HAPS) Channel Modelling for Free-Space Optical Inter-HAP Links Using Adaptive ARQ Transmission (CC 2014)
        self.FSO_wavelength = 1550 * 10 ** (-9) # m 要将nm转换为m   (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.FSO_transmitter_optical_efficiency_factor = 0.8 # (L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        self.FSO_receiver_optical_efficiency_factor = 0.8 # (L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        self.FSO_pointing_error = 10 ** (-2/10) # 2 dB，转换为可以相乘的正常单位  FSO-based vertical backhaul-fronthaul framework for 5G+ wireless networks (CM 2018)
        
        self.FSO_transmitter_antenna_gain = 16 / math.pow(self.FSO_transmitting_divergence_angle, 2) # FSO发射天线增益
        # (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.FSO_transmitter_antenna_gain_dB = 10*math.log(self.FSO_transmitter_antenna_gain, 10)
        self.FSO_receiver_antenna_gain = math.pow(math.pi * self.FSO_receiver_telescope_diameter / self.FSO_wavelength, 2) # FSO接收天线增益
        # (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.FSO_receiver_antenna_gain_dB = 10*math.log(self.FSO_receiver_antenna_gain, 10)
        
        self.Planck_constant_factor = 6.626*10**(-34) # J.s    FSO-based vertical backhaul-fronthaul framework for 5G+ wireless networks (CM 2018)
        self.light_speed = 3*10**8  # 3*10^8 m/s
        self.FSO_photon_energy = self.Planck_constant_factor * self.light_speed / self.FSO_wavelength # (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.FSO_receiver_sensitivity = 100 # photons/b  FSO-based vertical backhaul-fronthaul framework for 5G+ wireless networks (CM 2018)
        self.FSO_rate_small_part = 4 / (math.pi * self.FSO_photon_energy * self.FSO_receiver_sensitivity)
        
        self.FSO_transmit_power = 200 * 10 ** (-3) # W  (L5, inter-HAPS) Channel Modelling for Free-Space Optical Inter-HAP Links Using Adaptive ARQ Transmission (CC 2014)
        
        self.HH_FSO_fspl = math.pow(self.FSO_wavelength / (4 * math.pi * self.HIBS_HIBS_interval), 2) # 此处波长和距离的单位一致，都是m
        # (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.HC_FSO_fspl = math.pow(self.FSO_wavelength / (4 * math.pi * self.HIBS1_cloud_interval), 2)
        
        self.HIBS0_MBS1_interval = np.linalg.norm(np.array(self.HIBS0_coordinate) - np.array(self.MBS1_coordinate)) # HIBS0到MBS1的距离
        self.HM_FSO_fspl = math.pow(self.FSO_wavelength / (4 * math.pi * self.HIBS0_MBS1_interval), 2)
        
        self.HH_FSO_fspl_dB = 10*math.log(self.HH_FSO_fspl, 10)
        self.HC_FSO_fspl_dB = 10*math.log(self.HC_FSO_fspl, 10)
        self.HM_FSO_fspl_dB = 10*math.log(self.HM_FSO_fspl, 10)
        self.HH_FSO_aa = 10 ** (-0.058 * (self.HIBS_HIBS_interval * 10 ** (-3)) / 10) # 平流层中HIBS之间的大气衰减，因子为0.058 dB/km。距离转换为km
        # 衰减因子引自：(L5, inter-HAPS loss) Link Budget Design of Adaptive Optical Satellite Network for Integrated Non-Terrestrial Network (ICSOS 2022)
        self.HC_FSO_liquid_water_content = 0.064 # g/(m**(-3)) 
        self.HC_FSO_thin_cirrus_cloud_concentration = 0.025 # cm**(-3)
        self.HC_FSO_visibility_distance = 1.002 / pow(self.HC_FSO_liquid_water_content * self.HC_FSO_thin_cirrus_cloud_concentration, 0.6473) # (L5, FSO信道增益)
        # (L5, 可视距离计算) Cloud Attenuations for Free-Space Optical Links (CC 2013)
        # (L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        self.HC_FSO_particle_size_coefficient = 1.3 # 没有单位 # (L3, HAPS-UAV信道) Outage Performance of HAP-UAV FSO Links with Gaussian Beam and UAV Hovering (VTC 2020)
        self.HC_FSO_aa_coefficient = (3.912 / 40) * pow((self.FSO_wavelength * 10 ** 9 / 550), -self.HC_FSO_particle_size_coefficient)
        self.HC_FSO_aa = math.exp(-self.HC_FSO_aa_coefficient * (self.HIBS1_cloud_interval * 10 ** (-3))) # 距离单位为km
        # (L3, HAPS-UAV信道) Outage Performance of HAP-UAV FSO Links with Gaussian Beam and UAV Hovering (VTC 2020)
        
        #self.HC_FSO_aa = 10 ** (-0.2 * (self.HIBS1_cloud_interval * 10 ** (-3)) / 10)  # (l5, FSO速率公式) Free-space laser communication performance in the atmospheric channel (J 2005)
        self.HM_FSO_aa = math.exp(-self.HC_FSO_aa_coefficient * (self.HIBS0_MBS1_interval * 10 ** (-3))) # 距离单位为km
        self.HH_FSO_aa_dB = 10*math.log(self.HH_FSO_aa, 10)
        self.HC_FSO_aa_dB = 10*math.log(self.HC_FSO_aa, 10)
        self.HM_FSO_aa_dB = 10*math.log(self.HM_FSO_aa, 10)
        
        self.HH_FSO_gain = self.FSO_transmitter_antenna_gain * self.FSO_receiver_antenna_gain * \
                             self.FSO_transmitter_optical_efficiency_factor * self.FSO_receiver_optical_efficiency_factor * \
                             self.FSO_pointing_error * self.HH_FSO_fspl * self.HH_FSO_aa
        self.HC_FSO_gain = self.FSO_transmitter_antenna_gain * self.FSO_receiver_antenna_gain * \
                             self.FSO_transmitter_optical_efficiency_factor * self.FSO_receiver_optical_efficiency_factor * \
                             self.FSO_pointing_error * self.HC_FSO_fspl * self.HC_FSO_aa
        self.HM_FSO_gain = self.FSO_transmitter_antenna_gain * self.FSO_receiver_antenna_gain * \
                             self.FSO_transmitter_optical_efficiency_factor * self.FSO_receiver_optical_efficiency_factor * \
                             self.FSO_pointing_error * self.HM_FSO_fspl * self.HM_FSO_aa
        self.HH_FSO_gain_dB = 10*math.log(self.HH_FSO_gain, 10)
        self.HC_FSO_gain_dB = 10*math.log(self.HC_FSO_gain, 10)
        self.HM_FSO_gain_dB = 10*math.log(self.HM_FSO_gain, 10)
        
        self.HH_FSO_receiver_power = self.FSO_transmit_power * self.HH_FSO_gain
        self.HC_FSO_receiver_power = self.FSO_transmit_power * self.HC_FSO_gain
        self.HM_FSO_receiver_power = self.FSO_transmit_power * self.HM_FSO_gain
        # (L5, inter-HAPS) Design considerations for optical inter-HAP links (2004)
        
        self.HH_FSO_rate = (self.HH_FSO_receiver_power * self.FSO_rate_small_part) * 10 ** (0) # Gbps  (L5, FSO速率公式) Analysis of Data Rate for Free Space Optical Communications System (2014)
        self.HC_FSO_rate = (self.HC_FSO_receiver_power * self.FSO_rate_small_part) * 10 ** (0)
        self.HM_FSO_rate = (self.HM_FSO_receiver_power * self.FSO_rate_small_part) * 10 ** (0)
        
        """
        self.FSO_ground_station_height_above_sea = 0.5 # km  FSO地面站海拔高度
        self.FSO_ms_asl_extinction_ratio_wdec_a = -0.000545*(pow(self.FSO_wavelength, 2)) + 0.002*self.FSO_wavelength - 0.0038
        self.FSO_ms_asl_extinction_ratio_wdec_b = 0.00628*(pow(self.FSO_wavelength, 2)) - 0.0232*self.FSO_wavelength + 0.00439
        self.FSO_ms_asl_extinction_ratio_wdec_c = -0.028*(pow(self.FSO_wavelength, 2)) + 0.101*self.FSO_wavelength - 0.18
        self.FSO_ms_asl_extinction_ratio_wdec_d = -0.228*(pow(self.FSO_wavelength, 3)) + 0.922*(pow(self.FSO_wavelength, 2)) - 1.26*self.FSO_wavelength + 0.719
        self.FSO_ms_asl_extinction_ratio = self.FSO_ms_asl_extinction_ratio_wdec_a * pow(self.FSO_ground_station_height_above_sea, 3) + \
                                           self.FSO_ms_asl_extinction_ratio_wdec_b * pow(self.FSO_ground_station_height_above_sea, 2) + \
                                           self.FSO_ms_asl_extinction_ratio_wdec_c * self.FSO_ground_station_height_above_sea + \
                                           self.FSO_ms_asl_extinction_ratio_wdec_d
        # self.FSO_ms_asl_extinction_ratio 引自(L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        self.elevation_angle_of_FSO_ground_station = 40 # degree 引自(L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        #self.FSO_ms_asl = math.exp(-self.FSO_ms_asl_extinction_ratio / math.sin(self.elevation_angle_of_FSO_ground_station)) 
        # self.FSO_ms_asl 引自(L5, FSO信道增益) Link Budget Analysis for Free-Space Optical Satellite Networks (arxiv 2022)
        
        self.height_of_the_troposphere_layer_of_atmosphere = 20 # km
        self.FSO_distance_of_through_troposphere_layer = (self.height_of_the_troposphere_layer_of_atmosphere - self.FSO_ground_station_height_above_sea) * \
                                                         (1 / math.sin(self.elevation_angle_of_FSO_ground_station))
        #self.FSO_gs_asl = math.exp(-self.attenuation_coefficient * self.FSO_distance_of_through_troposphere_layer)
        #self.FSO_asl = self.FSO_ms_asl * self.FSO_gs_asl
        """
        
        self.per_device_backhaul_communication_capacity_min = 5 # Mbps
        self.per_device_backhaul_communication_capacity_max = 50 # Mbps # (重点，云计算时延) Collaborative cloud and edge computing for latency minimization (TVT 2019)
        # 上述两个参数用于计算云计算回程时延
        
        self.last_action = True # 使用最新动作选择动作 # ???
        self.reuse_network = True # 对所有智能体使用同一个网络
        